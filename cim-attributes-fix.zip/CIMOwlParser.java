package com.cim.service;

import com.cim.model.mongo.CimClassDefinition;
import org.apache.jena.rdf.model.*;
import org.apache.jena.vocabulary.OWL;
import org.apache.jena.vocabulary.RDF;
import org.apache.jena.vocabulary.RDFS;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import java.io.*;
import java.util.*;

/**
 * CIM OWL PARSER — Apache Jena, with CPSM ancestor resolution
 * ════════════════════════════════════════════════════════════════════
 *
 * ROOT CAUSE of empty ancestors:
 *
 *   In CPSM profile files, ACLineSegment's rdfs:subClassOf points to:
 *     http://iec.ch/TC57/CIM100#ACLineSegment
 *   Local name = "ACLineSegment" — same as the class itself.
 *   This is a CIM100 cross-namespace self-reference (CPSM restriction
 *   pattern), NOT the actual parent in the inheritance hierarchy.
 *
 *   The real chain:
 *     ACLineSegment → Conductor → ConductingEquipment → Equipment
 *                  → PowerSystemResource → IdentifiedObject
 *   is NOT declared in CPSM profile OWL files. It exists only in the
 *   full CIM17 OWL (iec61970cim17v40.owl).
 *
 * FIX — Two-level strategy:
 *
 *   Level 1: Parse parent from rdfs:subClassOf.
 *     If localName(subClassOf) == className → self-reference → skip.
 *     If localName(subClassOf) != className → use as parent normally.
 *
 *   Level 2: For classes with no parent found in the CPSM files,
 *     apply the BUILT-IN CIM17 CORE HIERARCHY as a fallback.
 *     This covers the complete Equipment branch which CPSM files
 *     never re-declare because they assume knowledge of CIM17.
 *
 *   Result: ACLineSegment gets full ancestor chain from the built-in map:
 *     [Conductor, ConductingEquipment, Equipment,
 *      PowerSystemResource, IdentifiedObject]
 */
@Component
public class CIMOwlParser {

    private static final Logger log = LoggerFactory.getLogger(CIMOwlParser.class);

    private static final String NS_UML = "http://langdale.com.au/2005/UML#";
    private static final Property PROP_HAS_STEREOTYPE =
            ResourceFactory.createProperty(NS_UML, "hasStereotype");

    private static final Set<String> PHYSICAL_STEREO =
            Set.of("byreference", "concrete", "Concrete");
    private static final Set<String> LOGICAL_STEREO  =
            Set.of("abstract","Abstract","Primitive","CIMDatatype",
                   "enumeration","Enumeration","Compound");

    // ── BUILT-IN CIM17 CORE HIERARCHY ─────────────────────────────────────
    // Used as fallback when CPSM files do not declare parent relationships.
    // CPSM profiles assume knowledge of the base CIM17 hierarchy — they only
    // declare CPSM-specific classes. Core Equipment branch must be supplied.
    private static final Map<String, String> CIM_CORE_PARENTS;

    static {
        Map<String, String> m = new LinkedHashMap<>();
        // ── Core Equipment hierarchy ───────────────────────────────────────
        m.put("IdentifiedObject",      null);
        m.put("PowerSystemResource",   "IdentifiedObject");
        m.put("Equipment",             "PowerSystemResource");
        m.put("ConductingEquipment",   "Equipment");
        m.put("Conductor",             "ConductingEquipment");
        m.put("ACLineSegment",         "Conductor");             // ← key fix
        m.put("DCLineSegment",         "Conductor");
        m.put("ACLineSegmentPhase",    "PowerSystemResource");

        // ── Switching ──────────────────────────────────────────────────────
        m.put("Switch",                "ConductingEquipment");
        m.put("ProtectedSwitch",       "Switch");
        m.put("Breaker",               "ProtectedSwitch");
        m.put("Recloser",              "ProtectedSwitch");
        m.put("LoadBreakSwitch",       "ProtectedSwitch");
        m.put("Fuse",                  "Switch");                // NOT ProtectedSwitch
        m.put("Disconnector",          "Switch");
        m.put("GroundDisconnector",    "Switch");
        m.put("Sectionaliser",         "Switch");
        m.put("Jumper",                "Switch");
        m.put("CompositeSwitch",       "Equipment");

        // ── Transformers ───────────────────────────────────────────────────
        m.put("PowerTransformer",      "ConductingEquipment");
        m.put("TransformerTank",       "Equipment");
        m.put("TransformerEnd",        "IdentifiedObject");
        m.put("PowerTransformerEnd",   "TransformerEnd");
        m.put("TransformerTankEnd",    "TransformerEnd");
        m.put("TapChanger",            "PowerSystemResource");
        m.put("RatioTapChanger",       "TapChanger");
        m.put("PhaseTapChangerLinear", "TapChanger");

        // ── Reactive ───────────────────────────────────────────────────────
        m.put("EnergyConnection",          "ConductingEquipment");
        m.put("RegulatingCondEq",          "EnergyConnection");
        m.put("ShuntCompensator",          "RegulatingCondEq");
        m.put("LinearShuntCompensator",    "ShuntCompensator");
        m.put("NonLinearShuntCompensator", "ShuntCompensator");
        m.put("StaticVarCompensator",      "RegulatingCondEq");
        m.put("SeriesCompensator",         "ConductingEquipment");

        // ── Generators ────────────────────────────────────────────────────
        m.put("RotatingMachine",           "RegulatingCondEq");
        m.put("SynchronousMachine",        "RotatingMachine");
        m.put("AsynchronousMachine",       "RotatingMachine");
        m.put("GeneratingUnit",            "Equipment");
        m.put("HydroGeneratingUnit",       "GeneratingUnit");
        m.put("ThermalGeneratingUnit",     "GeneratingUnit");
        m.put("WindGeneratingUnit",        "GeneratingUnit");
        m.put("NuclearGeneratingUnit",     "GeneratingUnit");
        m.put("SolarGeneratingUnit",       "GeneratingUnit");

        // ── DER ───────────────────────────────────────────────────────────
        m.put("PowerElectronicsConnection","RegulatingCondEq");
        m.put("PowerElectronicsUnit",      "Equipment");
        m.put("BatteryUnit",               "PowerElectronicsUnit");
        m.put("PhotoVoltaicUnit",          "PowerElectronicsUnit");
        m.put("PowerElectronicsWindUnit",  "PowerElectronicsUnit");

        // ── Loads ─────────────────────────────────────────────────────────
        m.put("EnergyConsumer",            "EnergyConnection");
        m.put("EnergyConsumerPhase",       "PowerSystemResource");
        m.put("ConformLoad",               "EnergyConsumer");
        m.put("NonConformLoad",            "EnergyConsumer");
        m.put("StationSupply",             "EnergyConsumer");

        // ── Containers ────────────────────────────────────────────────────
        m.put("ConnectivityNodeContainer", "PowerSystemResource");
        m.put("EquipmentContainer",        "ConnectivityNodeContainer");
        m.put("Line",                      "EquipmentContainer");
        m.put("Substation",                "EquipmentContainer");
        m.put("VoltageLevel",              "EquipmentContainer");
        m.put("Bay",                       "EquipmentContainer");
        m.put("Feeder",                    "EquipmentContainer");

        // ── Geography ─────────────────────────────────────────────────────
        m.put("GeographicalRegion",        "IdentifiedObject");
        m.put("SubGeographicalRegion",     "IdentifiedObject");
        m.put("BaseVoltage",               "IdentifiedObject");

        // ── Topology (LOGICAL) ────────────────────────────────────────────
        m.put("ConnectivityNode",          "IdentifiedObject");
        m.put("TopologicalNode",           "IdentifiedObject");
        m.put("TopologicalIsland",         "IdentifiedObject");
        m.put("Terminal",                  "ACDCTerminal");
        m.put("ACDCTerminal",              "IdentifiedObject");
        m.put("DCTerminal",                "ACDCTerminal");

        // ── Measurements (LOGICAL) ────────────────────────────────────────
        m.put("Measurement",               "IdentifiedObject");
        m.put("Accumulator",               "Measurement");
        m.put("Analog",                    "Measurement");
        m.put("Discrete",                  "Measurement");

        CIM_CORE_PARENTS = Collections.unmodifiableMap(m);
    }

    // ── Internal DTO ──────────────────────────────────────────────────────

    private static class ClassInfo {
        final String name, parentName, stereotype, description;
        ClassInfo(String n, String p, String s, String d) {
            name=n; parentName=p; stereotype=s; description=d;
        }
    }

    // ═══════════════════════════════════════════════════════════════════════
    // PUBLIC API
    // ═══════════════════════════════════════════════════════════════════════

    public List<CimClassDefinition> parse(InputStream in, String version)
            throws Exception {
        return parse(in, version, "uploaded.owl");
    }

    public List<CimClassDefinition> parse(InputStream in, String version,
                                           String fileName) throws Exception {
        log.info("Parsing OWL (Jena): '{}' version={}", fileName, version);
        long start = System.currentTimeMillis();
        Model model = ModelFactory.createDefaultModel();
        model.read(in, null, "RDF/XML");
        log.info("  Loaded {} triples", model.size());
        List<CimClassDefinition> defs = extractDefinitions(model, version);
        log.info("  {} classes ({} with attributes) in {}ms",
                defs.size(),
                defs.stream().filter(d -> !d.getOwnAttributes().isEmpty()).count(),
                System.currentTimeMillis() - start);
        return defs;
    }

    public List<CimClassDefinition> parseMultiple(
            Map<String, InputStream> streams, String version) throws Exception {

        log.info("Merging {} OWL files (version: {})", streams.size(), version);
        long start = System.currentTimeMillis();

        Model merged = ModelFactory.createDefaultModel();
        for (Map.Entry<String, InputStream> e : streams.entrySet()) {
            Model fm = ModelFactory.createDefaultModel();
            fm.read(e.getValue(), null, "RDF/XML");
            log.info("  Loaded {} triples from '{}'", fm.size(), e.getKey());
            merged.add(fm);
        }
        log.info("  Combined model: {} triples", merged.size());

        List<CimClassDefinition> defs = extractDefinitions(merged, version);
        log.info("Merge complete: {} classes ({} with attributes) in {}ms",
                defs.size(),
                defs.stream().filter(d -> !d.getOwnAttributes().isEmpty()).count(),
                System.currentTimeMillis() - start);
        return defs;
    }

    // ═══════════════════════════════════════════════════════════════════════
    // EXTRACTION
    // ═══════════════════════════════════════════════════════════════════════

    private List<CimClassDefinition> extractDefinitions(Model model, String version) {

        // ── 1. Find all classes ────────────────────────────────────────────
        Map<String, ClassInfo> classMap = new LinkedHashMap<>();

        model.listSubjectsWithProperty(RDF.type, OWL.Class)
             .forEachRemaining(r -> {
                 ClassInfo ci = extractClassInfo(r);
                 if (ci != null) classMap.putIfAbsent(ci.name, ci);
             });
        model.listSubjectsWithProperty(RDF.type, RDFS.Class)
             .forEachRemaining(r -> {
                 ClassInfo ci = extractClassInfo(r);
                 if (ci != null) classMap.putIfAbsent(ci.name, ci);
             });

        log.info("  Classes from OWL: {}", classMap.size());

        // ── 2. Attribute→class mappings via owl:Restriction ───────────────
        Map<String, List<String>> attrMap = new LinkedHashMap<>();

        model.listSubjectsWithProperty(RDF.type, OWL.Restriction)
             .forEachRemaining(restriction -> {
                 Statement onProp = restriction.getProperty(OWL.onProperty);
                 if (onProp == null) return;

                 String propLocal = localName(onProp.getObject().toString());
                 if (propLocal == null || !propLocal.contains(".")) return;

                 int    dot  = propLocal.lastIndexOf('.');
                 String cls  = propLocal.substring(0, dot);
                 String attr = propLocal.substring(dot + 1);
                 if (cls.isBlank() || attr.isBlank()) return;

                 // Add attribute to class — skip only exact duplicates
                 List<String> attrs = attrMap.computeIfAbsent(
                         cls, k -> new ArrayList<>());
                 if (!attrs.contains(attr)) {
                     attrs.add(attr);
                 }

                 // Ensure class entry exists
                 classMap.computeIfAbsent(cls,
                         k -> new ClassInfo(cls, null, null, null));
             });

        // ── 3. Build MERGED parent map ─────────────────────────────────────
        // Priority: OWL file data → CIM17 built-in fallback
        Map<String, String> parentMap = buildMergedParentMap(classMap);

        log.info("  Classes with parents resolved: {}",
                parentMap.size());
        log.info("  Parents from OWL: {}",
                classMap.values().stream()
                    .filter(ci -> ci.parentName != null).count());
        log.info("  Parents from CIM17 fallback: {}",
                parentMap.entrySet().stream()
                    .filter(e -> classMap.containsKey(e.getKey())
                         && classMap.get(e.getKey()).parentName == null)
                    .count());

        // ── 4. Build definitions ───────────────────────────────────────────
        List<CimClassDefinition> defs = new ArrayList<>();
        classMap.forEach((name, ci) -> {

            // Deduplicated attribute list
            List<String> attrs = new ArrayList<>();
            List<String> raw   = attrMap.get(name);
            if (raw != null) {
                for (String a : raw) if (!attrs.contains(a)) attrs.add(a);
            }

            CimClassDefinition def = new CimClassDefinition(
                    name,
                    parentMap.get(name),
                    computeAncestors(name, parentMap),
                    attrs,
                    determineCategory(ci.stereotype),
                    version);
            def.setCimPackage("Core");
            def.setDescription(ci.description);
            defs.add(def);
        });

        return defs;
    }

    // ── Build merged parent map ────────────────────────────────────────────

    /**
     * Builds the parent map used for ancestor chain computation.
     *
     * Merge strategy:
     *   1. Start with built-in CIM17 core hierarchy (covers all base classes)
     *   2. Override/add with data from the OWL file (CPSM-specific subclasses)
     *   3. Skip self-references (CPSM pattern: subClassOf → same local name)
     *
     * This ensures ACLineSegment always gets:
     *   [Conductor, ConductingEquipment, Equipment, PowerSystemResource, IdentifiedObject]
     * even though CPSM files don't declare these relationships.
     */
    private Map<String, String> buildMergedParentMap(
            Map<String, ClassInfo> classMap) {

        // Start with built-in CIM17 hierarchy
        Map<String, String> parentMap = new LinkedHashMap<>(CIM_CORE_PARENTS);

        // Apply OWL-declared parents (override built-in only if not self-ref)
        classMap.forEach((name, ci) -> {
            if (ci.parentName != null && !ci.parentName.equals(name)) {
                // OWL-declared parent is valid — use it
                parentMap.put(name, ci.parentName);
            }
            // If ci.parentName == name → CPSM self-reference → keep built-in
            // If ci.parentName == null → no OWL parent → keep built-in if exists
        });

        return parentMap;
    }

    // ── Extract ClassInfo from one Jena Resource ──────────────────────────

    private ClassInfo extractClassInfo(Resource resource) {
        // Class name — from rdfs:label (CPSM) or URI local name (full OWL)
        String name = null;
        Statement labelStmt = resource.getProperty(RDFS.label);
        if (labelStmt != null) name = labelStmt.getString().trim();
        if ((name == null || name.isBlank()) && resource.isURIResource()) {
            name = localName(resource.getURI());
        }
        if (name == null || name.isBlank()) return null;

        // Parent — from rdfs:subClassOf (skip if same as class name = self-ref)
        String parentName = null;
        Statement subStmt = resource.getProperty(RDFS.subClassOf);
        if (subStmt != null) {
            RDFNode parent = subStmt.getObject();
            if (parent.isURIResource()) {
                String pLocal = localName(parent.asResource().getURI());
                // Skip self-references and owl:Thing
                if (pLocal != null && !pLocal.equals(name)
                        && !"Thing".equals(pLocal)) {
                    parentName = pLocal;
                }
            } else if (parent.isResource()) {
                Statement pl = parent.asResource().getProperty(RDFS.label);
                if (pl != null) {
                    String pLabel = pl.getString().trim();
                    if (!pLabel.equals(name)) parentName = pLabel;
                }
            }
        }

        // Stereotype — from uml:hasStereotype
        String stereotype = null;
        Statement stereoStmt = resource.getProperty(PROP_HAS_STEREOTYPE);
        if (stereoStmt != null) {
            RDFNode node = stereoStmt.getObject();
            stereotype = node.isURIResource()
                    ? localName(node.asResource().getURI())
                    : node.asLiteral().getString().trim();
        }

        // Description — from rdfs:comment
        String description = null;
        Statement commentStmt = resource.getProperty(RDFS.comment);
        if (commentStmt != null) description = commentStmt.getString().trim();

        return new ClassInfo(name, parentName, stereotype, description);
    }

    // ── Helpers ────────────────────────────────────────────────────────────

    private List<String> computeAncestors(String cls, Map<String, String> parentMap) {
        List<String> chain   = new ArrayList<>();
        Set<String>  visited = new HashSet<>();
        String       cur     = parentMap.get(cls);
        while (cur != null && !visited.contains(cur)) {
            chain.add(cur);
            visited.add(cur);
            cur = parentMap.get(cur);
        }
        return chain;
    }

    private String determineCategory(String stereotype) {
        if (stereotype != null) {
            if (PHYSICAL_STEREO.contains(stereotype)) return "PHYSICAL";
            if (LOGICAL_STEREO.contains(stereotype))  return "LOGICAL";
        }
        return "PHYSICAL";
    }

    String localName(String uri) {
        if (uri == null || uri.isBlank()) return null;
        int idx = Math.max(uri.lastIndexOf('#'), uri.lastIndexOf('/'));
        return (idx >= 0 && idx < uri.length() - 1)
                ? uri.substring(idx + 1) : uri;
    }
}

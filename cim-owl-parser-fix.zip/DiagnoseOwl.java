import javax.xml.stream.*;
import java.io.*;
import java.util.*;

/**
 * Standalone diagnostic — run against your CPSM OWL file to print
 * every unique element name + namespace found in the file.
 * This tells us exactly what the parser needs to match.
 *
 * Usage:
 *   javac DiagnoseOwl.java
 *   java DiagnoseOwl /path/to/CPSM-CoreEquipment.owl
 */
public class DiagnoseOwl {
    public static void main(String[] args) throws Exception {
        String path = args.length > 0 ? args[0] : "CPSM-CoreEquipment.owl";
        System.out.println("Diagnosing: " + path);
        System.out.println("=".repeat(60));

        XMLInputFactory factory = XMLInputFactory.newInstance();
        factory.setProperty(XMLInputFactory.IS_SUPPORTING_EXTERNAL_ENTITIES, false);
        factory.setProperty(XMLInputFactory.SUPPORT_DTD, false);

        XMLStreamReader reader = factory.createXMLStreamReader(
                new BufferedInputStream(new FileInputStream(path), 64*1024));

        // Track unique elements with their namespaces
        Map<String, Set<String>> elementsByNs = new LinkedHashMap<>();
        // Track all namespace declarations
        Set<String> namespaces = new LinkedHashSet<>();
        // Track first 5 elements at depth 1 and 2
        int depth = 0;
        int classCount = 0;
        int propCount = 0;
        List<String> firstTopLevel = new ArrayList<>();

        while (reader.hasNext()) {
            int event = reader.next();
            if (event == XMLStreamConstants.START_ELEMENT) {
                depth++;
                String ns = reader.getNamespaceURI() != null
                          ? reader.getNamespaceURI() : "(no namespace)";
                String local = reader.getLocalName();
                String prefix = reader.getPrefix() != null ? reader.getPrefix() : "";

                // Collect namespaces from namespace declarations
                for (int i = 0; i < reader.getNamespaceCount(); i++) {
                    String nUri = reader.getNamespaceURI(i);
                    if (nUri != null) namespaces.add(nUri);
                }

                elementsByNs.computeIfAbsent(ns, k -> new LinkedHashSet<>()).add(local);

                if (depth == 1) {
                    System.out.println("ROOT element:");
                    System.out.println("  local: " + local);
                    System.out.println("  ns:    " + ns);
                    System.out.println("  prefix:" + prefix);
                    System.out.println("  Declared namespaces on root:");
                    for (int i = 0; i < reader.getNamespaceCount(); i++) {
                        System.out.println("    " + reader.getNamespacePrefix(i)
                                + " = " + reader.getNamespaceURI(i));
                    }
                }
                if (depth == 2 && firstTopLevel.size() < 10) {
                    String attrAbout = reader.getAttributeValue(
                            "http://www.w3.org/1999/02/22-rdf-syntax-ns#", "about");
                    String attrID = reader.getAttributeValue(
                            "http://www.w3.org/1999/02/22-rdf-syntax-ns#", "ID");
                    firstTopLevel.add(
                        String.format("  [%s] prefix='%s' ns='%s' rdf:about='%s' rdf:ID='%s'",
                            local, prefix, ns,
                            attrAbout != null ? attrAbout : "(none)",
                            attrID    != null ? attrID    : "(none)"));
                }

                // Count potential class/property elements
                if (local.equals("Class"))    classCount++;
                if (local.equals("Description")) classCount++;  // some OWLs use rdfs:Description
                if (local.equals("DatatypeProperty") || local.equals("ObjectProperty")
                        || local.equals("Property")) propCount++;

            } else if (event == XMLStreamConstants.END_ELEMENT) {
                depth--;
            }
        }
        reader.close();

        System.out.println("\nFirst 10 top-level elements (depth=2):");
        firstTopLevel.forEach(System.out::println);

        System.out.println("\nAll namespaces found:");
        namespaces.forEach(ns -> System.out.println("  " + ns));

        System.out.println("\nAll element local names by namespace:");
        elementsByNs.forEach((ns, els) ->
            System.out.println("  [" + ns + "]\n    " + els));

        System.out.println("\nClass elements found:    " + classCount);
        System.out.println("Property elements found: " + propCount);
    }
}

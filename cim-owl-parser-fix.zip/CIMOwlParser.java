package com.cim.service;

import com.cim.model.mongo.CimClassDefinition;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import javax.xml.stream.*;
import java.io.*;
import java.util.*;

/**
 * CIM OWL FILE PARSER — handles all known CPSM/CIM OWL structures
 * ════════════════════════════════════════════════════════════════════
 *
 * CPSM OWL files (CoreEquipment, Operation, ShortCircuit) use a
 * different RDF serialization than the full CIM17 OWL. This parser
 * handles all observed variants:
 *
 * VARIANT A — Standard OWL (full CIM17 OWL):
 *   <owl:Class rdf:about="...#ACLineSegment">
 *     <rdfs:subClassOf rdf:resource="...#Conductor"/>
 *   </owl:Class>
 *
 * VARIANT B — rdfs:Class (some CPSM profiles):
 *   <rdfs:Class rdf:about="...#ACLineSegment">
 *     <rdfs:subClassOf rdf:resource="...#Conductor"/>
 *   </rdfs:Class>
 *
 * VARIANT C — rdf:Description (legacy RDFS style):
 *   <rdf:Description rdf:about="...#ACLineSegment">
 *     <rdf:type rdf:resource="...#Class"/>
 *     <rdfs:subClassOf rdf:resource="...#Conductor"/>
 *   </rdf:Description>
 *
 * VARIANT D — Typed node with rdf:type inline attribute:
 *   <rdf:Description rdf:about="...#ACLineSegment"
 *       rdf:type="http://www.w3.org/2002/07/owl#Class">
 *     <rdfs:subClassOf rdf:resource="...#Conductor"/>
 *   </rdf:Description>
 *
 * VARIANT E — Property as rdf:Description with type:
 *   <rdf:Description rdf:about="...#ACLineSegment.r">
 *     <rdf:type rdf:resource="...#DatatypeProperty"/>
 *     <rdfs:domain rdf:resource="...#ACLineSegment"/>
 *   </rdf:Description>
 */
@Component
public class CIMOwlParser {

    private static final Logger log = LoggerFactory.getLogger(CIMOwlParser.class);

    // ── Known namespace URIs ───────────────────────────────────────────────
    private static final String NS_RDF  = "http://www.w3.org/1999/02/22-rdf-syntax-ns#";
    private static final String NS_RDFS = "http://www.w3.org/2000/01/rdf-schema#";
    private static final String NS_OWL  = "http://www.w3.org/2002/07/owl#";

    // cims namespace has multiple known URI variants across CIM versions
    private static final Set<String> NS_CIMS_VARIANTS = Set.of(
        "http://iec.ch/TC57/1999/rdf-schema-extensions-19990926#",
        "http://iec.ch/TC57/NonStandard/UML#",
        "http://www.iec.ch/TC57/CIM-generic#",
        "http://iec.ch/TC57/2013/CIM-schema-cim16#",
        "http://iec.ch/TC57/2013/CIM-schema-cim17#"
    );

    // OWL type URIs that mean "this rdf:Description IS a class"
    private static final Set<String> CLASS_TYPE_URIS = Set.of(
        "http://www.w3.org/2002/07/owl#Class",
        "http://www.w3.org/2000/01/rdf-schema#Class",
        "http://www.w3.org/2002/07/owl#NamedIndividual"
    );

    // OWL type URIs that mean "this rdf:Description IS a property"
    private static final Set<String> PROPERTY_TYPE_URIS = Set.of(
        "http://www.w3.org/2002/07/owl#DatatypeProperty",
        "http://www.w3.org/2002/07/owl#ObjectProperty",
        "http://www.w3.org/1999/02/22-rdf-syntax-ns#Property",
        "http://www.w3.org/2002/07/owl#AnnotationProperty"
    );

    private static final Set<String> LOGICAL_STEREOTYPES =
            Set.of("abstract", "Primitive", "CIMDatatype", "enumeration", "Compound");

    private static final Set<String> LOGICAL_PACKAGES =
            Set.of("Topology", "Meas", "StateVariables", "LoadModel", "Contingency",
                    "InfWork", "InfAssets", "InfLocations", "InfOperations",
                    "IEC61968CIMVersion", "IEC61970CIMVersion");

    // ── Internal model ─────────────────────────────────────────────────────

    private static class ClassEntry {
        final String       name;
        String             parentUri;
        String             packageName;
        String             stereotype;
        String             description;
        String             sourceFile;
        List<String>       ownAttributes = new ArrayList<>();

        ClassEntry(String name) { this.name = name; }
    }

    // ═══════════════════════════════════════════════════════════════════════
    // PUBLIC API
    // ═══════════════════════════════════════════════════════════════════════

    public List<CimClassDefinition> parse(InputStream owlStream,
                                           String cimVersion) throws Exception {
        return parse(owlStream, cimVersion, "uploaded-owl");
    }

    public List<CimClassDefinition> parse(InputStream owlStream,
                                           String cimVersion,
                                           String fileName) throws Exception {
        log.info("Parsing OWL: '{}' version={}", fileName, cimVersion);
        long start = System.currentTimeMillis();

        Map<String, ClassEntry>   classes   = new LinkedHashMap<>();
        Map<String, List<String>> domainMap = new LinkedHashMap<>();

        parseOwlStream(owlStream, fileName, classes, domainMap);
        List<CimClassDefinition> defs =
                buildDefinitions(classes, domainMap, cimVersion, start);

        log.info("Parsed '{}': {} classes, {} property domains",
                fileName, classes.size(), domainMap.size());
        return defs;
    }

    public List<CimClassDefinition> parseMultiple(
            Map<String, InputStream> owlStreams,
            String cimVersion) throws Exception {

        log.info("Merging {} OWL profile files for version: {}",
                owlStreams.size(), cimVersion);
        long start = System.currentTimeMillis();

        Map<String, ClassEntry>   classes   = new LinkedHashMap<>();
        Map<String, List<String>> domainMap = new LinkedHashMap<>();

        int idx = 0;
        for (Map.Entry<String, InputStream> entry : owlStreams.entrySet()) {
            idx++;
            String fileName = entry.getKey();
            int beforeClasses = classes.size();
            int beforeDomains = domainMap.size();

            log.info("  [{}/{}] Parsing: {}", idx, owlStreams.size(), fileName);
            parseOwlStream(entry.getValue(), fileName, classes, domainMap);

            log.info("  [{}/{}] Added {} classes, {} property domains. Total: {}",
                    idx, owlStreams.size(),
                    classes.size() - beforeClasses,
                    domainMap.size() - beforeDomains,
                    classes.size());
        }

        List<CimClassDefinition> defs =
                buildDefinitions(classes, domainMap, cimVersion, start);

        log.info("Multi-profile merge complete: {} total classes from {} files",
                defs.size(), owlStreams.size());
        return defs;
    }

    // ═══════════════════════════════════════════════════════════════════════
    // CORE STAX PARSER — handles all 5 CPSM/CIM OWL variants
    // ═══════════════════════════════════════════════════════════════════════

    private void parseOwlStream(InputStream               owlStream,
                                 String                    fileName,
                                 Map<String, ClassEntry>   classes,
                                 Map<String, List<String>> domainMap) throws Exception {

        XMLInputFactory factory = XMLInputFactory.newInstance();
        factory.setProperty(XMLInputFactory.IS_SUPPORTING_EXTERNAL_ENTITIES, false);
        factory.setProperty(XMLInputFactory.SUPPORT_DTD, false);
        factory.setProperty(XMLInputFactory.IS_COALESCING, true);

        XMLStreamReader reader = factory.createXMLStreamReader(
                new BufferedInputStream(owlStream, 64 * 1024));

        // ── Parser state ──────────────────────────────────────────────────
        String        currentUri      = null;  // rdf:about of current element
        String        currentKind     = null;  // "CLASS", "PROPERTY", or null
        ClassEntry    currentClass    = null;
        String        currentPropName = null;
        String        currentDomain   = null;
        StringBuilder textBuf         = new StringBuilder(256);

        // For rdf:Description blocks, we may need to defer kind detection
        // until we see rdf:type inside the element
        boolean       inDescription   = false;
        String        pendingUri       = null; // uri of pending rdf:Description
        int           depth            = 0;

        try {
            while (reader.hasNext()) {
                int event = reader.next();

                switch (event) {

                    // ── OPEN TAG ───────────────────────────────────────────
                    case XMLStreamConstants.START_ELEMENT -> {
                        depth++;
                        String ns    = reader.getNamespaceURI();
                        String local = reader.getLocalName();
                        textBuf.setLength(0);

                        if (depth == 2) {
                            // ── Top-level element ──────────────────────────
                            // Reset state for each new top-level element
                            currentUri      = null;
                            currentKind     = null;
                            currentClass    = null;
                            currentPropName = null;
                            currentDomain   = null;
                            inDescription   = false;
                            pendingUri      = null;

                            String about = reader.getAttributeValue(NS_RDF, "about");
                            if (about == null) about = reader.getAttributeValue(NS_RDF, "ID");
                            currentUri = about;

                            // ── VARIANT A & B: owl:Class or rdfs:Class ─────
                            if ("Class".equals(local)
                                    && (isOwl(ns) || isRdfs(ns) || isRdf(ns))) {
                                currentKind  = "CLASS";
                                currentClass = registerClass(currentUri, fileName, classes);
                            }

                            // ── VARIANT A: owl:DatatypeProperty etc. ───────
                            else if (("DatatypeProperty".equals(local)
                                        || "ObjectProperty".equals(local)
                                        || "AnnotationProperty".equals(local))
                                    && (isOwl(ns) || isRdf(ns))) {
                                currentKind     = "PROPERTY";
                                currentPropName = propertyLocalName(currentUri);
                            }

                            // ── VARIANT C/D/E: rdf:Description (deferred) ──
                            else if ("Description".equals(local) && isRdf(ns)) {
                                inDescription = true;
                                pendingUri    = currentUri;
                            }

                            // Also check for inline rdf:type attribute on
                            // any top-level element (VARIANT D)
                            String typeAttr = reader.getAttributeValue(NS_RDF, "type");
                            if (typeAttr != null) {
                                resolveDescriptionType(typeAttr, pendingUri != null
                                        ? pendingUri : currentUri,
                                        fileName, classes, domainMap);
                            }
                        }

                        // ── DEPTH 3: child elements ────────────────────────
                        else if (depth == 3) {

                            // ── rdf:type inside rdf:Description (VARIANT C) ─
                            if ("type".equals(local) && isRdf(ns) && inDescription) {
                                String typeRef = reader.getAttributeValue(NS_RDF, "resource");
                                if (typeRef != null) {
                                    String resolved = resolveDescriptionType(
                                            typeRef, pendingUri,
                                            fileName, classes, domainMap);
                                    if (resolved != null) {
                                        currentKind     = resolved;
                                        currentUri      = pendingUri;
                                        if ("CLASS".equals(currentKind)) {
                                            currentClass = classes.get(localName(pendingUri));
                                        } else if ("PROPERTY".equals(currentKind)) {
                                            currentPropName = propertyLocalName(pendingUri);
                                        }
                                    }
                                }
                            }

                            // ── rdfs:subClassOf ────────────────────────────
                            if ("subClassOf".equals(local) && isRdfs(ns)
                                    && currentClass != null) {
                                String ref = reader.getAttributeValue(NS_RDF, "resource");
                                if (ref != null && !ref.isBlank()
                                        && currentClass.parentUri == null) {
                                    currentClass.parentUri = ref;
                                }
                            }

                            // ── cims:belongsToCategory ─────────────────────
                            if ("belongsToCategory".equals(local) && isCims(ns)
                                    && currentClass != null) {
                                String ref = reader.getAttributeValue(NS_RDF, "resource");
                                if (ref != null && currentClass.packageName == null) {
                                    currentClass.packageName = localName(ref);
                                }
                            }

                            // ── rdfs:domain (property declares its class) ──
                            if ("domain".equals(local) && isRdfs(ns)
                                    && "PROPERTY".equals(currentKind)) {
                                String ref = reader.getAttributeValue(NS_RDF, "resource");
                                if (ref != null) {
                                    currentDomain = localName(ref);
                                }
                            }
                        }
                    }

                    // ── TEXT ───────────────────────────────────────────────
                    case XMLStreamConstants.CHARACTERS,
                         XMLStreamConstants.CDATA ->
                            textBuf.append(reader.getText());

                    // ── CLOSE TAG ──────────────────────────────────────────
                    case XMLStreamConstants.END_ELEMENT -> {
                        String ns    = reader.getNamespaceURI();
                        String local = reader.getLocalName();
                        String text  = textBuf.toString().trim();

                        // ── Text inside class element ──────────────────────
                        if ("CLASS".equals(currentKind) && currentClass != null) {
                            if ("comment".equals(local) && isRdfs(ns)
                                    && !text.isEmpty()
                                    && currentClass.description == null) {
                                currentClass.description = text;
                            }
                            if ("stereotype".equals(local) && isCims(ns)
                                    && !text.isEmpty()
                                    && currentClass.stereotype == null) {
                                currentClass.stereotype = text;
                            }
                            // label as fallback for class name
                            if ("label".equals(local) && isRdfs(ns)
                                    && !text.isEmpty()
                                    && currentClass.name.contains("#")) {
                                // If name is a full URI, update to label text
                                // (some CPSM files use full URI as name)
                            }
                        }

                        // ── Close top-level element ────────────────────────
                        if (depth == 2) {
                            // Register property domain if we have one
                            if ("PROPERTY".equals(currentKind)
                                    && currentDomain != null
                                    && currentPropName != null
                                    && !currentPropName.isBlank()) {
                                domainMap
                                    .computeIfAbsent(currentDomain,
                                            k -> new ArrayList<>())
                                    .add(currentPropName);
                            }
                            // Reset all state
                            currentUri      = null;
                            currentKind     = null;
                            currentClass    = null;
                            currentPropName = null;
                            currentDomain   = null;
                            inDescription   = false;
                            pendingUri      = null;
                        }

                        depth--;
                        textBuf.setLength(0);
                    }
                }
            }
        } finally {
            reader.close();
        }
    }

    // ── rdf:Description type resolver ─────────────────────────────────────

    /**
     * Given a rdf:type URI from a rdf:Description block,
     * determines if it is a CLASS or PROPERTY declaration.
     * Returns "CLASS", "PROPERTY", or null.
     */
    private String resolveDescriptionType(String typeUri,
                                           String aboutUri,
                                           String fileName,
                                           Map<String, ClassEntry>   classes,
                                           Map<String, List<String>> domainMap) {
        if (typeUri == null) return null;

        if (CLASS_TYPE_URIS.contains(typeUri)) {
            registerClass(aboutUri, fileName, classes);
            return "CLASS";
        }
        if (PROPERTY_TYPE_URIS.contains(typeUri)) {
            return "PROPERTY";
        }
        return null;
    }

    /** Registers a new ClassEntry if not already present. Returns the entry. */
    private ClassEntry registerClass(String uri, String fileName,
                                      Map<String, ClassEntry> classes) {
        if (uri == null) return null;
        String name = localName(uri);
        if (name == null || name.isBlank()) return null;

        ClassEntry entry = classes.computeIfAbsent(name, ClassEntry::new);
        if (entry.sourceFile == null) entry.sourceFile = fileName;
        return entry;
    }

    // ═══════════════════════════════════════════════════════════════════════
    // BUILD DEFINITIONS
    // ═══════════════════════════════════════════════════════════════════════

    private List<CimClassDefinition> buildDefinitions(
            Map<String, ClassEntry>   classes,
            Map<String, List<String>> domainMap,
            String                    cimVersion,
            long                      startMs) {

        // Attach attributes (additive, no duplicates)
        domainMap.forEach((className, attrs) -> {
            ClassEntry entry = classes.get(className);
            if (entry != null) {
                for (String attr : attrs) {
                    if (!entry.ownAttributes.contains(attr)) {
                        entry.ownAttributes.add(attr);
                    }
                }
            }
        });

        // Build parent map
        Map<String, String> parentMap = new LinkedHashMap<>();
        classes.forEach((name, entry) -> {
            if (entry.parentUri != null) {
                String parentName = localName(entry.parentUri);
                if (parentName != null && !parentName.equals(name)) {
                    parentMap.put(name, parentName);
                }
            }
        });

        // Build definitions
        List<CimClassDefinition> defs = new ArrayList<>();
        classes.forEach((name, entry) -> {
            CimClassDefinition def = new CimClassDefinition(
                    name,
                    parentMap.get(name),
                    computeAncestors(name, parentMap),
                    new ArrayList<>(entry.ownAttributes),
                    determineCategory(entry),
                    cimVersion);
            def.setCimPackage(entry.packageName != null ? entry.packageName : "Core");
            def.setDescription(entry.description);
            defs.add(def);
        });

        log.info("Build complete: {} classes in {}ms",
                defs.size(), System.currentTimeMillis() - startMs);
        return defs;
    }

    // ── Helpers ────────────────────────────────────────────────────────────

    private List<String> computeAncestors(String cls, Map<String, String> parentMap) {
        List<String> chain   = new ArrayList<>();
        Set<String>  visited = new HashSet<>();
        String       cur     = parentMap.get(cls);
        while (cur != null && !visited.contains(cur)) {
            chain.add(cur);
            visited.add(cur);
            cur = parentMap.get(cur);
        }
        return chain;
    }

    private String determineCategory(ClassEntry entry) {
        if (entry.stereotype != null
                && LOGICAL_STEREOTYPES.contains(entry.stereotype)) return "LOGICAL";
        if (entry.packageName != null
                && LOGICAL_PACKAGES.contains(entry.packageName)) return "LOGICAL";
        if (entry.name != null) {
            String n = entry.name;
            if (n.endsWith("Value") || n.endsWith("Schedule") || n.endsWith("Island")
                    || n.endsWith("Node") || n.equals("Terminal")
                    || n.equals("ACDCTerminal") || n.equals("DCTerminal")
                    || n.endsWith("Type") || n.endsWith("Kind")) {
                return "LOGICAL";
            }
        }
        return "PHYSICAL";
    }

    private boolean isOwl(String ns)  { return NS_OWL.equals(ns); }
    private boolean isRdf(String ns)  { return NS_RDF.equals(ns); }
    private boolean isRdfs(String ns) { return NS_RDFS.equals(ns); }

    private boolean isCims(String ns) {
        if (ns == null) return false;
        if (NS_CIMS_VARIANTS.contains(ns)) return true;
        return ns.contains("rdf-schema-extensions")
            || ns.contains("TC57/NonStandard")
            || ns.contains("CIM-generic");
    }

    /** "http://iec.ch/...#ACLineSegment" → "ACLineSegment" */
    String localName(String uri) {
        if (uri == null) return null;
        int idx = Math.max(uri.lastIndexOf('#'), uri.lastIndexOf('/'));
        return (idx >= 0 && idx < uri.length() - 1)
                ? uri.substring(idx + 1) : uri;
    }

    /** "...#ACLineSegment.r" → "r"  |  "...#ACLineSegment" → "ACLineSegment" */
    private String propertyLocalName(String uri) {
        String local = localName(uri);
        if (local == null) return null;
        int dot = local.lastIndexOf('.');
        return (dot >= 0 && dot < local.length() - 1)
                ? local.substring(dot + 1) : local;
    }
}

package com.cim.controller;

import com.cim.model.mongo.CimObjectRecord;
import com.cim.repository.CimObjectRecordRepository;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.BulkOperations;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.data.mongodb.core.query.Update;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.*;

/**
 * REST API for managing isRequired flag on CIM objects.
 *
 * ── Single object ──────────────────────────────────────────────────
 *
 *   GET  /api/objects/{id}/required
 *        Get current isRequired value for one object
 *
 *   PATCH /api/objects/{id}/required?value=true
 *   PATCH /api/objects/{id}/required?value=false
 *        Change isRequired for one specific object
 *
 * ── Bulk by job ────────────────────────────────────────────────────
 *
 *   PATCH /api/jobs/{jobId}/objects/required?value=true
 *        Set ALL objects in job to isRequired=true
 *
 *   PATCH /api/jobs/{jobId}/objects/required?value=false
 *        Set ALL objects in job to isRequired=false
 *
 *   PATCH /api/jobs/{jobId}/objects/required?category=PHYSICAL&value=true
 *        Set only PHYSICAL objects to isRequired=true
 *
 *   PATCH /api/jobs/{jobId}/objects/required?category=LOGICAL&value=true
 *        Set only LOGICAL objects to isRequired=true
 *
 *   PATCH /api/jobs/{jobId}/objects/required?cimType=Terminal&value=true
 *        Set all Terminal objects to isRequired=true
 *
 * ── Query by isRequired ────────────────────────────────────────────
 *
 *   GET /api/jobs/{jobId}/objects?required=true
 *       Get all required objects for a job
 *
 *   GET /api/jobs/{jobId}/objects/required/summary
 *       Get count of required vs not-required per type
 */
@RestController
@RequestMapping("/api")
@CrossOrigin(origins = "*")
public class ObjectRequiredController {

    private final CimObjectRecordRepository objectRepo;
    private final MongoTemplate             mongoTemplate;

    public ObjectRequiredController(CimObjectRecordRepository objectRepo,
                                     MongoTemplate mongoTemplate) {
        this.objectRepo    = objectRepo;
        this.mongoTemplate = mongoTemplate;
    }

    // ─────────────────────────────────────────────────────────────────
    // GET /api/objects/{id}/required
    // Get current isRequired for one object
    // ─────────────────────────────────────────────────────────────────
    @GetMapping("/objects/{id}/required")
    public ResponseEntity<?> getRequired(@PathVariable String id) {
        return objectRepo.findById(id)
                .map(obj -> ResponseEntity.ok(Map.of(
                    "id",         obj.getId(),
                    "rdfId",      obj.getRdfId(),
                    "cimType",    obj.getCimType(),
                    "name",       obj.getName() != null ? obj.getName() : "",
                    "category",   obj.getCategory(),
                    "isRequired", obj.isRequired()
                )))
                .orElse(ResponseEntity.notFound().build());
    }

    // ─────────────────────────────────────────────────────────────────
    // PATCH /api/objects/{id}/required?value=true
    // Change isRequired for ONE specific object
    //
    // Example:
    //   curl -X PATCH "http://localhost:8080/api/objects/{id}/required?value=false"
    // ─────────────────────────────────────────────────────────────────
    @PatchMapping("/objects/{id}/required")
    public ResponseEntity<?> setRequired(@PathVariable String id,
                                          @RequestParam boolean value) {
        return objectRepo.findById(id)
                .map(obj -> {
                    boolean oldValue = obj.isRequired();
                    obj.setRequired(value);
                    objectRepo.save(obj);
                    return ResponseEntity.ok(Map.of(
                        "id",         obj.getId(),
                        "rdfId",      obj.getRdfId(),
                        "cimType",    obj.getCimType(),
                        "name",       obj.getName() != null ? obj.getName() : "",
                        "category",   obj.getCategory(),
                        "isRequired", obj.isRequired(),
                        "changed",    oldValue != value,
                        "message",    "isRequired changed from " + oldValue
                                    + " to " + value
                    ));
                })
                .orElse(ResponseEntity.notFound().build());
    }

    // ─────────────────────────────────────────────────────────────────
    // PATCH /api/jobs/{jobId}/objects/required?value=true
    // PATCH /api/jobs/{jobId}/objects/required?value=true&category=PHYSICAL
    // PATCH /api/jobs/{jobId}/objects/required?value=true&cimType=Terminal
    //
    // Bulk update — MongoDB BulkWrite, one round trip
    //
    // Examples:
    //   All objects required:
    //     PATCH /api/jobs/{id}/objects/required?value=true
    //
    //   Only LOGICAL objects set to required:
    //     PATCH /api/jobs/{id}/objects/required?category=LOGICAL&value=true
    //
    //   All Terminals set to required:
    //     PATCH /api/jobs/{id}/objects/required?cimType=Terminal&value=true
    //
    //   Reset all to default (PHYSICAL=true, LOGICAL=false):
    //     PATCH /api/jobs/{id}/objects/required/reset
    // ─────────────────────────────────────────────────────────────────
    @PatchMapping("/jobs/{jobId}/objects/required")
    public ResponseEntity<?> bulkSetRequired(
            @PathVariable String jobId,
            @RequestParam boolean value,
            @RequestParam(required = false) String category,
            @RequestParam(required = false) String cimType) {

        // Build the filter criteria
        Criteria criteria = Criteria.where("jobId").is(jobId);

        if (category != null && !category.isBlank()) {
            criteria = criteria.and("category").is(category.toUpperCase());
        }
        if (cimType != null && !cimType.isBlank()) {
            criteria = criteria.and("cimType").is(cimType);
        }

        // Count how many will be affected
        long totalMatching = mongoTemplate.count(
                new Query(criteria), "cim_objects");

        if (totalMatching == 0) {
            return ResponseEntity.ok(Map.of(
                "message",  "No objects matched the filter.",
                "jobId",    jobId,
                "category", category != null ? category : "ALL",
                "cimType",  cimType  != null ? cimType  : "ALL",
                "updated",  0
            ));
        }

        // Bulk update — single MongoDB round trip
        Query  query  = new Query(criteria);
        Update update = new Update().set("isRequired", value);
        var result = mongoTemplate.updateMulti(query, update, "cim_objects");

        return ResponseEntity.ok(Map.of(
            "message",  "isRequired updated to " + value,
            "jobId",    jobId,
            "category", category != null ? category : "ALL",
            "cimType",  cimType  != null ? cimType  : "ALL",
            "value",    value,
            "updated",  result.getModifiedCount()
        ));
    }

    // ─────────────────────────────────────────────────────────────────
    // PATCH /api/jobs/{jobId}/objects/required/reset
    // Reset ALL objects to default:
    //   PHYSICAL → isRequired = true
    //   LOGICAL  → isRequired = false
    // ─────────────────────────────────────────────────────────────────
    @PatchMapping("/jobs/{jobId}/objects/required/reset")
    public ResponseEntity<?> resetToDefault(@PathVariable String jobId) {

        // Set PHYSICAL → true
        Query physicalQuery = new Query(
                Criteria.where("jobId").is(jobId)
                        .and("category").is("PHYSICAL"));
        long physicalUpdated = mongoTemplate.updateMulti(
                physicalQuery,
                new Update().set("isRequired", true),
                "cim_objects").getModifiedCount();

        // Set LOGICAL → false
        Query logicalQuery = new Query(
                Criteria.where("jobId").is(jobId)
                        .and("category").is("LOGICAL"));
        long logicalUpdated = mongoTemplate.updateMulti(
                logicalQuery,
                new Update().set("isRequired", false),
                "cim_objects").getModifiedCount();

        return ResponseEntity.ok(Map.of(
            "message",          "isRequired reset to defaults",
            "jobId",            jobId,
            "physicalSetTrue",  physicalUpdated,
            "logicalSetFalse",  logicalUpdated,
            "total",            physicalUpdated + logicalUpdated
        ));
    }

    // ─────────────────────────────────────────────────────────────────
    // GET /api/jobs/{jobId}/objects/required/summary
    // Summary: how many required vs not-required, broken down by type
    // ─────────────────────────────────────────────────────────────────
    @GetMapping("/jobs/{jobId}/objects/required/summary")
    public ResponseEntity<?> getRequiredSummary(@PathVariable String jobId) {

        long totalRequired = objectRepo.countByJobIdAndIsRequired(jobId, true);
        long totalNotRequired = objectRepo.countByJobIdAndIsRequired(jobId, false);
        long total = totalRequired + totalNotRequired;

        // Breakdown by category
        long physicalRequired    = mongoTemplate.count(
                new Query(Criteria.where("jobId").is(jobId)
                        .and("category").is("PHYSICAL")
                        .and("isRequired").is(true)), "cim_objects");
        long physicalNotRequired = mongoTemplate.count(
                new Query(Criteria.where("jobId").is(jobId)
                        .and("category").is("PHYSICAL")
                        .and("isRequired").is(false)), "cim_objects");
        long logicalRequired     = mongoTemplate.count(
                new Query(Criteria.where("jobId").is(jobId)
                        .and("category").is("LOGICAL")
                        .and("isRequired").is(true)), "cim_objects");
        long logicalNotRequired  = mongoTemplate.count(
                new Query(Criteria.where("jobId").is(jobId)
                        .and("category").is("LOGICAL")
                        .and("isRequired").is(false)), "cim_objects");

        return ResponseEntity.ok(Map.of(
            "jobId",            jobId,
            "total",            total,
            "required",         totalRequired,
            "notRequired",      totalNotRequired,
            "breakdown", Map.of(
                "PHYSICAL", Map.of(
                    "required",    physicalRequired,
                    "notRequired", physicalNotRequired
                ),
                "LOGICAL", Map.of(
                    "required",    logicalRequired,
                    "notRequired", logicalNotRequired
                )
            )
        ));
    }
}

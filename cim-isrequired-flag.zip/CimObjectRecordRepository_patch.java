// ═══════════════════════════════════════════════════════════════════
// ADD THESE METHODS to CimObjectRecordRepository interface
// in ValidationRepositories.java
// ═══════════════════════════════════════════════════════════════════

    // Find all required objects for a job
    List<CimObjectRecord> findByJobIdAndIsRequired(String jobId, boolean isRequired);

    // Count required/not-required per job
    long countByJobIdAndIsRequired(String jobId, boolean isRequired);

    // Find by jobId + category + isRequired
    List<CimObjectRecord> findByJobIdAndCategoryAndIsRequired(
            String jobId, String category, boolean isRequired);

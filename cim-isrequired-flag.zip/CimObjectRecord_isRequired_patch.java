// ═══════════════════════════════════════════════════════════════════
// CHANGES TO CimObjectRecord in MongoDocuments.java
//
// ADD one field after line 174 (after category field):
// ═══════════════════════════════════════════════════════════════════

    /**
     * Whether this CIM object is required in the network model.
     *
     * Default assignment (set automatically during import):
     *   category = "PHYSICAL" → isRequired = true
     *   category = "LOGICAL"  → isRequired = false
     *
     * Can be changed at any time via:
     *   PATCH /api/objects/{id}/required?value=true
     *   PATCH /api/objects/{id}/required?value=false
     *
     * Or bulk change:
     *   PATCH /api/jobs/{jobId}/objects/required?category=PHYSICAL&value=false
     *
     * Use cases for overriding:
     *   - Mark a specific Terminal as required for topology completeness
     *   - Mark an ACLineSegment as not-required (e.g. decommissioned)
     *   - Mark all LOGICAL objects of a certain type as required
     */
    private boolean isRequired;

// ADD getter/setter after setCategory():

    public boolean isRequired()           { return isRequired; }
    public void setRequired(boolean v)    { this.isRequired = v; }

// ═══════════════════════════════════════════════════════════════════
// UPDATE toRecord() in LargeFileValidationService.java AND
// ValidationService.java
//
// ADD one line after r.setCategory(...):
//   r.setRequired("PHYSICAL".equals(category));
//
// This auto-sets isRequired during import:
//   PHYSICAL → isRequired = true
//   LOGICAL  → isRequired = false
// ═══════════════════════════════════════════════════════════════════

    private CimObjectRecord toRecord(CIMObject obj, String jobId,
                                      String networkVersion) {
        CimObjectRecord r = new CimObjectRecord();
        r.setJobId(jobId);
        r.setRdfId(obj.getRdfId());
        r.setMrid(obj.getMrid());
        r.setCimType(obj.getCimType());
        r.setName(obj.getName());

        // Determine category
        String category = PhysicalFilterStage.isLogical(obj.getCimType())
                ? "LOGICAL" : "PHYSICAL";
        r.setCategory(category);

        // isRequired: true for PHYSICAL, false for LOGICAL (can be changed later)
        r.setRequired("PHYSICAL".equals(category));

        r.setSourceFormat(obj.getSourceFormat());
        r.setSourceFile(obj.getSourceFile());
        r.setOrgId(obj.getOrgId());
        r.setVersion(networkVersion);
        r.setAttributes(MapKeySanitizer.encodeKeys(obj.getAttributes()));
        r.setReferences(MapKeySanitizer.encodeKeys(obj.getReferences()));
        r.setCreatedAt(java.time.Instant.now());
        return r;
    }

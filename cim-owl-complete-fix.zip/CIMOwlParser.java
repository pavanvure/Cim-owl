package com.cim.service;

import com.cim.model.mongo.CimClassDefinition;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import javax.xml.stream.*;
import java.io.*;
import java.util.*;

/**
 * CIM OWL FILE PARSER
 * ════════════════════════════════════════════════════════════════════
 * Parses official CIM OWL files using StAX XMLStreamReader (cursor API).
 * Supports single file (full CIM OWL) and multiple files (CPSM profiles).
 *
 * Extracts per owl:Class:
 *   rdfs:subClassOf          → parentClass
 *   cims:belongsToCategory   → cimPackage
 *   cims:stereotype          → category (PHYSICAL / LOGICAL)
 *   rdfs:comment             → description
 *
 * Extracts per owl:DatatypeProperty / owl:ObjectProperty:
 *   rdfs:domain              → declaring class name
 *   property local name      → attribute name (part after last '.')
 */
@Component
public class CIMOwlParser {

    private static final Logger log = LoggerFactory.getLogger(CIMOwlParser.class);

    private static final String NS_RDF  = "http://www.w3.org/1999/02/22-rdf-syntax-ns#";
    private static final String NS_RDFS = "http://www.w3.org/2000/01/rdf-schema#";
    private static final String NS_OWL  = "http://www.w3.org/2002/07/owl#";
    private static final String NS_CIMS =
            "http://iec.ch/TC57/1999/rdf-schema-extensions-19990926#";

    private static final Set<String> LOGICAL_STEREOTYPES =
            Set.of("abstract", "Primitive", "CIMDatatype", "enumeration", "Compound");

    private static final Set<String> LOGICAL_PACKAGES =
            Set.of("Topology", "Meas", "StateVariables", "LoadModel", "Contingency",
                    "InfWork", "InfAssets", "InfLocations", "InfOperations",
                    "IEC61968CIMVersion", "IEC61970CIMVersion");

    // ── Internal raw model ─────────────────────────────────────────────────

    private static class ClassEntry {
        final String       name;
        String             parentUri;
        String             packageName;
        String             stereotype;
        String             description;
        String             sourceFile;
        List<String>       ownAttributes = new ArrayList<>();

        ClassEntry(String name) { this.name = name; }
    }

    // ═══════════════════════════════════════════════════════════════════════
    // PUBLIC API — Single InputStream
    // ═══════════════════════════════════════════════════════════════════════

    /**
     * Parse a single OWL InputStream.
     * Called when admin uploads one file via REST or one file is configured.
     */
    public List<CimClassDefinition> parse(InputStream owlStream,
                                           String cimVersion) throws Exception {
        return parse(owlStream, cimVersion, "uploaded-owl");
    }

    public List<CimClassDefinition> parse(InputStream owlStream,
                                           String cimVersion,
                                           String fileName) throws Exception {
        log.info("Parsing OWL: '{}' version={}", fileName, cimVersion);
        long start = System.currentTimeMillis();

        Map<String, ClassEntry>   classes   = new LinkedHashMap<>();
        Map<String, List<String>> domainMap = new LinkedHashMap<>();

        parseOwlStream(owlStream, fileName, classes, domainMap);
        return buildDefinitions(classes, domainMap, cimVersion, start);
    }

    // ═══════════════════════════════════════════════════════════════════════
    // PUBLIC API — Multiple InputStreams (CPSM multi-profile merge)
    // ═══════════════════════════════════════════════════════════════════════

    /**
     * Parse and MERGE multiple CPSM profile OWL files.
     *
     * This is required when the CIM hierarchy is split across several OWLs:
     *   CPSM-CoreEquipment.owl  → ACLineSegment, Transformer, Breaker ...
     *   CPSM-Operation.owl      → TopologicalNode, Terminal, Analog ...
     *   CPSM-ShortCircuit.owl   → short-circuit specific classes
     *
     * Merge strategy:
     *   - Classes:    first file to declare a class wins for parentUri,
     *                 stereotype, packageName, description (first-wins)
     *   - Attributes: all files contribute — attributes are merged additively
     *                 (no duplicates added)
     *
     * @param owlStreams  ordered map: fileName → InputStream
     *                   order matters — CoreEquipment should come first
     * @param cimVersion label to store in MongoDB e.g. "CIM17-CPSM"
     */
    public List<CimClassDefinition> parseMultiple(
            Map<String, InputStream> owlStreams,
            String cimVersion) throws Exception {

        log.info("Merging {} OWL profile files for version: {}",
                owlStreams.size(), cimVersion);
        long start = System.currentTimeMillis();

        // Shared accumulation maps — all files write into the same maps
        Map<String, ClassEntry>   classes   = new LinkedHashMap<>();
        Map<String, List<String>> domainMap = new LinkedHashMap<>();

        int fileIndex = 0;
        for (Map.Entry<String, InputStream> entry : owlStreams.entrySet()) {
            fileIndex++;
            String fileName = entry.getKey();
            log.info("  [{}/{}] Parsing: {}", fileIndex, owlStreams.size(), fileName);

            parseOwlStream(entry.getValue(), fileName, classes, domainMap);

            log.info("  [{}/{}] Running total: {} classes, {} property domains",
                    fileIndex, owlStreams.size(), classes.size(), domainMap.size());
        }

        List<CimClassDefinition> defs =
                buildDefinitions(classes, domainMap, cimVersion, start);

        log.info("Multi-profile merge complete: {} total classes from {} files in {}ms",
                defs.size(), owlStreams.size(),
                System.currentTimeMillis() - start);
        return defs;
    }

    // ═══════════════════════════════════════════════════════════════════════
    // SHARED BUILD STEP — runs after all OWL parsing is done
    // ═══════════════════════════════════════════════════════════════════════

    private List<CimClassDefinition> buildDefinitions(
            Map<String, ClassEntry>   classes,
            Map<String, List<String>> domainMap,
            String                    cimVersion,
            long                      startMs) {

        // Attach attributes to their class entries (additive, no duplicates)
        domainMap.forEach((className, attrs) -> {
            ClassEntry entry = classes.get(className);
            if (entry != null) {
                for (String attr : attrs) {
                    if (!entry.ownAttributes.contains(attr)) {
                        entry.ownAttributes.add(attr);
                    }
                }
            }
        });

        // Build parent map (localName → parentLocalName)
        Map<String, String> parentMap = new LinkedHashMap<>();
        classes.forEach((name, entry) -> {
            if (entry.parentUri != null) {
                String parentName = localName(entry.parentUri);
                if (parentName != null && !parentName.equals(name)) {
                    parentMap.put(name, parentName);
                }
            }
        });

        // Build final CimClassDefinition list
        List<CimClassDefinition> defs = new ArrayList<>();
        classes.forEach((name, entry) -> {
            List<String> ancestors = computeAncestors(name, parentMap);
            String       category  = determineCategory(entry);

            CimClassDefinition def = new CimClassDefinition(
                    name,
                    parentMap.get(name),
                    ancestors,
                    new ArrayList<>(entry.ownAttributes),
                    category,
                    cimVersion);
            def.setCimPackage(entry.packageName != null ? entry.packageName : "Core");
            def.setDescription(entry.description);
            defs.add(def);
        });

        long elapsed = System.currentTimeMillis() - startMs;
        log.info("Build complete: {} class definitions in {}ms", defs.size(), elapsed);
        return defs;
    }

    // ═══════════════════════════════════════════════════════════════════════
    // STAX SINGLE-PASS PARSER
    // ═══════════════════════════════════════════════════════════════════════

    /**
     * Reads one OWL file and populates the shared classes + domainMap.
     * Safe to call multiple times on the same maps — additive, not replacing.
     * First-wins for class-level fields (parentUri, stereotype, etc.).
     */
    private void parseOwlStream(InputStream               owlStream,
                                 String                    fileName,
                                 Map<String, ClassEntry>   classes,
                                 Map<String, List<String>> domainMap) throws Exception {

        XMLInputFactory factory = XMLInputFactory.newInstance();
        factory.setProperty(XMLInputFactory.IS_SUPPORTING_EXTERNAL_ENTITIES, false);
        factory.setProperty(XMLInputFactory.SUPPORT_DTD, false);
        factory.setProperty(XMLInputFactory.IS_COALESCING, true);

        XMLStreamReader reader = factory.createXMLStreamReader(
                new BufferedInputStream(owlStream, 64 * 1024));

        String        currentType     = null; // "CLASS" or "PROPERTY"
        ClassEntry    currentClass    = null;
        String        currentPropName = null;
        String        currentDomain   = null;
        StringBuilder textBuf         = new StringBuilder(256);

        try {
            while (reader.hasNext()) {
                int event = reader.next();

                switch (event) {

                    case XMLStreamConstants.START_ELEMENT -> {
                        String ns    = reader.getNamespaceURI();
                        String local = reader.getLocalName();
                        textBuf.setLength(0);

                        // ── Top-level: class declaration ───────────────────
                        if ((isOwl(ns) || isRdf(ns))
                                && ("Class".equals(local)
                                    || "NamedIndividual".equals(local))) {

                            String uri = reader.getAttributeValue(NS_RDF, "about");
                            currentType = "CLASS";
                            if (uri != null) {
                                String name = localName(uri);
                                if (name != null) {
                                    currentClass = classes.computeIfAbsent(
                                            name, ClassEntry::new);
                                    // Track which file first declared this class
                                    if (currentClass.sourceFile == null) {
                                        currentClass.sourceFile = fileName;
                                    }
                                }
                            }
                        }

                        // ── Top-level: property declaration ────────────────
                        else if ((isOwl(ns) || isRdf(ns))
                                && ("DatatypeProperty".equals(local)
                                    || "ObjectProperty".equals(local))) {

                            String uri = reader.getAttributeValue(NS_RDF, "about");
                            currentType = "PROPERTY";
                            if (uri != null) {
                                currentPropName = propertyLocalName(uri);
                            }
                        }

                        // ── Child elements inside a class ──────────────────
                        if ("CLASS".equals(currentType) && currentClass != null) {
                            if (isRdfs(ns) && "subClassOf".equals(local)) {
                                String ref = reader.getAttributeValue(NS_RDF, "resource");
                                // First-wins: only set if not already set by earlier file
                                if (ref != null && !ref.isBlank()
                                        && currentClass.parentUri == null) {
                                    currentClass.parentUri = ref;
                                }
                            }
                            if (isCims(ns) && "belongsToCategory".equals(local)) {
                                String ref = reader.getAttributeValue(NS_RDF, "resource");
                                if (ref != null && currentClass.packageName == null) {
                                    currentClass.packageName = localName(ref);
                                }
                            }
                        }

                        // ── Child elements inside a property ───────────────
                        if ("PROPERTY".equals(currentType)
                                && isRdfs(ns) && "domain".equals(local)) {
                            String ref = reader.getAttributeValue(NS_RDF, "resource");
                            if (ref != null) {
                                currentDomain = localName(ref);
                            }
                        }
                    }

                    case XMLStreamConstants.CHARACTERS,
                         XMLStreamConstants.CDATA ->
                            textBuf.append(reader.getText());

                    case XMLStreamConstants.END_ELEMENT -> {
                        String ns    = reader.getNamespaceURI();
                        String local = reader.getLocalName();
                        String text  = textBuf.toString().trim();

                        // ── Text content inside class ──────────────────────
                        if ("CLASS".equals(currentType) && currentClass != null) {
                            if (isRdfs(ns) && "comment".equals(local)
                                    && !text.isEmpty()
                                    && currentClass.description == null) {
                                currentClass.description = text;
                            }
                            if (isCims(ns) && "stereotype".equals(local)
                                    && !text.isEmpty()
                                    && currentClass.stereotype == null) {
                                currentClass.stereotype = text;
                            }
                        }

                        // ── Close class element ────────────────────────────
                        if ((isOwl(ns) || isRdf(ns))
                                && ("Class".equals(local)
                                    || "NamedIndividual".equals(local))) {
                            currentType  = null;
                            currentClass = null;
                        }

                        // ── Close property element ─────────────────────────
                        if ((isOwl(ns) || isRdf(ns))
                                && ("DatatypeProperty".equals(local)
                                    || "ObjectProperty".equals(local))) {

                            // Register attribute on its declaring class (additive)
                            if (currentDomain != null
                                    && currentPropName != null
                                    && !currentPropName.isBlank()) {
                                domainMap
                                    .computeIfAbsent(currentDomain, k -> new ArrayList<>())
                                    .add(currentPropName);
                            }
                            currentType     = null;
                            currentPropName = null;
                            currentDomain   = null;
                        }

                        textBuf.setLength(0);
                    }
                }
            }
        } finally {
            reader.close();
        }
    }

    // ── Helpers ────────────────────────────────────────────────────────────

    private List<String> computeAncestors(String cls, Map<String, String> parentMap) {
        List<String> chain   = new ArrayList<>();
        Set<String>  visited = new HashSet<>();
        String       cur     = parentMap.get(cls);
        while (cur != null && !visited.contains(cur)) {
            chain.add(cur);
            visited.add(cur);
            cur = parentMap.get(cur);
        }
        return chain;
    }

    private String determineCategory(ClassEntry entry) {
        if (entry.stereotype != null
                && LOGICAL_STEREOTYPES.contains(entry.stereotype)) {
            return "LOGICAL";
        }
        if (entry.packageName != null
                && LOGICAL_PACKAGES.contains(entry.packageName)) {
            return "LOGICAL";
        }
        if (entry.name != null) {
            String n = entry.name;
            if (n.endsWith("Value") || n.endsWith("Schedule")
                    || n.endsWith("Island") || n.endsWith("Node")
                    || n.equals("Terminal") || n.equals("ACDCTerminal")
                    || n.equals("DCTerminal")
                    || n.endsWith("Type") || n.endsWith("Kind")) {
                return "LOGICAL";
            }
        }
        return "PHYSICAL";
    }

    private boolean isOwl(String ns)  { return NS_OWL.equals(ns); }
    private boolean isRdf(String ns)  { return NS_RDF.equals(ns); }
    private boolean isRdfs(String ns) { return NS_RDFS.equals(ns); }
    private boolean isCims(String ns) {
        return NS_CIMS.equals(ns)
            || (ns != null && ns.contains("rdf-schema-extensions"));
    }

    /** "http://iec.ch/...#ACLineSegment" → "ACLineSegment" */
    private String localName(String uri) {
        if (uri == null) return null;
        int idx = Math.max(uri.lastIndexOf('#'), uri.lastIndexOf('/'));
        return (idx >= 0 && idx < uri.length() - 1)
                ? uri.substring(idx + 1) : uri;
    }

    /** "...#ACLineSegment.r" → "r"   |   "...#ACLineSegment" → "ACLineSegment" */
    private String propertyLocalName(String uri) {
        String local = localName(uri);
        if (local == null) return null;
        int dot = local.lastIndexOf('.');
        return (dot >= 0 && dot < local.length() - 1)
                ? local.substring(dot + 1) : local;
    }
}

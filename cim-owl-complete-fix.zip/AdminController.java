package com.cim.controller;

import com.cim.repository.CimClassRepository;
import com.cim.service.CIMStandardService;
import com.cim.validation.registry.CIMHierarchyRegistry;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.util.List;
import java.util.Map;

/**
 * Admin REST API — CIM Standard Management
 * ════════════════════════════════════════════════════════════════════
 *
 * Endpoints:
 *
 *   POST /api/admin/cim/upload-owl
 *        Upload ONE OWL file (full CIM OWL or single CPSM profile)
 *        → CIMStandardService.loadFromUploadedOwl()
 *
 *   POST /api/admin/cim/upload-owl/multiple
 *        Upload MULTIPLE CPSM profile OWL files — merged into one registry
 *        → CIMStandardService.loadFromMultipleUploads()
 *
 *   POST /api/admin/cim/reload
 *        Reload from cim.owl.file-path or cim.owl.profile-paths in yml
 *        → CIMStandardService.reload()
 *
 *   GET  /api/admin/cim/classes
 *   GET  /api/admin/cim/classes/{name}
 *   GET  /api/admin/cim/chain/{className}
 *   POST /api/admin/cim/validate-path
 *   GET  /api/admin/cim/stats
 */
@RestController
@RequestMapping("/api/admin")
@CrossOrigin(origins = "*")
public class AdminController {

    private final CIMStandardService   standardService;
    private final CIMHierarchyRegistry registry;
    private final CimClassRepository   classRepo;

    public AdminController(CIMStandardService standardService,
                           CIMHierarchyRegistry registry,
                           CimClassRepository classRepo) {
        this.standardService = standardService;
        this.registry        = registry;
        this.classRepo       = classRepo;
    }

    // ─────────────────────────────────────────────────────────────────────
    // POST /api/admin/cim/upload-owl
    //
    // Upload ONE OWL file.
    // Use this for: full CIM17 OWL (iec61970cim17v40.owl) or a single profile.
    //
    // curl -X POST http://localhost:8080/api/admin/cim/upload-owl \
    //      -F "file=@iec61970cim17v40.owl" \
    //      -F "version=CIM17v40"
    // ─────────────────────────────────────────────────────────────────────
    @PostMapping("/cim/upload-owl")
    public ResponseEntity<?> uploadSingleOwl(
            @RequestParam("file")    MultipartFile file,
            @RequestParam(value = "version", defaultValue = "CIM17") String version) {

        if (file.isEmpty()) {
            return ResponseEntity.badRequest()
                    .body(Map.of("error", "OWL file is empty."));
        }

        try {
            CIMStandardService.AdminLoadResult result =
                    standardService.loadFromUploadedOwl(file, version);

            return ResponseEntity.ok(Map.of(
                "status",          "OK",
                "cimVersion",      result.cimVersion(),
                "totalClasses",    result.totalClasses(),
                "physicalClasses", result.physicalClasses(),
                "logicalClasses",  result.logicalClasses(),
                "message",         "OWL file loaded. Registry ready."
            ));
        } catch (Exception e) {
            return ResponseEntity.internalServerError()
                    .body(Map.of("error", "Failed to parse OWL: " + e.getMessage()));
        }
    }

    // ─────────────────────────────────────────────────────────────────────
    // POST /api/admin/cim/upload-owl/multiple
    //
    // Upload MULTIPLE CPSM profile OWL files.
    // All files are merged into one unified class registry.
    // Upload order matters: CoreEquipment first, then Operation, ShortCircuit.
    //
    // curl -X POST http://localhost:8080/api/admin/cim/upload-owl/multiple \
    //      -F "files=@CPSM-CoreEquipment.owl" \
    //      -F "files=@CPSM-Operation.owl" \
    //      -F "files=@CPSM-ShortCircuit.owl" \
    //      -F "version=CIM17-CPSM"
    //
    // Response:
    // { "totalClasses": 487, "filesProcessed": ["CPSM-CoreEquipment.owl", ...] }
    // ─────────────────────────────────────────────────────────────────────
    @PostMapping("/cim/upload-owl/multiple")
    public ResponseEntity<?> uploadMultipleOwls(
            @RequestParam("files")   List<MultipartFile> files,
            @RequestParam(value = "version", defaultValue = "CIM17-CPSM") String version) {

        if (files == null || files.isEmpty()) {
            return ResponseEntity.badRequest()
                    .body(Map.of("error", "No OWL files provided.",
                                 "hint",  "Send files via -F \"files=@file1.owl\" -F \"files=@file2.owl\""));
        }

        List<String> fileNames = files.stream()
                .map(MultipartFile::getOriginalFilename)
                .toList();

        try {
            CIMStandardService.AdminLoadResult result =
                    standardService.loadFromMultipleUploads(files, version);

            return ResponseEntity.ok(Map.of(
                "status",          "OK",
                "cimVersion",      result.cimVersion(),
                "totalClasses",    result.totalClasses(),
                "physicalClasses", result.physicalClasses(),
                "logicalClasses",  result.logicalClasses(),
                "filesProcessed",  fileNames,
                "filesCount",      files.size(),
                "message",         "Merged " + files.size()
                                 + " CPSM profile OWL files. Registry ready."
            ));
        } catch (Exception e) {
            return ResponseEntity.internalServerError()
                    .body(Map.of(
                        "error",  "Failed to parse/merge OWL files: " + e.getMessage(),
                        "files",  fileNames
                    ));
        }
    }

    // ─────────────────────────────────────────────────────────────────────
    // POST /api/admin/cim/reload?version=CIM17
    //
    // Reload from configured cim.owl.file-path or cim.owl.profile-paths.
    // Uses the same priority logic as startup:
    //   profile-paths (if configured) → merge multiple files
    //   file-path     (if configured) → single file
    //
    // curl -X POST http://localhost:8080/api/admin/cim/reload?version=CIM17v40
    // ─────────────────────────────────────────────────────────────────────
    @PostMapping("/cim/reload")
    public ResponseEntity<?> reload(
            @RequestParam(value = "version", defaultValue = "") String version) {
        try {
            CIMStandardService.AdminLoadResult result =
                    standardService.reload(version);

            return ResponseEntity.ok(Map.of(
                "status",       "OK",
                "cimVersion",   result.cimVersion(),
                "totalClasses", result.totalClasses()
            ));
        } catch (IllegalStateException e) {
            // No OWL path configured
            return ResponseEntity.badRequest()
                    .body(Map.of("error", e.getMessage()));
        } catch (Exception e) {
            return ResponseEntity.internalServerError()
                    .body(Map.of("error", e.getMessage()));
        }
    }

    // ─────────────────────────────────────────────────────────────────────
    // GET /api/admin/cim/classes
    // GET /api/admin/cim/classes?category=PHYSICAL
    // ─────────────────────────────────────────────────────────────────────
    @GetMapping("/cim/classes")
    public ResponseEntity<?> listClasses(
            @RequestParam(required = false) String category) {

        var classes = (category != null && !category.isBlank())
                ? classRepo.findByCategory(category.toUpperCase())
                : classRepo.findAll();

        return ResponseEntity.ok(Map.of(
            "totalClasses", classes.size(),
            "classes",      classes
        ));
    }

    // ─────────────────────────────────────────────────────────────────────
    // GET /api/admin/cim/classes/{name}
    // ─────────────────────────────────────────────────────────────────────
    @GetMapping("/cim/classes/{name}")
    public ResponseEntity<?> getClass(@PathVariable String name) {
        var def = registry.getDefinition(name);
        if (def == null) return ResponseEntity.notFound().build();
        return ResponseEntity.ok(Map.of(
            "className",     def.getClassName(),
            "parentClass",   def.getParentClass() != null ? def.getParentClass() : "ROOT",
            "ancestors",     def.getAncestors(),
            "ownAttributes", def.getOwnAttributes(),
            "category",      def.getCategory() != null ? def.getCategory() : "UNKNOWN",
            "cimPackage",    def.getCimPackage() != null ? def.getCimPackage() : "Unknown",
            "cimVersion",    def.getCimVersion(),
            "description",   def.getDescription() != null ? def.getDescription() : ""
        ));
    }

    // ─────────────────────────────────────────────────────────────────────
    // GET /api/admin/cim/chain/{className}
    // ─────────────────────────────────────────────────────────────────────
    @GetMapping("/cim/chain/{className}")
    public ResponseEntity<?> getChain(@PathVariable String className) {
        if (!registry.isKnownClass(className))
            return ResponseEntity.notFound().build();

        var chain = registry.getFullChain(className);
        return ResponseEntity.ok(Map.of(
            "className",        className,
            "inheritanceChain", chain,
            "depth",            chain.size()
        ));
    }

    // ─────────────────────────────────────────────────────────────────────
    // POST /api/admin/cim/validate-path
    //
    // curl -X POST http://localhost:8080/api/admin/cim/validate-path \
    //   -H "Content-Type: application/json" \
    //   -d '{"objectType":"ACLineSegment","attributeTag":"ConductingEquipment.BaseVoltage"}'
    // ─────────────────────────────────────────────────────────────────────
    @PostMapping("/cim/validate-path")
    public ResponseEntity<?> validatePath(@RequestBody Map<String, String> body) {
        String objectType   = body.get("objectType");
        String attributeTag = body.get("attributeTag");

        if (objectType == null || attributeTag == null) {
            return ResponseEntity.badRequest()
                    .body(Map.of("error",
                            "Both 'objectType' and 'attributeTag' are required."));
        }

        var result = registry.validateAttributePath(objectType, attributeTag);
        var chain  = registry.getFullChain(objectType);

        return ResponseEntity.ok(Map.of(
            "objectType",       objectType,
            "attributeTag",     attributeTag,
            "status",           result.getStatus().name(),
            "valid",            result.isValid(),
            "explanation",      result.getExplanation(),
            "inheritanceChain", chain
        ));
    }

    // ─────────────────────────────────────────────────────────────────────
    // GET /api/admin/cim/stats
    // ─────────────────────────────────────────────────────────────────────
    @GetMapping("/cim/stats")
    public ResponseEntity<?> getStats() {
        boolean loaded   = registry.isLoaded();
        long    physical = classRepo.findByCategory("PHYSICAL").size();
        long    logical  = classRepo.findByCategory("LOGICAL").size();

        return ResponseEntity.ok(Map.of(
            "registryLoaded",  loaded,
            "totalClasses",    registry.size(),
            "physicalClasses", physical,
            "logicalClasses",  logical,
            "note", loaded
                ? "Registry loaded and ready."
                : "Registry EMPTY. Upload OWL via POST /api/admin/cim/upload-owl "
                + "or POST /api/admin/cim/upload-owl/multiple"
        ));
    }
}

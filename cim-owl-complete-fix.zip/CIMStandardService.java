package com.cim.service;

import com.cim.model.mongo.CimClassDefinition;
import com.cim.repository.CimClassRepository;
import com.cim.validation.registry.CIMHierarchyRegistry;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.context.event.ApplicationReadyEvent;
import org.springframework.context.event.EventListener;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import java.io.*;
import java.nio.file.*;
import java.util.*;

/**
 * CIM STANDARD SERVICE
 * ════════════════════════════════════════════════════════════════════
 * Loads the CIM class hierarchy into MongoDB (cim_standard collection)
 * and the in-memory CIMHierarchyRegistry.
 *
 * Three loading paths — all converge on persistDefinitions():
 *
 *  ┌─────────────────────────────────────────────────────────────────┐
 *  │  STARTUP  (@EventListener ApplicationReadyEvent)               │
 *  │                                                                 │
 *  │  if MongoDB already has data:                                   │
 *  │      load registry from MongoDB  (skip file parsing)           │
 *  │  else if cim.owl.profile-paths is configured (list, non-empty):│
 *  │      loadFromMultipleFiles()  ← CPSM profile OWLs              │
 *  │  else if cim.owl.file-path is configured (single path):        │
 *  │      loadFromSingleFile()     ← full CIM OWL                   │
 *  │  else:                                                          │
 *  │      warn → wait for REST upload                               │
 *  └─────────────────────────────────────────────────────────────────┘
 *
 *  ┌─────────────────────────────────────────────────────────────────┐
 *  │  REST — Single file                                             │
 *  │  POST /api/admin/cim/upload-owl                                 │
 *  │      loadFromUploadedOwl(MultipartFile, version)               │
 *  └─────────────────────────────────────────────────────────────────┘
 *
 *  ┌─────────────────────────────────────────────────────────────────┐
 *  │  REST — Multiple files (CPSM profiles)                          │
 *  │  POST /api/admin/cim/upload-owl/multiple                        │
 *  │      loadFromMultipleUploads(List<MultipartFile>, version)      │
 *  └─────────────────────────────────────────────────────────────────┘
 *
 * All three paths produce a List<CimClassDefinition> and call
 * persistDefinitions() which:
 *   1. Clears MongoDB cim_standard collection
 *   2. Saves new definitions (saveAll)
 *   3. Loads definitions into in-memory CIMHierarchyRegistry
 */
@Service
public class CIMStandardService {

    private static final Logger log =
            LoggerFactory.getLogger(CIMStandardService.class);

    // ── Config values from application.yml ───────────────────────────────

    /** Single OWL file path — used when cim.owl.file-path is set */
    @Value("${cim.owl.file-path:}")
    private String singleOwlPath;

    /** Multiple CPSM profile OWL paths — used when cim.owl.profile-paths is set */
    @Value("${cim.owl.profile-paths:}")
    private List<String> profilePaths;

    /** CIM version label stored in MongoDB e.g. "CIM17v40" */
    @Value("${cim.owl.version:CIM17}")
    private String cimVersion;

    // ── Dependencies ──────────────────────────────────────────────────────

    private final CimClassRepository   mongoRepo;
    private final CIMHierarchyRegistry registry;
    private final CIMOwlParser         owlParser;

    public CIMStandardService(CimClassRepository mongoRepo,
                               CIMHierarchyRegistry registry,
                               CIMOwlParser owlParser) {
        this.mongoRepo  = mongoRepo;
        this.registry   = registry;
        this.owlParser  = owlParser;
    }

    // ═══════════════════════════════════════════════════════════════════════
    // PATH 1 — STARTUP
    // ═══════════════════════════════════════════════════════════════════════

    @EventListener(ApplicationReadyEvent.class)
    public void initOnStartup() {

        // If MongoDB already seeded — load registry from it, skip file parsing
        if (mongoRepo.count() > 0) {
            List<CimClassDefinition> existing = mongoRepo.findAll();
            registry.load(existing);
            log.info("CIM registry loaded from MongoDB: {} classes", registry.size());
            return;
        }

        // MongoDB is empty — try to load from configured file(s)

        // Priority 1: multiple profile paths (CPSM use case)
        if (profilePaths != null && !profilePaths.isEmpty()) {
            log.info("cim.owl.profile-paths configured ({} paths) — loading CPSM profiles",
                    profilePaths.size());
            try {
                loadFromMultipleFiles(profilePaths, cimVersion);
                return;
            } catch (Exception e) {
                log.error("Failed loading CPSM profile OWL files: {}", e.getMessage());
            }
        }

        // Priority 2: single file path
        if (singleOwlPath != null && !singleOwlPath.isBlank()) {
            log.info("cim.owl.file-path configured — loading single OWL file");
            try {
                loadFromSingleFile(singleOwlPath, cimVersion);
                return;
            } catch (Exception e) {
                log.error("Failed loading OWL file '{}': {}", singleOwlPath, e.getMessage());
            }
        }

        // Nothing configured — application still starts, registry is empty
        log.warn("CIM registry is EMPTY. No OWL file configured. "
               + "Upload via REST: POST /api/admin/cim/upload-owl (single) "
               + "or POST /api/admin/cim/upload-owl/multiple (CPSM profiles)");
    }

    // ═══════════════════════════════════════════════════════════════════════
    // PATH 2 — REST: Single file upload
    // POST /api/admin/cim/upload-owl
    // ═══════════════════════════════════════════════════════════════════════

    /**
     * Admin uploads one OWL file via REST.
     * Used for full CIM OWL (iec61970cim17v40.owl) or a single profile.
     */
    public AdminLoadResult loadFromUploadedOwl(MultipartFile file,
                                                String version) throws Exception {
        log.info("REST single OWL upload: {} ({} bytes)",
                file.getOriginalFilename(), file.getSize());

        List<CimClassDefinition> defs =
                owlParser.parse(file.getInputStream(), version,
                                file.getOriginalFilename());

        persistDefinitions(defs);
        return toResult(version, defs);
    }

    // ═══════════════════════════════════════════════════════════════════════
    // PATH 3 — REST: Multiple files upload (CPSM profiles)
    // POST /api/admin/cim/upload-owl/multiple
    // ═══════════════════════════════════════════════════════════════════════

    /**
     * Admin uploads multiple CPSM profile OWL files via REST.
     *
     * Example (three CPSM profiles merged into one registry):
     *   -F "files=@CPSM-CoreEquipment.owl"
     *   -F "files=@CPSM-Operation.owl"
     *   -F "files=@CPSM-ShortCircuit.owl"
     *
     * The files are processed in the order they are uploaded.
     * For CPSM, CoreEquipment should be uploaded first so that
     * base classes (Equipment, ConductingEquipment, etc.) are
     * registered before their subclasses from other profiles.
     */
    public AdminLoadResult loadFromMultipleUploads(List<MultipartFile> files,
                                                    String version) throws Exception {
        log.info("REST multi-OWL upload: {} files", files.size());

        // Build ordered map: fileName → InputStream (preserves upload order)
        Map<String, InputStream> streams = new LinkedHashMap<>();
        for (MultipartFile file : files) {
            log.info("  Adding: {} ({} bytes)",
                    file.getOriginalFilename(), file.getSize());
            streams.put(file.getOriginalFilename(), file.getInputStream());
        }

        List<CimClassDefinition> defs = owlParser.parseMultiple(streams, version);
        persistDefinitions(defs);
        return toResult(version, defs);
    }

    // ═══════════════════════════════════════════════════════════════════════
    // INTERNAL HELPERS — file-system loading (used during startup)
    // ═══════════════════════════════════════════════════════════════════════

    /**
     * Loads from a single configured file path.
     * Called during startup when cim.owl.file-path is set.
     */
    private void loadFromSingleFile(String filePath,
                                     String version) throws Exception {
        File file = new File(filePath);
        if (!file.exists() || !file.isFile()) {
            throw new FileNotFoundException(
                    "OWL file not found at: " + filePath);
        }
        log.info("Loading single OWL: {} ({} MB)",
                file.getName(),
                String.format("%.1f", file.length() / (1024.0 * 1024.0)));

        List<CimClassDefinition> defs;
        try (InputStream is = new BufferedInputStream(
                new FileInputStream(file), 64 * 1024)) {
            defs = owlParser.parse(is, version, file.getName());
        }
        persistDefinitions(defs);
        log.info("Single OWL load complete: {} classes", defs.size());
    }

    /**
     * Loads and merges multiple CPSM profile OWL files from disk.
     * Called during startup when cim.owl.profile-paths is configured.
     *
     * @param paths    list of absolute file paths from application.yml
     * @param version  CIM version label
     */
    private void loadFromMultipleFiles(List<String> paths,
                                        String version) throws Exception {

        log.info("Loading {} CPSM profile OWL files from disk:", paths.size());

        // Validate all files exist BEFORE opening any streams
        for (String path : paths) {
            File f = new File(path);
            if (!f.exists() || !f.isFile()) {
                throw new FileNotFoundException(
                        "CPSM profile OWL not found: " + path);
            }
            log.info("  Verified: {} ({} MB)",
                    f.getName(),
                    String.format("%.1f", f.length() / (1024.0 * 1024.0)));
        }

        // Build ordered map: fileName → InputStream
        // Use LinkedHashMap to preserve the configured order
        Map<String, InputStream> streams = new LinkedHashMap<>();
        List<InputStream> openStreams = new ArrayList<>(); // for cleanup in finally

        try {
            for (String path : paths) {
                File f = new File(path);
                InputStream is = new BufferedInputStream(
                        new FileInputStream(f), 64 * 1024);
                streams.put(f.getName(), is);
                openStreams.add(is);
            }

            List<CimClassDefinition> defs = owlParser.parseMultiple(streams, version);
            persistDefinitions(defs);
            log.info("Multi-profile load complete: {} total classes from {} files",
                    defs.size(), paths.size());

        } finally {
            // Always close all streams
            for (InputStream is : openStreams) {
                try { is.close(); } catch (IOException ignored) {}
            }
        }
    }

    // ═══════════════════════════════════════════════════════════════════════
    // RELOAD — clears and reloads from configured path(s)
    // POST /api/admin/cim/reload
    // ═══════════════════════════════════════════════════════════════════════

    /**
     * Reloads CIM standard from configured paths.
     * Uses same priority logic as startup:
     *   profile-paths (if set) → loadFromMultipleFiles
     *   file-path     (if set) → loadFromSingleFile
     */
    public AdminLoadResult reload(String version) throws Exception {
        String v = (version != null && !version.isBlank()) ? version : cimVersion;

        if (profilePaths != null && !profilePaths.isEmpty()) {
            log.info("Reload: using profile-paths ({} files)", profilePaths.size());
            loadFromMultipleFiles(profilePaths, v);
        } else if (singleOwlPath != null && !singleOwlPath.isBlank()) {
            log.info("Reload: using file-path");
            loadFromSingleFile(singleOwlPath, v);
        } else {
            throw new IllegalStateException(
                    "No OWL path configured. Set cim.owl.file-path or "
                    + "cim.owl.profile-paths in application.yml, "
                    + "or upload via POST /api/admin/cim/upload-owl");
        }

        List<CimClassDefinition> loaded = mongoRepo.findAll();
        return toResult(v, loaded);
    }

    // ═══════════════════════════════════════════════════════════════════════
    // PERSIST — single entry point for saving to MongoDB + registry
    // ═══════════════════════════════════════════════════════════════════════

    /**
     * Clears the existing cim_standard collection, saves new definitions,
     * and reloads the in-memory registry.
     * ALL loading paths call this method.
     */
    private void persistDefinitions(List<CimClassDefinition> defs) {
        mongoRepo.deleteAll();
        mongoRepo.saveAll(defs);
        registry.load(defs);
        log.info("Persisted {} class definitions to MongoDB. Registry ready.",
                defs.size());
    }

    // ── Result DTO ────────────────────────────────────────────────────────

    private AdminLoadResult toResult(String version, List<CimClassDefinition> defs) {
        long physical = defs.stream()
                .filter(d -> "PHYSICAL".equals(d.getCategory())).count();
        long logical  = defs.stream()
                .filter(d -> "LOGICAL".equals(d.getCategory())).count();
        return new AdminLoadResult(version, defs.size(),
                (int) physical, (int) logical);
    }

    public record AdminLoadResult(
            String cimVersion,
            int    totalClasses,
            int    physicalClasses,
            int    logicalClasses) {}
}

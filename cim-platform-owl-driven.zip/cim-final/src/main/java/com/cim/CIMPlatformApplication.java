package com.cim;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.scheduling.annotation.EnableAsync;

/**
 * CIM Validation Platform
 * ═══════════════════════════════════════════════════════════════
 *
 * UPDATED END-TO-END FLOW:
 *
 *  Step 1 — Admin seeds MongoDB with CIM17 class hierarchy
 *            (cim_standard collection — runs once on startup)
 *
 *  Step 2 — Client uploads file
 *            (RDF/XML, JSON-LD, Milsoft CSV, or custom format)
 *            Files ≤ 50MB  → synchronous processing
 *            Files > 50MB  → streaming / async processing
 *
 *  Step 3 — FormatDetector auto-detects format from file content
 *            Routes to correct adapter automatically
 *
 *  Step 4 — Adapter parses file → List<CIMObject>  (COMMON MODEL)
 *            All formats produce the same CIMObject structure.
 *            Cross-references resolved within the file.
 *
 *  Step 5 — Store ALL parsed objects to MongoDB  (cim_objects)
 *            Every object saved regardless of physical/logical type.
 *            This is the permanent store for future reference / re-query.
 *
 *  Step 6 — Validation Pipeline (4 stages):
 *
 *    Stage 1 — Physical Filter
 *              Separate PHYSICAL equipment (ACLineSegment, Breaker…)
 *              from LOGICAL nodes (Terminal, ConnectivityNode…).
 *              Stages 2-4 run on ALL objects for path/ref checks,
 *              but business rules only apply to PHYSICAL objects.
 *
 *    Stage 2 — Attribute Path Validation
 *              For each tag "DeclaringClass.attribute", verify
 *              DeclaringClass is in the CIM inheritance chain of
 *              the object's actual type (loaded from MongoDB).
 *              e.g. "ConductingEquipment.BaseVoltage" on ACLineSegment → VALID
 *                   "ConductingEquipment.BaseVoltage" on BaseVoltage   → INVALID
 *
 *    Stage 3 — Reference Resolution
 *              Verify each rdf:resource reference resolves to an
 *              existing object of the correct CIM type.
 *              Unresolved refs = WARNING (may be in another profile file).
 *
 *    Stage 4 — Business Rules (PHYSICAL objects only)
 *              Per-class required field checks:
 *              ACLineSegment → BaseVoltage + EquipmentContainer required
 *              BaseVoltage   → nominalVoltage required and > 0
 *              Switch family → BaseVoltage recommended
 *              etc. (pluggable — add @Component ClassRule for new rules)
 *
 *  Step 7 — Save results to MongoDB
 *            validation_findings — one document per finding
 *            validation_jobs     — status, counts, timing per job
 *
 *  Step 8 — REST API exposes all data
 *            GET /api/jobs/{id}/objects   → parsed CIM data (Step 5)
 *            GET /api/jobs/{id}/findings  → validation results (Step 7)
 *            GET /api/jobs/{id}/progress  → live progress for large files
 */
@SpringBootApplication
@EnableAsync
public class CIMPlatformApplication {
    public static void main(String[] args) {
        SpringApplication.run(CIMPlatformApplication.class, args);
    }
}

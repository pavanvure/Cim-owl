package com.cim.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.data.mongodb.MongoDatabaseFactory;
import org.springframework.data.mongodb.core.convert.*;
import org.springframework.data.mongodb.core.mapping.MongoMappingContext;

/**
 * MongoDB configuration that fixes:
 *
 *   MappingException: Map key "ACLineSegment.r" contains dots but
 *   no replacement was configured!
 *
 * CIM attribute keys follow the pattern "ClassName.attributeName"
 * (e.g. "ACLineSegment.r", "ConductingEquipment.BaseVoltage").
 * MongoDB forbids dots in map keys by default.
 *
 * Fix: register a MapKeyDotReplacement that encodes "." → "\uff0e"
 * (Unicode FULLWIDTH FULL STOP — visually identical, no MongoDB conflict).
 *
 * The encoding/decoding is transparent:
 *   Write to Mongo:   "ACLineSegment.r"    → "ACLineSegment\uff0er"
 *   Read from Mongo:  "ACLineSegment\uff0er" → "ACLineSegment.r"
 *
 * Alternative approaches (not used here):
 *   Option B: Change Map<String,String> to List<AttributeEntry> — changes
 *             the data model and breaks all existing query code.
 *   Option C: Use @Field on the map — doesn't work for dynamic keys.
 */
@Configuration
public class MongoConfig {

    /**
     * Unicode FULLWIDTH FULL STOP (U+FF0E).
     * Looks identical to a normal dot but is not the ASCII dot (U+002E)
     * that MongoDB rejects. Survives round-trips through JSON serialization.
     */
    public static final String DOT_REPLACEMENT = "\uff0e";

    @Bean
    public MappingMongoConverter mappingMongoConverter(
            MongoDatabaseFactory factory,
            MongoMappingContext context) {

        DbRefResolver dbRefResolver = new DefaultDbRefResolver(factory);
        MappingMongoConverter converter =
                new MappingMongoConverter(dbRefResolver, context);

        // Tell Spring Data MongoDB to encode "." as DOT_REPLACEMENT
        // when writing map keys, and decode it back when reading.
        converter.setMapKeyDotReplacement(DOT_REPLACEMENT);

        // Do not store class type information (_class field) —
        // saves space and avoids type mismatch issues on reads.
        converter.setTypeMapper(new DefaultMongoTypeMapper(null));

        return converter;
    }
}

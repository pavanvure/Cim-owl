package com.cim.pipeline.stage;

import com.cim.model.cim.CIMObject;
import com.cim.model.mongo.CimClassDefinition;
import com.cim.pipeline.result.PipelineFinding;
import com.cim.validation.registry.CIMHierarchyRegistry;
import com.cim.validation.registry.PathValidationResult;
import com.cim.validation.rules.BusinessRuleEngine;
import org.springframework.stereotype.Component;

import java.util.*;
import java.util.stream.Collectors;

// ═══════════════════════════════════════════════════════════════════════════
// STAGE 1 — Physical Object Filter
// Separates physical equipment from logical/topology objects.
// Business rules (Stage 4) only apply to physical objects.
// ═══════════════════════════════════════════════════════════════════════════

@Component
class PhysicalFilterStage {

    private static final Set<String> PHYSICAL = Set.of(
        "ACLineSegment","ACLineSegmentPhase","DCLineSegment",
        "Breaker","Recloser","LoadBreakSwitch","ProtectedSwitch","Fuse",
        "Disconnector","GroundDisconnector","Sectionaliser","Jumper",
        "CompositeSwitch","Switch",
        "PowerTransformer","PowerTransformerEnd","TransformerTank",
        "TransformerTankEnd","TransformerEnd","TransformerWinding",
        "RatioTapChanger","PhaseTapChangerLinear","TapChanger",
        "ShuntCompensator","LinearShuntCompensator","NonLinearShuntCompensator",
        "StaticVarCompensator","SeriesCompensator",
        "SynchronousMachine","AsynchronousMachine","RotatingMachine",
        "GeneratingUnit","HydroGeneratingUnit","ThermalGeneratingUnit",
        "WindGeneratingUnit","NuclearGeneratingUnit","SolarGeneratingUnit",
        "PowerElectronicsConnection","PowerElectronicsConnectionPhase",
        "BatteryUnit","PhotoVoltaicUnit","PowerElectronicsUnit","PowerElectronicsWindUnit",
        "EnergyConsumer","EnergyConsumerPhase","ConformLoad","NonConformLoad","StationSupply",
        "Substation","VoltageLevel","Bay","Line","Feeder",
        "GeographicalRegion","SubGeographicalRegion",
        "BaseVoltage","OperationalLimitSet","CurrentLimit",
        "ActivePowerLimit","ApparentPowerLimit",
        "BusbarSection","WireInfo","CableInfo","WireSpacingInfo",
        "PerLengthSequenceImpedance","PerLengthPhaseImpedance","PhaseImpedanceData",
        "TransformerEndInfo","PowerTransformerInfo","TransformerTankInfo",
        "UtilityDistributionCompany","Company"
    );

    private static final Set<String> LOGICAL = Set.of(
        "ConnectivityNode","TopologicalNode","TopologicalIsland",
        "Terminal","ACDCTerminal","DCTerminal",
        "LoadGroup","ConformLoadGroup","NonConformLoadGroup",
        "SubLoadArea","LoadArea","EnergyArea","MeteredSubSystem",
        "RegulatingControl","RegulationSchedule","TapChangerControl",
        "ConformLoadSchedule","NonConformLoadSchedule","RegularTimePoint",
        "DayType","Season","SeasonDayTypeSchedule","BasicIntervalSchedule",
        "Measurement","Accumulator","AccumulatorValue","Analog","AnalogValue",
        "Discrete","DiscreteValue","MeasurementValue","MeasurementValueSource",
        "StringMeasurement","StringMeasurementValue","IOPoint",
        "BranchGroup","BranchGroupTerminal","LossShare",
        "Name","NameType","NameTypeAuthority","Location","PositionPoint",
        "PowerCutZone","CurveData","GenUnitOpCostCurve","GenUnitOpSchedule"
    );

    public static boolean isPhysical(String t) {
        if (PHYSICAL.contains(t)) return true;
        if (LOGICAL.contains(t))  return false;
        return true; // unknown → treat as physical
    }

    public static boolean isLogical(String t) { return LOGICAL.contains(t); }

    public static Map<String, List<CIMObject>> split(List<CIMObject> objects) {
        Map<String, List<CIMObject>> m = new HashMap<>();
        m.put("physical", new ArrayList<>());
        m.put("logical",  new ArrayList<>());
        m.put("unknown",  new ArrayList<>());
        for (CIMObject o : objects) {
            if (PHYSICAL.contains(o.getCimType()))    m.get("physical").add(o);
            else if (LOGICAL.contains(o.getCimType())) m.get("logical").add(o);
            else m.get("unknown").add(o);
        }
        return m;
    }
}


// ═══════════════════════════════════════════════════════════════════════════
// STAGE 2 — Attribute Path Validation
// For each "DeclaringClass.attribute" tag, verify DeclaringClass is in
// the inheritance chain of the object's actual CIM type.
// ═══════════════════════════════════════════════════════════════════════════

@Component
class PathValidationStage {

    private final CIMHierarchyRegistry registry;

    PathValidationStage(CIMHierarchyRegistry registry) {
        this.registry = registry;
    }

    List<PipelineFinding> run(CIMObject obj, String jobId) {
        List<PipelineFinding> findings = new ArrayList<>();
        if (!registry.isLoaded()) return findings;

        for (String tag : obj.getAttributes().keySet()) {
            if (!tag.contains(".")) continue;

            PathValidationResult r = registry.validateAttributePath(obj.getCimType(), tag);

            switch (r.getStatus()) {
                case VALID -> findings.add(PipelineFinding.info(jobId,
                        "PATH_VALIDATION", obj, tag,
                        "Valid — " + r.getExplanation(), r.getExplanation()));

                case INVALID -> findings.add(PipelineFinding.error(jobId,
                        "PATH_VALIDATION", obj, tag,
                        r.getExplanation(), null));

                case VENDOR_EXTENSION -> findings.add(PipelineFinding.info(jobId,
                        "PATH_VALIDATION", obj, tag,
                        "Vendor extension: " + r.getExplanation(), null));

                case UNKNOWN_TYPE -> findings.add(PipelineFinding.warning(jobId,
                        "PATH_VALIDATION", obj, tag,
                        r.getExplanation(), null));
            }
        }
        return findings;
    }
}


// ═══════════════════════════════════════════════════════════════════════════
// STAGE 3 — Reference Resolution
// Verify every rdf:resource reference resolves to an existing object
// of the correct CIM type.
// ═══════════════════════════════════════════════════════════════════════════

@Component
class ReferenceResolutionStage {

    private final CIMHierarchyRegistry registry;

    ReferenceResolutionStage(CIMHierarchyRegistry registry) {
        this.registry = registry;
    }

    // Known reference key → expected target type (or base class)
    private static final Map<String, String> EXPECTED_TYPES = Map.ofEntries(
        Map.entry("ConductingEquipment.BaseVoltage",        "BaseVoltage"),
        Map.entry("Equipment.EquipmentContainer",           "EquipmentContainer"),
        Map.entry("VoltageLevel.Substation",                "Substation"),
        Map.entry("VoltageLevel.BaseVoltage",               "BaseVoltage"),
        Map.entry("SubGeographicalRegion.Region",           "GeographicalRegion"),
        Map.entry("Line.Region",                            "SubGeographicalRegion"),
        Map.entry("Substation.Region",                      "SubGeographicalRegion"),
        Map.entry("PowerTransformerEnd.BaseVoltage",        "BaseVoltage"),
        Map.entry("RatioTapChanger.TransformerEnd",         "TransformerEnd"),
        Map.entry("SynchronousMachine.GeneratingUnit",      "GeneratingUnit"),
        Map.entry("Terminal.ConnectivityNode",              "ConnectivityNode"),
        Map.entry("Terminal.ConductingEquipment",           "ConductingEquipment")
    );

    List<PipelineFinding> run(CIMObject obj,
                               Map<String, CIMObject> allById,
                               String jobId) {
        List<PipelineFinding> findings = new ArrayList<>();

        for (Map.Entry<String, String> ref : obj.getReferences().entrySet()) {
            String key      = ref.getKey();
            String targetId = ref.getValue();

            if (!allById.containsKey(targetId)) {
                findings.add(PipelineFinding.warning(jobId, "REFERENCE_RESOLUTION",
                        obj, key,
                        "Reference '" + targetId + "' not found in this file. "
                        + "May be defined in another CIM profile file.", null));
                continue;
            }

            CIMObject target = allById.get(targetId);
            String expectedType = EXPECTED_TYPES.get(key);

            if (expectedType != null) {
                List<String> chain = registry.getFullChain(target.getCimType());
                if (!chain.contains(expectedType) && !target.getCimType().equals(expectedType)) {
                    findings.add(PipelineFinding.error(jobId, "REFERENCE_RESOLUTION",
                            obj, key,
                            "Reference target type '" + target.getCimType()
                            + "' is not compatible with expected '" + expectedType + "'.",
                            null));
                    continue;
                }
            }

            findings.add(PipelineFinding.info(jobId, "REFERENCE_RESOLUTION",
                    obj, key,
                    "Resolved → [" + target.getCimType() + "] " + target.getName(), null));
        }
        return findings;
    }
}


// ═══════════════════════════════════════════════════════════════════════════
// STAGE 4 — Business Rules
// Per-class required field checks. Physical objects only.
// Pluggable: add @Component ClassRule implementations for new classes.
// ═══════════════════════════════════════════════════════════════════════════

@Component
class BusinessRuleStage {

    private final BusinessRuleEngine engine;

    BusinessRuleStage(BusinessRuleEngine engine) {
        this.engine = engine;
    }

    List<PipelineFinding> run(CIMObject obj, String jobId) {
        return engine.validate(obj, jobId);
    }
}


// ═══════════════════════════════════════════════════════════════════════════
// STAGE 5 — Cross-Object Consistency
// Rules that span multiple objects (mRID uniqueness, etc.)
// ═══════════════════════════════════════════════════════════════════════════

@Component
class CrossObjectStage {

    List<PipelineFinding> run(List<CIMObject> objects, String jobId) {
        List<PipelineFinding> findings = new ArrayList<>();

        // Rule: mRID must be unique
        Map<String, List<CIMObject>> byMrid = new HashMap<>();
        for (CIMObject o : objects) {
            if (o.getMrid() != null && !o.getMrid().isBlank()) {
                byMrid.computeIfAbsent(o.getMrid(), k -> new ArrayList<>()).add(o);
            }
        }
        for (Map.Entry<String, List<CIMObject>> entry : byMrid.entrySet()) {
            if (entry.getValue().size() > 1) {
                String ids = entry.getValue().stream()
                        .map(CIMObject::getRdfId)
                        .collect(Collectors.joining(", "));
                CIMObject first = entry.getValue().get(0);
                findings.add(PipelineFinding.error(jobId, "CROSS_OBJECT", first,
                        "IdentifiedObject.mRID",
                        "Duplicate mRID '" + entry.getKey()
                        + "' found on objects: " + ids, null));
            }
        }

        return findings;
    }
}


// ═══════════════════════════════════════════════════════════════════════════
// PIPELINE ORCHESTRATOR
// Wires all stages together in the correct order.
// ═══════════════════════════════════════════════════════════════════════════

@Component
public class ValidationPipeline {

    private final PathValidationStage     pathStage;
    private final ReferenceResolutionStage refStage;
    private final BusinessRuleStage        ruleStage;
    private final CrossObjectStage         crossStage;

    public ValidationPipeline(PathValidationStage pathStage,
                               ReferenceResolutionStage refStage,
                               BusinessRuleStage ruleStage,
                               CrossObjectStage crossStage) {
        this.pathStage  = pathStage;
        this.refStage   = refStage;
        this.ruleStage  = ruleStage;
        this.crossStage = crossStage;
    }

    public List<PipelineFinding> run(List<CIMObject> objects, String jobId) {
        List<PipelineFinding> findings = new ArrayList<>();

        // Build ID index for reference resolution
        Map<String, CIMObject> byId = new LinkedHashMap<>();
        for (CIMObject o : objects) byId.put(o.getRdfId(), o);

        // Split physical vs logical
        Map<String, List<CIMObject>> split = PhysicalFilterStage.split(objects);
        List<CIMObject> physical = split.get("physical");

        // Log filter summary
        if (!objects.isEmpty()) {
            CIMObject first = objects.get(0);
            findings.add(PipelineFinding.info(jobId, "PHYSICAL_FILTER", first,
                    "filter",
                    String.format("Total:%d  Physical:%d  Logical:%d  Unknown:%d",
                            objects.size(), physical.size(),
                            split.get("logical").size(),
                            split.get("unknown").size()), null));
        }

        // Stage 2 & 3: Run on ALL objects (path + ref checks apply everywhere)
        for (CIMObject obj : objects) {
            findings.addAll(pathStage.run(obj, jobId));
            findings.addAll(refStage.run(obj, byId, jobId));
        }

        // Stage 4: Business rules — PHYSICAL ONLY
        for (CIMObject obj : physical) {
            findings.addAll(ruleStage.run(obj, jobId));
        }

        // Mark logical objects as skipped
        for (CIMObject obj : split.get("logical")) {
            findings.add(PipelineFinding.info(jobId, "PHYSICAL_FILTER", obj,
                    "filter",
                    "SKIPPED [" + obj.getCimType() + "] is a logical node.", null));
        }

        // Stage 5: Cross-object — PHYSICAL ONLY
        findings.addAll(crossStage.run(physical, jobId));

        return findings;
    }
}

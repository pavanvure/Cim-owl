package com.cim.pipeline.result;

import com.cim.model.cim.CIMObject;

/**
 * One finding produced by any pipeline stage.
 */
public class PipelineFinding {

    public enum Severity { ERROR, WARNING, INFO }

    private final String   jobId;
    private final Severity severity;
    private final String   stage;
    private final String   objectType;
    private final String   objectId;
    private final String   objectName;
    private final String   attributeTag;
    private final String   message;
    private final String   resolvedPath;
    private final String   sourceFormat;

    private PipelineFinding(String jobId, Severity severity, String stage,
                             String objectType, String objectId, String objectName,
                             String attributeTag, String message,
                             String resolvedPath, String sourceFormat) {
        this.jobId        = jobId;
        this.severity     = severity;
        this.stage        = stage;
        this.objectType   = objectType;
        this.objectId     = objectId;
        this.objectName   = objectName;
        this.attributeTag = attributeTag;
        this.message      = message;
        this.resolvedPath = resolvedPath;
        this.sourceFormat = sourceFormat;
    }

    public static PipelineFinding error(String jobId, String stage, CIMObject obj,
                                         String tag, String msg, String path) {
        return new PipelineFinding(jobId, Severity.ERROR, stage,
                obj.getCimType(), obj.getRdfId(), obj.getName(),
                tag, msg, path, obj.getSourceFormat());
    }

    public static PipelineFinding warning(String jobId, String stage, CIMObject obj,
                                           String tag, String msg, String path) {
        return new PipelineFinding(jobId, Severity.WARNING, stage,
                obj.getCimType(), obj.getRdfId(), obj.getName(),
                tag, msg, path, obj.getSourceFormat());
    }

    public static PipelineFinding info(String jobId, String stage, CIMObject obj,
                                        String tag, String msg, String path) {
        return new PipelineFinding(jobId, Severity.INFO, stage,
                obj.getCimType(), obj.getRdfId(), obj.getName(),
                tag, msg, path, obj.getSourceFormat());
    }

    public boolean isError()   { return severity == Severity.ERROR; }
    public boolean isWarning() { return severity == Severity.WARNING; }
    public boolean isInfo()    { return severity == Severity.INFO; }

    public String   getJobId()        { return jobId; }
    public Severity getSeverity()     { return severity; }
    public String   getStage()        { return stage; }
    public String   getObjectType()   { return objectType; }
    public String   getObjectId()     { return objectId; }
    public String   getObjectName()   { return objectName; }
    public String   getAttributeTag() { return attributeTag; }
    public String   getMessage()      { return message; }
    public String   getResolvedPath() { return resolvedPath; }
    public String   getSourceFormat() { return sourceFormat; }

    @Override
    public String toString() {
        return String.format("[%s][%s] %s.%s : %s",
                severity, stage, objectType, attributeTag, message);
    }
}

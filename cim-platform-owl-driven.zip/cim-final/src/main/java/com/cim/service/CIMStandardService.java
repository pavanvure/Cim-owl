package com.cim.service;

import com.cim.model.mongo.CimClassDefinition;
import com.cim.repository.CimClassRepository;
import com.cim.validation.registry.CIMHierarchyRegistry;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.context.event.ApplicationReadyEvent;
import org.springframework.context.event.EventListener;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import java.io.*;
import java.nio.file.*;
import java.util.List;

/**
 * ════════════════════════════════════════════════════════════════════
 * CIM STANDARD SERVICE — OWL-driven (zero hardcoded class data)
 * ════════════════════════════════════════════════════════════════════
 *
 * BEFORE: CIMStandardService had ~200 lines of hardcoded maps:
 *   getParentMap()       — 60+ hardcoded class → parent entries
 *   getAttributeMap()    — 15+ classes with hardcoded attribute lists
 *   getPackageMap()      — 20+ hardcoded package assignments
 *   getLogicalClasses()  — 25+ hardcoded logical class names
 *
 * AFTER: Zero hardcoded data.
 *   All class hierarchy, attributes, packages, and categories
 *   are read directly from the official CIM OWL ontology file.
 *
 * Benefits:
 *   ✅ Automatically correct — no manual sync with CIM spec needed
 *   ✅ Supports any CIM version (CIM15, CIM16, CIM17, CIM18...)
 *      just by uploading a different OWL file
 *   ✅ Captures ALL classes (~500+) not just the ~60 we hardcoded
 *   ✅ Captures ALL attributes from the spec, not a hand-picked subset
 *   ✅ Admin can update the CIM standard without a code deployment
 *
 * OWL file location (configure in application.yml):
 *   cim.owl.file-path: /data/cim/iec61970cim17v40.owl
 *
 * Fallback: if no OWL file is configured and MongoDB is empty,
 *           the application starts but registry is empty (warns).
 */
@Service
public class CIMStandardService {

    private static final Logger log = LoggerFactory.getLogger(CIMStandardService.class);

    @Value("${cim.owl.file-path:}")
    private String owlFilePath;

    @Value("${cim.owl.version:CIM17}")
    private String defaultCimVersion;

    private final CimClassRepository  mongoRepo;
    private final CIMHierarchyRegistry registry;
    private final CIMOwlParser         owlParser;

    public CIMStandardService(CimClassRepository mongoRepo,
                               CIMHierarchyRegistry registry,
                               CIMOwlParser owlParser) {
        this.mongoRepo  = mongoRepo;
        this.registry   = registry;
        this.owlParser  = owlParser;
    }

    // ── Startup ───────────────────────────────────────────────────────────

    @EventListener(ApplicationReadyEvent.class)
    public void initOnStartup() {
        if (mongoRepo.count() > 0) {
            // Already seeded — just load into registry
            List<CimClassDefinition> existing = mongoRepo.findAll();
            registry.load(existing);
            log.info("CIM registry loaded from MongoDB: {} classes", registry.size());
            return;
        }

        // First run — try to load from OWL file
        if (owlFilePath != null && !owlFilePath.isBlank()) {
            File owlFile = new File(owlFilePath);
            if (owlFile.exists() && owlFile.isFile()) {
                try {
                    loadFromOwlFile(owlFile, defaultCimVersion);
                    return;
                } catch (Exception e) {
                    log.error("Failed to load OWL file '{}': {}", owlFilePath, e.getMessage());
                }
            } else {
                log.warn("OWL file not found at '{}'. Registry will be empty.", owlFilePath);
            }
        } else {
            log.warn("cim.owl.file-path not configured. "
                   + "Upload OWL file via POST /api/admin/cim/upload-owl "
                   + "or set the path in application.yml.");
        }
    }

    // ── Admin: upload OWL file via REST ──────────────────────────────────

    /**
     * Called by POST /api/admin/cim/upload-owl
     * Admin uploads the official CIM OWL file once.
     * Parses it and stores all class definitions in MongoDB + registry.
     */
    public AdminLoadResult loadFromUploadedOwl(MultipartFile owlFile,
                                                String cimVersion) throws Exception {
        log.info("Loading CIM OWL from uploaded file: {} ({} bytes)",
                owlFile.getOriginalFilename(), owlFile.getSize());

        List<CimClassDefinition> defs =
                owlParser.parse(owlFile.getInputStream(), cimVersion);

        persistDefinitions(defs);

        return new AdminLoadResult(
                cimVersion,
                defs.size(),
                (int) defs.stream().filter(d -> "PHYSICAL".equals(d.getCategory())).count(),
                (int) defs.stream().filter(d -> "LOGICAL".equals(d.getCategory())).count()
        );
    }

    /**
     * Called by POST /api/admin/cim/reload?version=CIM17
     * Reloads from the configured file path.
     */
    public AdminLoadResult reloadFromConfiguredFile(String cimVersion) throws Exception {
        String path = (cimVersion != null && !cimVersion.isBlank())
                ? owlFilePath
                : owlFilePath;

        if (path == null || path.isBlank()) {
            throw new IllegalStateException(
                    "No OWL file path configured. Set cim.owl.file-path in application.yml "
                    + "or use POST /api/admin/cim/upload-owl to upload the file directly.");
        }

        File owlFile = new File(path);
        if (!owlFile.exists()) {
            throw new FileNotFoundException("OWL file not found: " + path);
        }

        return loadFromOwlFile(owlFile, cimVersion != null ? cimVersion : defaultCimVersion);
    }

    // ── Internal load helpers ─────────────────────────────────────────────

    private AdminLoadResult loadFromOwlFile(File owlFile,
                                             String cimVersion) throws Exception {
        log.info("Parsing OWL file: {} ({} MB)",
                owlFile.getName(),
                String.format("%.1f", owlFile.length() / (1024.0 * 1024.0)));

        List<CimClassDefinition> defs;
        try (InputStream is = new BufferedInputStream(
                new FileInputStream(owlFile), 64 * 1024)) {
            defs = owlParser.parse(is, cimVersion);
        }

        persistDefinitions(defs);

        AdminLoadResult result = new AdminLoadResult(
                cimVersion, defs.size(),
                (int) defs.stream().filter(d -> "PHYSICAL".equals(d.getCategory())).count(),
                (int) defs.stream().filter(d -> "LOGICAL".equals(d.getCategory())).count()
        );

        log.info("CIM OWL loaded: {} total classes ({} physical, {} logical)",
                result.totalClasses(), result.physicalClasses(), result.logicalClasses());

        return result;
    }

    private void persistDefinitions(List<CimClassDefinition> defs) {
        // Clear existing and replace
        mongoRepo.deleteAll();
        mongoRepo.saveAll(defs);
        registry.load(defs);
    }

    // ── Result DTO ────────────────────────────────────────────────────────

    public record AdminLoadResult(
            String cimVersion,
            int    totalClasses,
            int    physicalClasses,
            int    logicalClasses
    ) {}
}

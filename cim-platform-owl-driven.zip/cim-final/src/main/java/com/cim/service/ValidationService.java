package com.cim.service;

import com.cim.adapter.AdapterRegistry;
import com.cim.adapter.CIMFormatAdapter;
import com.cim.model.cim.CIMObject;
import com.cim.model.mongo.*;
import com.cim.pipeline.result.PipelineFinding;
import com.cim.pipeline.stage.ValidationPipeline;
import com.cim.repository.*;
import com.cim.util.MapKeySanitizer;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import java.time.Instant;
import java.util.*;
import java.util.concurrent.CompletableFuture;
import java.util.stream.Collectors;

/**
 * ValidationService — Updated End-to-End Flow (small/medium files ≤ 50MB)
 *
 * Step 2  Receive uploaded file
 * Step 3  Auto-detect format (AdapterRegistry)
 * Step 4  Parse → List<CIMObject>  (common model)
 * Step 5  Store ALL objects to MongoDB (cim_objects) — BEFORE validation
 *         Future re-validation or querying without re-upload
 * Step 6  Run 4-stage validation pipeline on the parsed objects
 * Step 7  Save findings + update job status in MongoDB
 */
@Service
public class ValidationService {

    private final AdapterRegistry             adapterRegistry;
    private final ValidationPipeline          pipeline;
    private final ValidationJobRepository     jobRepo;
    private final CimObjectRecordRepository   objectRepo;
    private final ValidationFindingRepository findingRepo;

    public ValidationService(AdapterRegistry adapterRegistry,
                              ValidationPipeline pipeline,
                              ValidationJobRepository jobRepo,
                              CimObjectRecordRepository objectRepo,
                              ValidationFindingRepository findingRepo) {
        this.adapterRegistry = adapterRegistry;
        this.pipeline        = pipeline;
        this.jobRepo         = jobRepo;
        this.objectRepo      = objectRepo;
        this.findingRepo     = findingRepo;
    }

    public ValidationSummary validateSync(MultipartFile file,
                                           String submittedBy) throws Exception {
        return execute(UUID.randomUUID().toString(),
                file.getOriginalFilename(), file.getBytes(), submittedBy);
    }

    @Async
    public CompletableFuture<ValidationSummary> validateAsync(
            MultipartFile file, String submittedBy) throws Exception {
        String jobId = UUID.randomUUID().toString();
        ValidationJob job = new ValidationJob(jobId, file.getOriginalFilename(), "DETECTING", submittedBy);
        jobRepo.save(job);
        return CompletableFuture.completedFuture(
                execute(jobId, file.getOriginalFilename(), file.getBytes(), submittedBy));
    }

    private ValidationSummary execute(String jobId, String fileName,
                                       byte[] bytes, String submittedBy) throws Exception {
        long start = System.currentTimeMillis();

        // ── Step 3: Detect format ─────────────────────────────────────────
        CIMFormatAdapter adapter;
        try {
            adapter = adapterRegistry.detect(
                    Arrays.copyOf(bytes, Math.min(512, bytes.length)), fileName);
        } catch (IllegalArgumentException e) {
            return failJob(jobId, fileName, "UNKNOWN", submittedBy,
                    e.getMessage(), elapsed(start));
        }
        String format = adapter.getFormatName();

        ValidationJob job = jobRepo.findByJobId(jobId)
                .orElse(new ValidationJob(jobId, fileName, format, submittedBy));
        job.setFileFormat(format);
        job.setStatus("RUNNING");
        jobRepo.save(job);

        // ── Step 4: Parse → common model ─────────────────────────────────
        List<CIMObject> objects;
        try {
            objects = adapter.parse(new java.io.ByteArrayInputStream(bytes), fileName);
        } catch (Exception e) {
            return failJob(jobId, fileName, format, submittedBy,
                    "Parse error: " + e.getMessage(), elapsed(start));
        }

        // ── Step 5: Store ALL parsed objects to MongoDB ───────────────────
        // Stored BEFORE validation so data is persisted even if validation fails.
        // Enables re-querying without re-uploading the file.
        objectRepo.saveAll(objects.stream()
                .map(o -> toRecord(o, jobId))
                .collect(Collectors.toList()));

        // ── Step 6: Run 4-stage validation pipeline ───────────────────────
        List<PipelineFinding> findings = pipeline.run(objects, jobId);

        // ── Step 7: Save findings + update job ────────────────────────────
        findingRepo.saveAll(findings.stream()
                .map(this::toFindingDoc)
                .collect(Collectors.toList()));

        long el = elapsed(start);
        long errors   = findings.stream().filter(PipelineFinding::isError).count();
        long warnings = findings.stream().filter(PipelineFinding::isWarning).count();
        long infos    = findings.stream().filter(PipelineFinding::isInfo).count();
        long physical = objects.stream().filter(o -> !LOGICAL_TYPES.contains(o.getCimType())).count();

        job.setStatus(errors > 0 ? "FAILED" : "DONE");
        job.setTotalObjects(objects.size());
        job.setPhysicalObjects((int) physical);
        job.setLogicalObjects((int)(objects.size() - physical));
        job.setErrorCount((int) errors);
        job.setWarningCount((int) warnings);
        job.setInfoCount((int) infos);
        job.setCompletedAt(Instant.now());
        job.setProcessingMs(el);
        jobRepo.save(job);

        return new ValidationSummary(jobId, fileName, format, objects.size(),
                (int) physical, (int)(objects.size()-physical),
                (int) errors, (int) warnings, (int) infos,
                errors > 0 ? "FAILED" : "PASSED", el);
    }

    private CimObjectRecord toRecord(CIMObject obj, String jobId) {
        CimObjectRecord r = new CimObjectRecord();
        r.setJobId(jobId);
        r.setRdfId(obj.getRdfId());
        r.setMrid(obj.getMrid());
        r.setCimType(obj.getCimType());
        r.setName(obj.getName());
        r.setCategory(LOGICAL_TYPES.contains(obj.getCimType()) ? "LOGICAL" : "PHYSICAL");
        r.setSourceFormat(obj.getSourceFormat());
        r.setSourceFile(obj.getSourceFile());
        r.setOrgId(obj.getOrgId());
        r.setVersion(obj.getVersion());
        r.setAttributes(MapKeySanitizer.encodeKeys(obj.getAttributes()));
        r.setReferences(MapKeySanitizer.encodeKeys(obj.getReferences()));
        r.setCreatedAt(Instant.now());
        return r;
    }

    private ValidationFinding toFindingDoc(PipelineFinding f) {
        return new ValidationFinding(f.getJobId(), f.getSeverity().name(),
                f.getStage(), f.getObjectType(), f.getObjectId(),
                f.getObjectName(), f.getAttributeTag(), f.getMessage(),
                f.getResolvedPath(), f.getSourceFormat());
    }

    private ValidationSummary failJob(String jobId, String fileName, String format,
                                       String submittedBy, String msg, long el) {
        ValidationJob job = jobRepo.findByJobId(jobId)
                .orElse(new ValidationJob(jobId, fileName, format, submittedBy));
        job.setStatus("FAILED"); job.setErrorMessage(msg);
        job.setCompletedAt(Instant.now()); job.setProcessingMs(el);
        jobRepo.save(job);
        return new ValidationSummary(jobId, fileName, format, 0,0,0,1,0,0,"FAILED",el);
    }

    private long elapsed(long start) { return System.currentTimeMillis() - start; }

    private static final Set<String> LOGICAL_TYPES = Set.of(
        "ConnectivityNode","TopologicalNode","TopologicalIsland","Terminal",
        "ACDCTerminal","Measurement","Accumulator","Analog","Discrete",
        "AccumulatorValue","AnalogValue","DiscreteValue","LoadGroup",
        "ConformLoadGroup","NonConformLoadGroup","LoadArea","SubLoadArea",
        "EnergyArea","RegulatingControl","RegulationSchedule","TapChangerControl",
        "BranchGroup","Name","NameType","Location","PowerCutZone"
    );
}

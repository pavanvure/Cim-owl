package com.cim.service;

/**
 * Summary returned after a validation job completes.
 */
public class ValidationSummary {

    private final String jobId;
    private final String fileName;
    private final String format;
    private final int    totalObjects;
    private final int    physicalObjects;
    private final int    logicalObjects;
    private final int    errorCount;
    private final int    warningCount;
    private final int    infoCount;
    private final String status;      // "PASSED" or "FAILED"
    private final long   elapsedMs;

    public ValidationSummary(String jobId, String fileName, String format,
                              int totalObjects, int physicalObjects, int logicalObjects,
                              int errorCount, int warningCount, int infoCount,
                              String status, long elapsedMs) {
        this.jobId           = jobId;
        this.fileName        = fileName;
        this.format          = format;
        this.totalObjects    = totalObjects;
        this.physicalObjects = physicalObjects;
        this.logicalObjects  = logicalObjects;
        this.errorCount      = errorCount;
        this.warningCount    = warningCount;
        this.infoCount       = infoCount;
        this.status          = status;
        this.elapsedMs       = elapsedMs;
    }

    public String getJobId()           { return jobId; }
    public String getFileName()        { return fileName; }
    public String getFormat()          { return format; }
    public int    getTotalObjects()    { return totalObjects; }
    public int    getPhysicalObjects() { return physicalObjects; }
    public int    getLogicalObjects()  { return logicalObjects; }
    public int    getErrorCount()      { return errorCount; }
    public int    getWarningCount()    { return warningCount; }
    public int    getInfoCount()       { return infoCount; }
    public String getStatus()          { return status; }
    public long   getElapsedMs()       { return elapsedMs; }
}

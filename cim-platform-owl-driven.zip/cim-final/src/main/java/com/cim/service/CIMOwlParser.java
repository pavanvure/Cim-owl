package com.cim.service;

import com.cim.model.mongo.CimClassDefinition;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import javax.xml.stream.XMLInputFactory;
import javax.xml.stream.XMLStreamConstants;
import javax.xml.stream.XMLStreamReader;
import java.io.*;
import java.util.*;

/**
 * ════════════════════════════════════════════════════════════════════
 * CIM OWL FILE PARSER
 * ════════════════════════════════════════════════════════════════════
 *
 * Parses the official CIM OWL ontology file (e.g. iec61970cim17v40.owl)
 * and extracts:
 *
 *   - Every class name           (rdfs:Class / owl:Class)
 *   - Parent class               (rdfs:subClassOf)
 *   - Own attributes             (rdfs:domain → class, rdfs:range → type)
 *   - CIM package                (from namespace or comment)
 *   - Category (PHYSICAL/LOGICAL) — derived from package + stereotype
 *
 * Replaces ALL hardcoded maps in CIMStandardService:
 *   getParentMap()      → parsed from owl:Class + rdfs:subClassOf
 *   getAttributeMap()   → parsed from owl:DatatypeProperty + rdfs:domain
 *   getPackageMap()     → parsed from class namespace/package annotation
 *   getLogicalClasses() → derived from stereotype annotation
 *
 * Uses StAX XMLStreamReader (cursor API) for:
 *   - Minimal heap memory — no DOM tree built
 *   - Fast parsing — single pass through the OWL file
 *   - OWL files are typically 5-50MB so memory is not critical here,
 *     but consistency with the streaming philosophy is maintained.
 *
 * OWL file structure (RDF/XML serialization):
 *
 *   <owl:Class rdf:about="...#ACLineSegment">
 *     <rdfs:label>ACLineSegment</rdfs:label>
 *     <rdfs:subClassOf rdf:resource="...#Conductor"/>
 *     <cims:belongsToCategory rdf:resource="...#Wires"/>
 *     <cims:stereotype>Concrete</cims:stereotype>
 *   </owl:Class>
 *
 *   <owl:DatatypeProperty rdf:about="...#ACLineSegment.r">
 *     <rdfs:label>r</rdfs:label>
 *     <rdfs:domain rdf:resource="...#ACLineSegment"/>
 *     <rdfs:range rdf:resource="...#Resistance"/>
 *   </owl:DatatypeProperty>
 */
@Component
public class CIMOwlParser {

    private static final Logger log = LoggerFactory.getLogger(CIMOwlParser.class);

    // OWL / RDF / RDFS namespaces
    private static final String NS_RDF   = "http://www.w3.org/1999/02/22-rdf-syntax-ns#";
    private static final String NS_RDFS  = "http://www.w3.org/2000/01/rdf-schema#";
    private static final String NS_OWL   = "http://www.w3.org/2002/07/owl#";
    private static final String NS_CIMS  = "http://iec.ch/TC57/1999/rdf-schema-extensions-19990926#";

    // CIM stereotypes that indicate a LOGICAL (non-physical) class
    private static final Set<String> LOGICAL_STEREOTYPES = Set.of(
        "abstract","Primitive","CIMDatatype","enumeration","Compound"
    );

    // Well-known logical packages regardless of stereotype
    private static final Set<String> LOGICAL_PACKAGES = Set.of(
        "Topology","Meas","StateVariables","LoadModel","Contingency",
        "InfWork","InfAssets","InfLocations","InfOperations",
        "IEC61968CIMVersion","IEC61970CIMVersion"
    );

    // ── Internal intermediate model ────────────────────────────────────────

    /** Holds raw data for one class during parse, before building CimClassDefinition */
    private static class ClassEntry {
        String name;
        String parentUri;         // raw URI, stripped to local name later
        String packageName;
        String stereotype;
        String description;
        List<String> ownAttributes = new ArrayList<>();

        ClassEntry(String name) { this.name = name; }
    }

    // ── Public API ─────────────────────────────────────────────────────────

    /**
     * Parse the OWL file from an InputStream.
     * Returns a fully-built list of CimClassDefinition ready for MongoDB.
     *
     * @param owlStream  InputStream of the .owl file
     * @param cimVersion version label e.g. "CIM17v40"
     * @return           all class definitions with computed ancestor chains
     */
    public List<CimClassDefinition> parse(InputStream owlStream,
                                           String cimVersion) throws Exception {
        log.info("Parsing CIM OWL ontology — version: {}", cimVersion);
        long start = System.currentTimeMillis();

        // ── Pass 1: Extract raw class and property data ────────────────────
        Map<String, ClassEntry>      classes    = new LinkedHashMap<>();
        Map<String, List<String>>    domainMap  = new LinkedHashMap<>();
        // domainMap: className → list of attribute local names declared on it

        parseOwlFile(owlStream, classes, domainMap);

        log.info("OWL parse pass 1 complete: {} classes, {} property domains",
                classes.size(), domainMap.size());

        // Attach own attributes to each class
        domainMap.forEach((className, attrs) -> {
            ClassEntry entry = classes.get(className);
            if (entry != null) entry.ownAttributes.addAll(attrs);
        });

        // ── Pass 2: Resolve parent names, compute ancestors ────────────────
        // Build localName → parentLocalName map first
        Map<String, String> parentMap = new LinkedHashMap<>();
        classes.forEach((name, entry) -> {
            if (entry.parentUri != null) {
                String parentName = localName(entry.parentUri);
                if (parentName != null && !parentName.equals(name)) {
                    parentMap.put(name, parentName);
                }
            }
        });

        // ── Pass 3: Build CimClassDefinition objects ───────────────────────
        List<CimClassDefinition> defs = new ArrayList<>();

        classes.forEach((name, entry) -> {
            List<String> ancestors = computeAncestors(name, parentMap);
            String category        = determineCategory(entry);

            CimClassDefinition def = new CimClassDefinition(
                    name,
                    parentMap.get(name),
                    ancestors,
                    new ArrayList<>(entry.ownAttributes),
                    category,
                    cimVersion
            );
            def.setCimPackage(entry.packageName != null ? entry.packageName : "Core");
            def.setDescription(entry.description);
            defs.add(def);
        });

        long elapsed = System.currentTimeMillis() - start;
        log.info("OWL parse complete: {} class definitions built in {}ms",
                defs.size(), elapsed);

        return defs;
    }

    // ── StAX single-pass OWL parser ────────────────────────────────────────

    private void parseOwlFile(InputStream owlStream,
                               Map<String, ClassEntry>   classes,
                               Map<String, List<String>> domainMap) throws Exception {

        XMLInputFactory factory = XMLInputFactory.newInstance();
        factory.setProperty(XMLInputFactory.IS_SUPPORTING_EXTERNAL_ENTITIES, false);
        factory.setProperty(XMLInputFactory.SUPPORT_DTD, false);
        factory.setProperty(XMLInputFactory.IS_COALESCING, true);

        XMLStreamReader reader = factory.createXMLStreamReader(
                new BufferedInputStream(owlStream, 64 * 1024));

        // State for current element being parsed
        String        currentType       = null; // "CLASS" or "PROPERTY"
        String        currentUri        = null; // rdf:about of current element
        ClassEntry    currentClass      = null;
        String        currentPropName   = null; // local name of property (e.g. "r")
        String        currentDomain     = null; // class that owns this property
        StringBuilder textBuf           = new StringBuilder(256);
        String        currentTag        = null; // local name of child element

        try {
            while (reader.hasNext()) {
                int event = reader.next();

                switch (event) {

                    case XMLStreamConstants.START_ELEMENT -> {
                        String ns    = reader.getNamespaceURI();
                        String local = reader.getLocalName();
                        currentTag   = local;
                        textBuf.setLength(0);

                        // ── Top-level class or property declaration ────────
                        if (isOwlNs(ns) || isRdfNs(ns)) {

                            if ("Class".equals(local) || "NamedIndividual".equals(local)) {
                                // owl:Class — a CIM class
                                currentUri  = reader.getAttributeValue(NS_RDF, "about");
                                currentType = "CLASS";
                                if (currentUri != null) {
                                    String name = localName(currentUri);
                                    if (name != null) {
                                        currentClass = classes.computeIfAbsent(
                                                name, ClassEntry::new);
                                    }
                                }

                            } else if ("DatatypeProperty".equals(local)
                                    || "ObjectProperty".equals(local)) {
                                // owl:DatatypeProperty — a CIM attribute or association
                                currentUri  = reader.getAttributeValue(NS_RDF, "about");
                                currentType = "PROPERTY";
                                if (currentUri != null) {
                                    // Property name is after the last '.'
                                    // e.g. "...#ACLineSegment.r" → local name = "r"
                                    currentPropName = propertyLocalName(currentUri);
                                }
                            }
                        }

                        // ── Child elements of current class/property ───────
                        if ("CLASS".equals(currentType) && currentClass != null) {
                            if (isRdfsNs(ns)) {
                                if ("subClassOf".equals(local)) {
                                    // rdfs:subClassOf rdf:resource="...#Conductor"
                                    String ref = reader.getAttributeValue(NS_RDF, "resource");
                                    if (ref != null && !ref.isBlank()) {
                                        currentClass.parentUri = ref;
                                    }
                                }
                            }
                            if (isCimsNs(ns)) {
                                if ("belongsToCategory".equals(local)) {
                                    // cims:belongsToCategory → package
                                    String ref = reader.getAttributeValue(NS_RDF, "resource");
                                    if (ref != null) {
                                        currentClass.packageName = localName(ref);
                                    }
                                }
                            }
                        }

                        if ("PROPERTY".equals(currentType)) {
                            if (isRdfsNs(ns) && "domain".equals(local)) {
                                // rdfs:domain rdf:resource="...#ACLineSegment"
                                String ref = reader.getAttributeValue(NS_RDF, "resource");
                                if (ref != null) {
                                    currentDomain = localName(ref);
                                }
                            }
                        }
                    }

                    case XMLStreamConstants.CHARACTERS,
                         XMLStreamConstants.CDATA -> {
                        textBuf.append(reader.getText());
                    }

                    case XMLStreamConstants.END_ELEMENT -> {
                        String ns    = reader.getNamespaceURI();
                        String local = reader.getLocalName();
                        String text  = textBuf.toString().trim();

                        // ── Collect text values inside class element ───────
                        if ("CLASS".equals(currentType) && currentClass != null) {
                            if (isRdfsNs(ns) && "comment".equals(local)) {
                                if (!text.isEmpty()) currentClass.description = text;
                            }
                            if (isCimsNs(ns) && "stereotype".equals(local)) {
                                if (!text.isEmpty()) currentClass.stereotype = text;
                            }
                        }

                        // ── Close of top-level class element ───────────────
                        if ((isOwlNs(ns) || isRdfNs(ns))
                                && ("Class".equals(local) || "NamedIndividual".equals(local))) {
                            currentType  = null;
                            currentClass = null;
                            currentUri   = null;
                        }

                        // ── Close of top-level property element ───────────
                        if ((isOwlNs(ns) || isRdfNs(ns))
                                && ("DatatypeProperty".equals(local)
                                    || "ObjectProperty".equals(local))) {

                            // Register property against its domain class
                            if (currentDomain != null && currentPropName != null
                                    && !currentPropName.isBlank()) {
                                domainMap.computeIfAbsent(currentDomain,
                                        k -> new ArrayList<>())
                                        .add(currentPropName);
                            }
                            currentType     = null;
                            currentPropName = null;
                            currentDomain   = null;
                            currentUri      = null;
                        }

                        textBuf.setLength(0);
                    }
                }
            }
        } finally {
            reader.close();
        }
    }

    // ── Ancestor computation ───────────────────────────────────────────────

    private List<String> computeAncestors(String className,
                                           Map<String, String> parentMap) {
        List<String> ancestors = new ArrayList<>();
        Set<String>  visited   = new HashSet<>();
        String       current   = parentMap.get(className);
        while (current != null && !visited.contains(current)) {
            ancestors.add(current);
            visited.add(current);
            current = parentMap.get(current);
        }
        return ancestors;
    }

    // ── Category determination ─────────────────────────────────────────────

    /**
     * Determines PHYSICAL or LOGICAL category from OWL metadata.
     *
     * LOGICAL if:
     *   - stereotype is "abstract", "Primitive", "CIMDatatype", "enumeration"
     *   - package is topology, measurements, or scheduling related
     *   - class name ends in typical logical suffixes (Value, Schedule, etc.)
     *
     * PHYSICAL otherwise (real field equipment).
     */
    private String determineCategory(ClassEntry entry) {
        // Stereotype check
        if (entry.stereotype != null
                && LOGICAL_STEREOTYPES.contains(entry.stereotype)) {
            return "LOGICAL";
        }

        // Package check
        if (entry.packageName != null
                && LOGICAL_PACKAGES.contains(entry.packageName)) {
            return "LOGICAL";
        }

        // Name suffix heuristic for well-known logical patterns
        if (entry.name != null) {
            String n = entry.name;
            if (n.endsWith("Value") || n.endsWith("Schedule")
                    || n.endsWith("Island") || n.endsWith("Node")
                    || n.equals("Terminal") || n.equals("ACDCTerminal")
                    || n.equals("DCTerminal")
                    || n.endsWith("Type") || n.endsWith("Kind")) {
                return "LOGICAL";
            }
        }

        return "PHYSICAL";
    }

    // ── Namespace helpers ─────────────────────────────────────────────────

    private boolean isOwlNs(String ns)  { return NS_OWL.equals(ns); }
    private boolean isRdfNs(String ns)  { return NS_RDF.equals(ns); }
    private boolean isRdfsNs(String ns) { return NS_RDFS.equals(ns); }
    private boolean isCimsNs(String ns) { return NS_CIMS.equals(ns) || (ns != null && ns.contains("rdf-schema-extensions")); }

    /**
     * Extracts local name from a URI.
     * "http://iec.ch/TC57/2013/CIM-schema-cim17#ACLineSegment" → "ACLineSegment"
     * Also handles "/" separator.
     */
    private String localName(String uri) {
        if (uri == null) return null;
        int hash  = uri.lastIndexOf('#');
        int slash = uri.lastIndexOf('/');
        int idx   = Math.max(hash, slash);
        return (idx >= 0 && idx < uri.length() - 1)
                ? uri.substring(idx + 1)
                : uri;
    }

    /**
     * For property URIs like "...#ACLineSegment.r", extracts "r".
     * For "...#IdentifiedObject.mRID", extracts "mRID".
     * Falls back to full local name if no dot present.
     */
    private String propertyLocalName(String uri) {
        String local = localName(uri);
        if (local == null) return null;
        int dot = local.lastIndexOf('.');
        return (dot >= 0 && dot < local.length() - 1)
                ? local.substring(dot + 1)
                : local;
    }
}

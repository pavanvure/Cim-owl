package com.cim.adapter;

import com.cim.model.cim.CIMObject;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.springframework.stereotype.Component;

import java.io.InputStream;
import java.util.*;

/**
 * Adapter for CIM JSON-LD format.
 *
 * Handles JSON-LD serializations from GridAPPS-D, OpenDSS CIM exports,
 * and modern CIM tools that emit JSON-LD instead of RDF/XML.
 *
 * Supported structures:
 *
 * Single object:
 * { "@type": "cim:ACLineSegment", "@id": "_uuid",
 *   "cim:ACLineSegment.r": 0.5,
 *   "cim:ConductingEquipment.BaseVoltage": {"@id": "_bv-uuid"} }
 *
 * Array of objects (most common):
 * [ { "@type": "cim:ACLineSegment", ... }, { "@type": "cim:BaseVoltage", ... } ]
 *
 * Wrapped in @graph:
 * { "@context": {...}, "@graph": [ {...}, {...} ] }
 */
@Component
public class JsonLdAdapter implements CIMFormatAdapter {

    private static final String FORMAT = "JSON_LD";
    private final ObjectMapper mapper  = new ObjectMapper();

    @Override
    public boolean supports(byte[] sample, String fileName) {
        if (fileName != null && fileName.toLowerCase().endsWith(".json")) return true;
        String start = new String(sample, 0, Math.min(500, sample.length)).trim();
        return start.contains("@context") || start.contains("@type")
                || start.contains("@graph") || start.contains("cim:");
    }

    @Override
    public String getFormatName() { return FORMAT; }

    @Override
    public List<CIMObject> parse(InputStream inputStream, String fileName) throws Exception {
        JsonNode root = mapper.readTree(inputStream);
        List<CIMObject> objects = new ArrayList<>();

        // Handle three JSON-LD structures
        if (root.isArray()) {
            // Array of objects
            root.forEach(node -> parseJsonLdNode(node, fileName, objects));
        } else if (root.has("@graph")) {
            // Wrapped in @graph
            root.get("@graph").forEach(node -> parseJsonLdNode(node, fileName, objects));
        } else if (root.isObject()) {
            // Single object
            parseJsonLdNode(root, fileName, objects);
        }

        resolveReferences(objects);
        return objects;
    }

    private void parseJsonLdNode(JsonNode node, String fileName, List<CIMObject> objects) {
        if (!node.isObject()) return;

        // Extract type
        String rawType = getTextValue(node, "@type");
        if (rawType == null || rawType.isBlank()) return;
        String cimType = stripPrefix(rawType);

        // Extract ID
        String rdfId = getTextValue(node, "@id");
        if (rdfId == null || rdfId.isBlank()) return;
        rdfId = cleanRef(rdfId);

        CIMObject obj = new CIMObject(cimType, rdfId);
        obj.setMrid(rdfId); // default mRID = rdfId
        obj.setSourceFormat(FORMAT);
        obj.setSourceFile(fileName);

        // Iterate all fields
        node.fields().forEachRemaining(entry -> {
            String rawKey = entry.getKey();
            JsonNode val  = entry.getValue();

            if (rawKey.startsWith("@")) return; // skip @type, @id, @context

            String key = stripPrefix(rawKey); // "cim:ACLineSegment.r" → "ACLineSegment.r"

            if (val.isObject() && val.has("@id")) {
                // Reference: {"@id": "_uuid"}
                String targetId = cleanRef(val.get("@id").asText());
                obj.addReference(key, targetId);
            } else if (val.isArray() && val.size() > 0 && val.get(0).has("@id")) {
                // Array reference (one-to-many)
                val.forEach(refNode -> {
                    if (refNode.has("@id")) {
                        obj.addReference(key, cleanRef(refNode.get("@id").asText()));
                    }
                });
            } else {
                // Plain value
                String strVal = val.isTextual() ? val.asText() : val.toString();
                obj.setAttribute(key, strVal.trim());
            }
        });

        objects.add(obj);
    }

    private void resolveReferences(List<CIMObject> objects) {
        Map<String, CIMObject> byId = new LinkedHashMap<>();
        for (CIMObject o : objects) byId.put(o.getRdfId(), o);
        for (CIMObject o : objects) {
            for (Map.Entry<String, String> ref : o.getReferences().entrySet()) {
                CIMObject target = byId.get(ref.getValue());
                if (target != null) o.addResolved(ref.getKey(), target);
            }
        }
    }

    private String getTextValue(JsonNode node, String field) {
        JsonNode n = node.get(field);
        if (n == null) return null;
        return n.isTextual() ? n.asText() : n.toString();
    }

    /** "cim:ACLineSegment" → "ACLineSegment", "md:Model" → "Model" */
    private String stripPrefix(String s) {
        if (s == null) return null;
        int colon = s.lastIndexOf(':');
        return colon >= 0 ? s.substring(colon + 1) : s;
    }

    private String cleanRef(String v) {
        if (v == null) return null;
        v = v.trim();
        if (v.startsWith("#")) v = v.substring(1);
        return v;
    }
}

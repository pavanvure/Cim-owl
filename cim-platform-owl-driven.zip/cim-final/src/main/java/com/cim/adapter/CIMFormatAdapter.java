package com.cim.adapter;

import com.cim.model.cim.CIMObject;
import java.io.InputStream;
import java.util.List;

/**
 * Plugin interface for CIM file format adapters.
 *
 * Every adapter converts its native format into List<CIMObject>
 * (the common model). The pipeline never sees the raw format.
 *
 * To add a new format:
 *   1. Implement this interface
 *   2. Add @Component
 *   3. Done — AdapterRegistry auto-discovers it via Spring DI
 */
public interface CIMFormatAdapter {

    /**
     * Returns true if this adapter can handle the given file.
     * Called by AdapterRegistry for auto-detection.
     *
     * @param contentSample  first 512 bytes of file content
     * @param fileName       original filename (for extension check)
     */
    boolean supports(byte[] contentSample, String fileName);

    /**
     * Parse the input stream into a list of CIMObjects.
     * Implementations must also resolve rdf:resource cross-references
     * within the same file before returning.
     */
    List<CIMObject> parse(InputStream inputStream, String fileName) throws Exception;

    /** Human-readable format name e.g. "RDF_XML", "JSON_LD" */
    String getFormatName();
}

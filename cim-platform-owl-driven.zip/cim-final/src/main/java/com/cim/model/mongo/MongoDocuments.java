package com.cim.model.mongo;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.index.CompoundIndex;
import org.springframework.data.mongodb.core.index.Indexed;
import org.springframework.data.mongodb.core.mapping.Document;

import java.time.Instant;
import java.util.*;

// ═══════════════════════════════════════════════════════════════════════════
// DOCUMENT 1: CimClassDefinition  →  collection: cim_standard
// Loaded once by Admin. Defines the CIM17 class hierarchy.
// ═══════════════════════════════════════════════════════════════════════════

@Document(collection = "cim_standard")
public class CimClassDefinition {

    @Id
    private String id;

    @Indexed(unique = true)
    private String className;        // "ACLineSegment"

    private String parentClass;      // "Conductor"

    private List<String> ancestors = new ArrayList<>();
    // ["Conductor","ConductingEquipment","Equipment","PowerSystemResource","IdentifiedObject"]

    private List<String> ownAttributes = new ArrayList<>();
    // ["r","x","bch","b0ch","gch","g0ch","x0","r0","x2"]

    private String category;         // "PHYSICAL" or "LOGICAL"
    private String cimPackage;       // "Wires", "Core", "Topology", etc.
    private String cimVersion;       // "CIM17"
    private String description;
    private Instant loadedAt;

    public CimClassDefinition() {}

    public CimClassDefinition(String className, String parentClass,
                               List<String> ancestors, List<String> ownAttributes,
                               String category, String cimVersion) {
        this.className     = className;
        this.parentClass   = parentClass;
        this.ancestors     = ancestors != null ? ancestors : new ArrayList<>();
        this.ownAttributes = ownAttributes != null ? ownAttributes : new ArrayList<>();
        this.category      = category;
        this.cimVersion    = cimVersion;
        this.loadedAt      = Instant.now();
    }

    /** Core validation method: is declaringClass in this class's chain? */
    public boolean isAncestorOrSelf(String declaringClass) {
        if (className.equals(declaringClass)) return true;
        return ancestors.contains(declaringClass);
    }

    public String getId()                   { return id; }
    public String getClassName()            { return className; }
    public void setClassName(String v)      { this.className = v; }
    public String getParentClass()          { return parentClass; }
    public void setParentClass(String v)    { this.parentClass = v; }
    public List<String> getAncestors()      { return ancestors; }
    public void setAncestors(List<String> v){ this.ancestors = v; }
    public List<String> getOwnAttributes()  { return ownAttributes; }
    public void setOwnAttributes(List<String> v){ this.ownAttributes = v; }
    public String getCategory()             { return category; }
    public void setCategory(String v)       { this.category = v; }
    public String getCimPackage()           { return cimPackage; }
    public void setCimPackage(String v)     { this.cimPackage = v; }
    public String getCimVersion()           { return cimVersion; }
    public void setCimVersion(String v)     { this.cimVersion = v; }
    public String getDescription()          { return description; }
    public void setDescription(String v)    { this.description = v; }
    public Instant getLoadedAt()            { return loadedAt; }
    public void setLoadedAt(Instant v)      { this.loadedAt = v; }
}


// ═══════════════════════════════════════════════════════════════════════════
// DOCUMENT 2: ValidationJob  →  collection: validation_jobs
// One document per uploaded file.
// ═══════════════════════════════════════════════════════════════════════════

@Document(collection = "validation_jobs")
class ValidationJob {

    @Id
    private String jobId;

    private String fileName;
    private String fileFormat;   // "RDF_XML","JSON_LD","MILSOFT_CSV","CUSTOM_XML"
    private String status;       // PENDING, RUNNING, DONE, FAILED
    private String submittedBy;

    private int totalObjects;
    private int physicalObjects;
    private int logicalObjects;
    private int errorCount;
    private int warningCount;
    private int infoCount;

    private Instant submittedAt;
    private Instant completedAt;
    private long processingMs;
    private String errorMessage;

    public ValidationJob() {}

    public ValidationJob(String jobId, String fileName,
                          String fileFormat, String submittedBy) {
        this.jobId        = jobId;
        this.fileName     = fileName;
        this.fileFormat   = fileFormat;
        this.submittedBy  = submittedBy;
        this.status       = "PENDING";
        this.submittedAt  = Instant.now();
    }

    public String getJobId()            { return jobId; }
    public void setJobId(String v)      { this.jobId = v; }
    public String getFileName()         { return fileName; }
    public void setFileName(String v)   { this.fileName = v; }
    public String getFileFormat()       { return fileFormat; }
    public void setFileFormat(String v) { this.fileFormat = v; }
    public String getStatus()           { return status; }
    public void setStatus(String v)     { this.status = v; }
    public String getSubmittedBy()      { return submittedBy; }
    public void setSubmittedBy(String v){ this.submittedBy = v; }
    public int getTotalObjects()        { return totalObjects; }
    public void setTotalObjects(int v)  { this.totalObjects = v; }
    public int getPhysicalObjects()     { return physicalObjects; }
    public void setPhysicalObjects(int v){ this.physicalObjects = v; }
    public int getLogicalObjects()      { return logicalObjects; }
    public void setLogicalObjects(int v){ this.logicalObjects = v; }
    public int getErrorCount()          { return errorCount; }
    public void setErrorCount(int v)    { this.errorCount = v; }
    public int getWarningCount()        { return warningCount; }
    public void setWarningCount(int v)  { this.warningCount = v; }
    public int getInfoCount()           { return infoCount; }
    public void setInfoCount(int v)     { this.infoCount = v; }
    public Instant getSubmittedAt()     { return submittedAt; }
    public void setSubmittedAt(Instant v){ this.submittedAt = v; }
    public Instant getCompletedAt()     { return completedAt; }
    public void setCompletedAt(Instant v){ this.completedAt = v; }
    public long getProcessingMs()       { return processingMs; }
    public void setProcessingMs(long v) { this.processingMs = v; }
    public String getErrorMessage()     { return errorMessage; }
    public void setErrorMessage(String v){ this.errorMessage = v; }
}


// ═══════════════════════════════════════════════════════════════════════════
// DOCUMENT 3: CimObjectRecord  →  collection: cim_objects
// Stores the parsed CIMObject data for each object in each file.
// This is the "common data" output — queryable per job, type, format.
// ═══════════════════════════════════════════════════════════════════════════

@Document(collection = "cim_objects")
@CompoundIndex(def = "{'jobId':1,'cimType':1}")
class CimObjectRecord {

    @Id
    private String id;

    @Indexed
    private String jobId;

    private String rdfId;
    private String mrid;
    private String cimType;
    private String name;
    private String category;       // "PHYSICAL" or "LOGICAL"
    private String sourceFormat;
    private String sourceFile;
    private String orgId;
    private String version;

    // All parsed attributes stored as a flat map.
    // Keys use CIM convention "ClassName.attribute" — dots are handled
    // by MongoConfig.setMapKeyDotReplacement(DOT_REPLACEMENT).
    private Map<String, String> attributes = new LinkedHashMap<>();

    // Reference declarations (key → targetRdfId)
    private Map<String, String> references = new LinkedHashMap<>();

    // Resolved reference IDs — filled by StreamingReferenceResolver (post-pass)
    // key = reference field name, value = rdfId of the resolved target
    private Map<String, String> resolvedRefIds = new LinkedHashMap<>();

    private Instant createdAt;

    public CimObjectRecord() {}

    // Getters/Setters
    public String getId()                       { return id; }
    public String getJobId()                    { return jobId; }
    public void setJobId(String v)              { this.jobId = v; }
    public String getRdfId()                    { return rdfId; }
    public void setRdfId(String v)              { this.rdfId = v; }
    public String getMrid()                     { return mrid; }
    public void setMrid(String v)               { this.mrid = v; }
    public String getCimType()                  { return cimType; }
    public void setCimType(String v)            { this.cimType = v; }
    public String getName()                     { return name; }
    public void setName(String v)               { this.name = v; }
    public String getCategory()                 { return category; }
    public void setCategory(String v)           { this.category = v; }
    public String getSourceFormat()             { return sourceFormat; }
    public void setSourceFormat(String v)       { this.sourceFormat = v; }
    public String getSourceFile()               { return sourceFile; }
    public void setSourceFile(String v)         { this.sourceFile = v; }
    public String getOrgId()                    { return orgId; }
    public void setOrgId(String v)              { this.orgId = v; }
    public String getVersion()                  { return version; }
    public void setVersion(String v)            { this.version = v; }
    public Map<String, String> getAttributes()  { return attributes; }
    public void setAttributes(Map<String, String> v){ this.attributes = v; }
    public Map<String, String> getReferences()   { return references; }
    public void setReferences(Map<String, String> v){ this.references = v; }
    public Map<String, String> getResolvedRefIds()  { return resolvedRefIds; }
    public void setResolvedRefIds(Map<String, String> v){ this.resolvedRefIds = v; }
    public Instant getCreatedAt()                { return createdAt; }
    public void setCreatedAt(Instant v)         { this.createdAt = v; }
}


// ═══════════════════════════════════════════════════════════════════════════
// DOCUMENT 4: ValidationFinding  →  collection: validation_findings
// One document per validation finding (error/warning/info).
// ═══════════════════════════════════════════════════════════════════════════

@Document(collection = "validation_findings")
@CompoundIndex(def = "{'jobId':1,'severity':1}")
class ValidationFinding {

    @Id
    private String id;

    @Indexed
    private String jobId;

    private String severity;       // ERROR, WARNING, INFO
    private String stage;          // PHYSICAL_FILTER, PATH_VALIDATION,
                                   // REFERENCE_RESOLUTION, BUSINESS_RULE, CROSS_OBJECT
    private String objectType;     // "ACLineSegment"
    private String objectId;       // rdfId
    private String objectName;
    private String attributeTag;   // "ConductingEquipment.BaseVoltage"
    private String message;
    private String resolvedPath;   // "ACLineSegment -> Conductor -> ConductingEquipment"
    private String sourceFormat;
    private Instant createdAt;

    public ValidationFinding() {}

    public ValidationFinding(String jobId, String severity, String stage,
                              String objectType, String objectId, String objectName,
                              String attributeTag, String message,
                              String resolvedPath, String sourceFormat) {
        this.jobId        = jobId;
        this.severity     = severity;
        this.stage        = stage;
        this.objectType   = objectType;
        this.objectId     = objectId;
        this.objectName   = objectName;
        this.attributeTag = attributeTag;
        this.message      = message;
        this.resolvedPath = resolvedPath;
        this.sourceFormat = sourceFormat;
        this.createdAt    = Instant.now();
    }

    // Getters/Setters
    public String getId()               { return id; }
    public String getJobId()            { return jobId; }
    public void setJobId(String v)      { this.jobId = v; }
    public String getSeverity()         { return severity; }
    public void setSeverity(String v)   { this.severity = v; }
    public String getStage()            { return stage; }
    public void setStage(String v)      { this.stage = v; }
    public String getObjectType()       { return objectType; }
    public void setObjectType(String v) { this.objectType = v; }
    public String getObjectId()         { return objectId; }
    public void setObjectId(String v)   { this.objectId = v; }
    public String getObjectName()       { return objectName; }
    public void setObjectName(String v) { this.objectName = v; }
    public String getAttributeTag()     { return attributeTag; }
    public void setAttributeTag(String v){ this.attributeTag = v; }
    public String getMessage()          { return message; }
    public void setMessage(String v)    { this.message = v; }
    public String getResolvedPath()     { return resolvedPath; }
    public void setResolvedPath(String v){ this.resolvedPath = v; }
    public String getSourceFormat()     { return sourceFormat; }
    public void setSourceFormat(String v){ this.sourceFormat = v; }
    public Instant getCreatedAt()       { return createdAt; }
    public void setCreatedAt(Instant v) { this.createdAt = v; }
}

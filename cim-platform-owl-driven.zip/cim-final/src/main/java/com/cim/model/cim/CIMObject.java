package com.cim.model.cim;

import java.util.*;

/**
 * ============================================================
 * COMMON MODEL — CIMObject
 * ============================================================
 * Universal in-memory representation of ONE parsed CIM object.
 *
 * Every adapter (RDF/XML, JSON-LD, Milsoft CSV, custom) converts
 * its native format into this single structure before the pipeline.
 *
 * Fields:
 *   cimType      — "ACLineSegment", "Breaker", "PowerTransformer" …
 *   rdfId        — global unique ID from source file (_uuid)
 *   mrid         — CIM mRID (same as rdfId in most cases)
 *   attributes   — flat map: "ACLineSegment.r" → "0.618552"
 *   references   — declared rdf:resource links: key → targetRdfId
 *   resolved     — filled after resolution: key → CIMObject target
 *   sourceFormat — "RDF_XML", "JSON_LD", "MILSOFT_CSV", "CUSTOM_XML"
 *   sourceFile   — original filename for traceability
 */
public class CIMObject {

    private String cimType;
    private String rdfId;
    private String mrid;
    private String orgId;
    private String version;
    private String sourceFormat;
    private String sourceFile;

    // "ClassName.attribute" → value
    private final Map<String, String> attributes = new LinkedHashMap<>();

    // "ClassName.refKey" → targetRdfId  (raw, unresolved)
    private final Map<String, String> references = new LinkedHashMap<>();

    // "ClassName.refKey" → resolved CIMObject
    private final Map<String, CIMObject> resolved = new LinkedHashMap<>();

    public CIMObject() {}

    public CIMObject(String cimType, String rdfId) {
        this.cimType = cimType;
        this.rdfId   = rdfId;
    }

    // ── Convenience ───────────────────────────────────────────────────────

    public String getName() {
        String n = attributes.get("IdentifiedObject.name");
        return (n != null && !n.isBlank()) ? n : rdfId;
    }

    public void setAttribute(String key, String value) {
        if (key != null && value != null) attributes.put(key, value);
    }

    public String getAttribute(String key) {
        return attributes.get(key);
    }

    public void addReference(String key, String targetId) {
        if (key != null && targetId != null) {
            references.put(key, targetId);
            attributes.put(key, targetId); // also visible as attribute
        }
    }

    public void addResolved(String key, CIMObject target) {
        if (key != null && target != null) resolved.put(key, target);
    }

    public boolean hasReference(String key)  { return references.containsKey(key); }
    public boolean hasResolved(String key)   { return resolved.containsKey(key); }
    public CIMObject getResolved(String key) { return resolved.get(key); }

    // ── Getters / Setters ─────────────────────────────────────────────────

    public String getCimType()    { return cimType; }
    public void setCimType(String v) { this.cimType = v; }

    public String getRdfId()      { return rdfId; }
    public void setRdfId(String v)   { this.rdfId = v; }

    public String getMrid()       { return mrid; }
    public void setMrid(String v)    { this.mrid = v; }

    public String getOrgId()      { return orgId; }
    public void setOrgId(String v)   { this.orgId = v; }

    public String getVersion()    { return version; }
    public void setVersion(String v) { this.version = v; }

    public String getSourceFormat()    { return sourceFormat; }
    public void setSourceFormat(String v) { this.sourceFormat = v; }

    public String getSourceFile()      { return sourceFile; }
    public void setSourceFile(String v)   { this.sourceFile = v; }

    public Map<String, String>   getAttributes() { return Collections.unmodifiableMap(attributes); }
    public Map<String, String>   getReferences() { return Collections.unmodifiableMap(references); }
    public Map<String, CIMObject> getResolved()  { return Collections.unmodifiableMap(resolved); }

    @Override
    public String toString() {
        return String.format("CIMObject{type=%s, name=%s, id=%s, format=%s}",
                cimType, getName(), rdfId, sourceFormat);
    }
}

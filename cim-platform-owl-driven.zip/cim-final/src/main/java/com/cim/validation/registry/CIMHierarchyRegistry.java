package com.cim.validation.registry;

import com.cim.model.mongo.CimClassDefinition;
import org.springframework.stereotype.Component;

import java.util.*;
import java.util.concurrent.ConcurrentHashMap;

/**
 * In-memory registry of the CIM class hierarchy.
 * Loaded from MongoDB (cim_standard collection) at startup.
 * Thread-safe — can be refreshed by Admin at runtime.
 */
@Component
public class CIMHierarchyRegistry {

    private final Map<String, CimClassDefinition> registry = new ConcurrentHashMap<>();

    public void load(List<CimClassDefinition> definitions) {
        registry.clear();
        for (CimClassDefinition def : definitions) {
            registry.put(def.getClassName(), def);
        }
    }

    public int size()       { return registry.size(); }
    public boolean isLoaded() { return !registry.isEmpty(); }

    /**
     * Core method: validate whether "DeclaringClass.attribute"
     * is a valid tag for an object of the given CIM type.
     */
    public PathValidationResult validateAttributePath(String objectCimType,
                                                       String attributeTag) {
        if (!attributeTag.contains(".")) {
            return PathValidationResult.invalid(objectCimType, attributeTag,
                    "Tag missing '.' — not valid CIM RDF naming convention.");
        }

        int dot = attributeTag.indexOf('.');
        String declaringClass = attributeTag.substring(0, dot);
        String fieldName      = attributeTag.substring(dot + 1);

        // Vendor extension — not in registry
        if (!registry.containsKey(declaringClass)
                && !declaringClass.equals(objectCimType)) {
            return PathValidationResult.vendorExtension(objectCimType, attributeTag,
                    "'" + declaringClass + "' not in CIM standard registry — vendor extension.");
        }

        CimClassDefinition objectDef = registry.get(objectCimType);
        if (objectDef == null) {
            return PathValidationResult.unknownType(objectCimType, attributeTag,
                    "Type '" + objectCimType + "' not found in CIM standard registry.");
        }

        if (objectDef.isAncestorOrSelf(declaringClass)) {
            List<String> chain = buildChainTo(objectCimType, declaringClass);
            String path = String.join(" -> ", chain)
                    + " [declares '" + fieldName + "']";
            return PathValidationResult.valid(objectCimType, attributeTag, path);
        }

        List<String> fullChain = getFullChain(objectCimType);
        return PathValidationResult.invalid(objectCimType, attributeTag,
                "'" + declaringClass + "' is NOT in chain of '"
                + objectCimType + "'. Chain: " + fullChain);
    }

    public List<String> getFullChain(String cimType) {
        List<String> chain   = new ArrayList<>();
        Set<String>  visited = new HashSet<>();
        String current       = cimType;
        while (current != null && !visited.contains(current)) {
            chain.add(current);
            visited.add(current);
            CimClassDefinition def = registry.get(current);
            current = (def != null) ? def.getParentClass() : null;
        }
        return chain;
    }

    private List<String> buildChainTo(String fromType, String toAncestor) {
        List<String> full  = getFullChain(fromType);
        List<String> chain = new ArrayList<>();
        for (String c : full) {
            chain.add(c);
            if (c.equals(toAncestor)) break;
        }
        return chain;
    }

    public CimClassDefinition getDefinition(String className) {
        return registry.get(className);
    }

    public boolean isKnownClass(String className) {
        return registry.containsKey(className);
    }
}

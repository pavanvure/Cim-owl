package com.cim.validation.registry;

public class PathValidationResult {
    public enum Status { VALID, INVALID, VENDOR_EXTENSION, UNKNOWN_TYPE }

    private final Status status;
    private final String objectType;
    private final String attributeTag;
    private final String explanation;

    private PathValidationResult(Status s, String t, String tag, String exp) {
        this.status = s; this.objectType = t;
        this.attributeTag = tag; this.explanation = exp;
    }

    public static PathValidationResult valid(String t, String tag, String path) {
        return new PathValidationResult(Status.VALID, t, tag, path); }
    public static PathValidationResult invalid(String t, String tag, String r) {
        return new PathValidationResult(Status.INVALID, t, tag, r); }
    public static PathValidationResult vendorExtension(String t, String tag, String n) {
        return new PathValidationResult(Status.VENDOR_EXTENSION, t, tag, n); }
    public static PathValidationResult unknownType(String t, String tag, String r) {
        return new PathValidationResult(Status.UNKNOWN_TYPE, t, tag, r); }

    public boolean isValid()       { return status == Status.VALID; }
    public boolean isInvalid()     { return status == Status.INVALID; }
    public boolean isVendor()      { return status == Status.VENDOR_EXTENSION; }
    public boolean isUnknownType() { return status == Status.UNKNOWN_TYPE; }

    public Status getStatus()       { return status; }
    public String getObjectType()   { return objectType; }
    public String getAttributeTag() { return attributeTag; }
    public String getExplanation()  { return explanation; }
}

package com.cim.repository;

import com.cim.model.mongo.*;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.mongodb.repository.Aggregation;
import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.data.mongodb.repository.Query;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

// ── ValidationJob ─────────────────────────────────────────────────────────

@Repository
interface ValidationJobRepository
        extends MongoRepository<ValidationJob, String> {

    Optional<ValidationJob> findByJobId(String jobId);
    List<ValidationJob> findByStatus(String status);
    List<ValidationJob> findBySubmittedByOrderBySubmittedAtDesc(String submittedBy);
    List<ValidationJob> findTop10ByOrderBySubmittedAtDesc();
}


// ── CimObjectRecord ───────────────────────────────────────────────────────

@Repository
interface CimObjectRecordRepository
        extends MongoRepository<CimObjectRecord, String> {

    List<CimObjectRecord> findByJobId(String jobId);
    Page<CimObjectRecord> findByJobId(String jobId, Pageable pageable);
    List<CimObjectRecord> findByJobIdAndCimType(String jobId, String cimType);
    List<CimObjectRecord> findByJobIdAndCategory(String jobId, String category);
    long countByJobId(String jobId);
    long countByJobIdAndCimType(String jobId, String cimType);

    @Query("{ 'jobId': ?0, 'attributes.IdentifiedObject.name': { $regex: ?1, $options: 'i' } }")
    List<CimObjectRecord> searchByName(String jobId, String namePattern);

    @Aggregation(pipeline = {
        "{ $match: { 'jobId': ?0 } }",
        "{ $group: { _id: '$cimType', count: { $sum: 1 } } }",
        "{ $sort: { count: -1 } }"
    })
    List<TypeCountResult> countByType(String jobId);

    interface TypeCountResult {
        String get_id();
        int getCount();
    }
}


// ── ValidationFinding ─────────────────────────────────────────────────────

@Repository
interface ValidationFindingRepository
        extends MongoRepository<ValidationFinding, String> {

    List<ValidationFinding> findByJobId(String jobId);
    Page<ValidationFinding> findByJobId(String jobId, Pageable pageable);
    List<ValidationFinding> findByJobIdAndSeverity(String jobId, String severity);
    List<ValidationFinding> findByJobIdAndStage(String jobId, String stage);
    List<ValidationFinding> findByJobIdAndObjectType(String jobId, String objectType);

    @Query("{ 'jobId': ?0, 'severity': ?1, 'stage': ?2 }")
    List<ValidationFinding> findByJobIdAndSeverityAndStage(String jobId,
                                                            String severity,
                                                            String stage);

    long countByJobIdAndSeverity(String jobId, String severity);
    long countByJobId(String jobId);

    void deleteByJobId(String jobId);
}

// ── Additional methods needed for streaming large files ──────────────────
// Add these to CimObjectRecordRepository:
//
//   @Query("{ 'jobId': ?0, 'category': 'PHYSICAL' }")
//   List<CimObjectRecord> findPhysicalByJobId(String jobId,
//       @Param("page") int page, @Param("size") int size);
//
//   @Query(value="{ 'jobId': ?0 }", fields="{ 'rdfId': 1, '_id': 1 }")
//   List<CimObjectRecord> findRdfIdsByJobId(String jobId, int page, int size);
//
//   @Query("{ 'jobId': ?0, 'references': { $exists: true, $ne: {} } }")
//   List<CimObjectRecord> findByJobIdWithReferences(String jobId, int page, int size);

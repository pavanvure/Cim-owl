package com.cim.repository;

import com.cim.model.mongo.CimClassDefinition;
import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.data.mongodb.repository.Query;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface CimClassRepository
        extends MongoRepository<CimClassDefinition, String> {

    Optional<CimClassDefinition> findByClassName(String className);
    List<CimClassDefinition> findByCimVersion(String cimVersion);
    List<CimClassDefinition> findByCategory(String category);

    @Query("{ 'ancestors': ?0 }")
    List<CimClassDefinition> findAllSubclassesOf(String ancestorName);

    boolean existsByClassName(String className);
}

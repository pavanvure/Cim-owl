package com.cim.util;

import com.cim.config.MongoConfig;

import java.util.LinkedHashMap;
import java.util.Map;

/**
 * Utility to encode/decode CIM attribute map keys for MongoDB storage.
 *
 * Problem:
 *   CIM attribute keys follow the pattern "ClassName.attributeName"
 *   e.g. "ACLineSegment.r", "ConductingEquipment.BaseVoltage"
 *   MongoDB forbids dots in map/document keys.
 *
 * Primary fix: MongoConfig.setMapKeyDotReplacement()
 *   Spring Data MongoDB automatically encodes dots on write
 *   and decodes them on read.
 *
 * This class is a secondary safety layer used in two places:
 *   1. When building maps manually before passing to objectRepo.insert()
 *      in bulk batch operations (Spring's auto-encoding may miss these).
 *   2. When reading maps back and need to restore the original key format
 *      for use in Java code (validation, queries, etc.)
 *
 * DOT_REPLACEMENT = U+FF0E (FULLWIDTH FULL STOP "．")
 *   Visually identical to "." but not the ASCII 0x2E that MongoDB rejects.
 *   Safe for JSON round-trips and MongoDB field names.
 */
public class MapKeySanitizer {

    private static final String DOT        = ".";
    private static final String REPLACEMENT = MongoConfig.DOT_REPLACEMENT;

    private MapKeySanitizer() {}

    // ── Encode ─────────────────────────────────────────────────────────────

    /**
     * Encodes a single key: "ACLineSegment.r" → "ACLineSegment．r"
     */
    public static String encodeKey(String key) {
        if (key == null) return null;
        return key.replace(DOT, REPLACEMENT);
    }

    /**
     * Returns a new map with all keys encoded.
     * The original map is not modified.
     *
     * Input:  { "ACLineSegment.r": "0.5",
     *           "ConductingEquipment.BaseVoltage": "_bv-uuid" }
     * Output: { "ACLineSegment．r": "0.5",
     *           "ConductingEquipment．BaseVoltage": "_bv-uuid" }
     */
    public static Map<String, String> encodeKeys(Map<String, String> input) {
        if (input == null || input.isEmpty()) return new LinkedHashMap<>();
        Map<String, String> result = new LinkedHashMap<>(input.size());
        input.forEach((k, v) -> result.put(encodeKey(k), v));
        return result;
    }

    // ── Decode ─────────────────────────────────────────────────────────────

    /**
     * Decodes a single key back to the original CIM format.
     * "ACLineSegment．r" → "ACLineSegment.r"
     */
    public static String decodeKey(String key) {
        if (key == null) return null;
        return key.replace(REPLACEMENT, DOT);
    }

    /**
     * Returns a new map with all keys decoded back to CIM format.
     * Use this when reading from MongoDB and working with keys in Java.
     */
    public static Map<String, String> decodeKeys(Map<String, String> input) {
        if (input == null || input.isEmpty()) return new LinkedHashMap<>();
        Map<String, String> result = new LinkedHashMap<>(input.size());
        input.forEach((k, v) -> result.put(decodeKey(k), v));
        return result;
    }

    // ── Check ──────────────────────────────────────────────────────────────

    /**
     * Returns true if the key contains a raw dot that needs encoding.
     * Useful for validating that maps are safe before inserting.
     */
    public static boolean needsEncoding(String key) {
        return key != null && key.contains(DOT);
    }

    /**
     * Returns true if ALL keys in the map are safe for MongoDB
     * (no raw dots present).
     */
    public static boolean allKeysSafe(Map<String, ?> map) {
        if (map == null) return true;
        return map.keySet().stream().noneMatch(MapKeySanitizer::needsEncoding);
    }
}

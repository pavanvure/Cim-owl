package com.cim.streaming;

import com.cim.model.mongo.CimObjectRecord;
import com.cim.repository.CimObjectRecordRepository;
import com.cim.util.MapKeySanitizer;
import org.springframework.data.domain.PageRequest;
import org.springframework.stereotype.Component;

import java.util.*;

/**
 * Post-streaming reference resolver for large files.
 *
 * After ALL objects are saved to MongoDB (Step 1 of the pipeline),
 * this step resolves rdf:resource cross-references by looking up
 * each target object inside MongoDB — no full in-memory map needed.
 *
 * Algorithm:
 *   Pass A: Build a rdfId → mongoId index (paged, ~100 bytes/entry)
 *   Pass B: For each object that has references, check which ones
 *           resolve to known objects and write the result into
 *           CimObjectRecord.resolvedRefIds (Map<refKey, targetRdfId>)
 *
 * The resolvedRefIds map is then read by fromRecord() in
 * LargeFileValidationService to restore resolved stubs into CIMObject,
 * so business rules like "BaseVoltage MUST be present" work correctly.
 *
 * Memory profile:
 *   rdfId index: ~100 bytes × N objects
 *   Safe up to ~5M objects (~500MB RAM).
 *   For truly massive jobs (50M+ objects), swap the in-memory index
 *   for a MongoDB aggregation lookup ($lookup stage).
 */
@Component
public class StreamingReferenceResolver {

    private final CimObjectRecordRepository objectRepo;

    public StreamingReferenceResolver(CimObjectRecordRepository objectRepo) {
        this.objectRepo = objectRepo;
    }

    /**
     * Resolves references for all objects in a job.
     *
     * @param jobId      the validation job
     * @param batchSize  objects to process per page
     * @param progress   tracker for logging
     * @return           total number of reference entries resolved
     */
    public long resolveReferencesInMongo(String jobId,
                                          int batchSize,
                                          ProgressTracker progress) {
        // ── Pass A: build rdfId → mongoId index ──────────────────────────
        progress.log("Building reference index for job: " + jobId);
        Map<String, String> rdfIdIndex = buildRdfIdIndex(jobId, batchSize);
        progress.log("Reference index ready: " + rdfIdIndex.size() + " entries");

        // ── Pass B: resolve references ────────────────────────────────────
        long totalResolved = 0;
        int  page          = 0;

        while (true) {
            // Fetch next batch of objects that have at least one reference
            List<CimObjectRecord> batch = objectRepo
                    .findByJobId(jobId, PageRequest.of(page, batchSize))
                    .getContent();

            if (batch.isEmpty()) break;

            List<CimObjectRecord> toUpdate = new ArrayList<>();

            for (CimObjectRecord record : batch) {
                Map<String, String> refs = record.getReferences();
                if (refs == null || refs.isEmpty()) continue;

                Map<String, String> resolvedRefs = new LinkedHashMap<>();

                // Decode stored keys back to CIM format before lookup
                Map<String, String> decodedRefs = MapKeySanitizer.decodeKeys(refs);

                for (Map.Entry<String, String> ref : decodedRefs.entrySet()) {
                    String targetRdfId = ref.getValue();
                    if (rdfIdIndex.containsKey(targetRdfId)) {
                        // Target found in this job — mark as resolved
                        // Key must be re-encoded for MongoDB storage
                        resolvedRefs.put(
                                MapKeySanitizer.encodeKey(ref.getKey()),
                                targetRdfId
                        );
                        totalResolved++;
                    }
                    // If not found: cross-file reference — skip silently
                    // (reference validation stage will flag it as WARNING)
                }

                if (!resolvedRefs.isEmpty()) {
                    record.setResolvedRefIds(resolvedRefs);
                    toUpdate.add(record);
                }
            }

            // Bulk save the updated records
            if (!toUpdate.isEmpty()) {
                objectRepo.saveAll(toUpdate);
            }

            progress.log("Reference resolution: page " + page
                    + ", resolved so far=" + totalResolved);
            page++;
        }

        return totalResolved;
    }

    /**
     * Builds a lightweight in-memory index: rdfId → mongoId.
     * Paged so it never loads all objects simultaneously.
     * Each entry ~100 bytes; 1M objects ≈ 100MB RAM.
     */
    private Map<String, String> buildRdfIdIndex(String jobId, int batchSize) {
        Map<String, String> index = new LinkedHashMap<>();
        int page = 0;

        while (true) {
            List<CimObjectRecord> batch = objectRepo
                    .findByJobId(jobId, PageRequest.of(page, batchSize))
                    .getContent();

            if (batch.isEmpty()) break;

            for (CimObjectRecord r : batch) {
                if (r.getRdfId() != null && r.getId() != null) {
                    index.put(r.getRdfId(), r.getId());
                }
            }
            page++;
        }

        return index;
    }
}

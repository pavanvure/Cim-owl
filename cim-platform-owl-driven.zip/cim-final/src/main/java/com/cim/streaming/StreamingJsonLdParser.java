package com.cim.streaming;

import com.cim.model.cim.CIMObject;
import com.fasterxml.jackson.core.*;
import org.springframework.stereotype.Component;

import java.io.InputStream;
import java.util.*;
import java.util.function.Consumer;

/**
 * ════════════════════════════════════════════════════════════════════
 * STREAMING JSON-LD PARSER — handles GB-sized JSON files
 * ════════════════════════════════════════════════════════════════════
 *
 * Uses Jackson's streaming API (JsonParser) instead of ObjectMapper.
 * ObjectMapper reads the whole JSON tree into RAM — kills GB files.
 * JsonParser reads token by token — constant memory regardless of size.
 *
 * Supported JSON-LD structures:
 *   [ { "@type":"cim:ACLineSegment", "@id":"_uuid", ... }, ... ]
 *   { "@graph": [ {...}, {...} ] }
 *
 * Each object is fired to the callback as soon as its closing } is hit.
 */
@Component
public class StreamingJsonLdParser {

    /**
     * Streams through JSON-LD and calls onObject for each complete object.
     *
     * @return total number of objects parsed
     */
    public long stream(InputStream inputStream,
                       String fileName,
                       Consumer<CIMObject> onObject) throws Exception {

        JsonFactory factory = new JsonFactory();
        long objectCount = 0;

        try (JsonParser parser = factory.createParser(inputStream)) {

            JsonToken token = parser.nextToken();

            // Skip outer array [ or object {
            if (token == JsonToken.START_ARRAY) {
                // Direct array of CIM objects
                objectCount = parseObjectArray(parser, fileName, onObject);

            } else if (token == JsonToken.START_OBJECT) {
                // Might be { "@graph": [...] } or a single object
                objectCount = parseWrappedObject(parser, fileName, onObject);
            }
        }

        return objectCount;
    }

    // ── Parse an array of CIM objects ─────────────────────────────────────

    private long parseObjectArray(JsonParser parser,
                                   String fileName,
                                   Consumer<CIMObject> onObject) throws Exception {
        long count = 0;
        while (parser.nextToken() != JsonToken.END_ARRAY) {
            if (parser.currentToken() == JsonToken.START_OBJECT) {
                CIMObject obj = parseSingleObject(parser, fileName);
                if (obj != null) {
                    onObject.accept(obj);
                    count++;
                }
            }
        }
        return count;
    }

    // ── Handle { "@graph": [...] } wrapper ────────────────────────────────

    private long parseWrappedObject(JsonParser parser,
                                     String fileName,
                                     Consumer<CIMObject> onObject) throws Exception {
        long count = 0;
        while (parser.nextToken() != JsonToken.END_OBJECT) {
            String fieldName = parser.getCurrentName();
            parser.nextToken();

            if ("@graph".equals(fieldName)
                    && parser.currentToken() == JsonToken.START_ARRAY) {
                count = parseObjectArray(parser, fileName, onObject);
            } else {
                // Skip @context or other top-level fields
                parser.skipChildren();
            }
        }
        return count;
    }

    // ── Parse one JSON object into a CIMObject ────────────────────────────

    private CIMObject parseSingleObject(JsonParser parser,
                                         String fileName) throws Exception {
        String cimType = null;
        String rdfId   = null;
        Map<String, String> attrs = new LinkedHashMap<>();
        Map<String, String> refs  = new LinkedHashMap<>();

        // parser is positioned at START_OBJECT — read until END_OBJECT
        while (parser.nextToken() != JsonToken.END_OBJECT) {
            String key = parser.getCurrentName();
            JsonToken valToken = parser.nextToken();

            if ("@type".equals(key)) {
                cimType = stripPrefix(parser.getText());

            } else if ("@id".equals(key)) {
                rdfId = cleanRef(parser.getText());

            } else if (key != null && key.startsWith("@")) {
                // skip @context etc.
                parser.skipChildren();

            } else if (key != null) {
                String attrKey = stripPrefix(key);

                if (valToken == JsonToken.START_OBJECT) {
                    // Reference: { "@id": "_uuid" }
                    String refId = parseRefObject(parser);
                    if (refId != null) refs.put(attrKey, refId);
                    else parser.skipChildren();

                } else if (valToken == JsonToken.START_ARRAY) {
                    // Array of references
                    parseRefArray(parser, attrKey, refs);

                } else {
                    // Plain scalar value
                    String val = parser.getValueAsString();
                    if (val != null && !val.isBlank()) {
                        attrs.put(attrKey, val.trim());
                    }
                }
            }
        }

        if (cimType == null || rdfId == null) return null;

        CIMObject obj = new CIMObject(cimType, rdfId);
        obj.setMrid(rdfId);
        obj.setSourceFormat("JSON_LD");
        obj.setSourceFile(fileName);

        attrs.forEach(obj::setAttribute);
        refs.forEach(obj::addReference);

        return obj;
    }

    // ── Parse {"@id": "_uuid"} → returns the id ──────────────────────────

    private String parseRefObject(JsonParser parser) throws Exception {
        String refId = null;
        while (parser.nextToken() != JsonToken.END_OBJECT) {
            String k = parser.getCurrentName();
            parser.nextToken();
            if ("@id".equals(k)) refId = cleanRef(parser.getText());
            else parser.skipChildren();
        }
        return refId;
    }

    // ── Parse [ {"@id":"_a"}, {"@id":"_b"} ] ─────────────────────────────

    private void parseRefArray(JsonParser parser,
                                String attrKey,
                                Map<String, String> refs) throws Exception {
        while (parser.nextToken() != JsonToken.END_ARRAY) {
            if (parser.currentToken() == JsonToken.START_OBJECT) {
                String refId = parseRefObject(parser);
                if (refId != null) refs.put(attrKey, refId); // last ref wins
            }
        }
    }

    // ── Helpers ───────────────────────────────────────────────────────────

    /** "cim:ACLineSegment" → "ACLineSegment" */
    private String stripPrefix(String s) {
        if (s == null) return null;
        int i = s.lastIndexOf(':');
        return i >= 0 ? s.substring(i + 1) : s;
    }

    private String cleanRef(String v) {
        if (v == null) return null;
        v = v.trim();
        if (v.startsWith("#")) v = v.substring(1);
        return v;
    }
}

package com.cim.streaming;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

/**
 * DTO returned by GET /api/jobs/{jobId}/progress
 *
 * Represents a point-in-time snapshot of a streaming job's progress.
 *
 * Why a standalone class (not a nested record):
 *   - Jackson serializes nested records inconsistently across versions.
 *   - A top-level class with explicit @JsonPropertyOrder gives predictable
 *     JSON field ordering, which makes the API response easier to read.
 *   - Null errorMessage is excluded from the response when job is healthy.
 *
 * Example response when streaming is in progress:
 * {
 *   "jobId":           "a3f8c2d1-...",
 *   "stage":           "STREAMING_PARSE",
 *   "stageDetail":     "Streaming RDF_XML file...",
 *   "parsed":          1500000,
 *   "saved":           1499500,
 *   "validated":       0,
 *   "errors":          0,
 *   "warnings":        12,
 *   "elapsedMs":       45231,
 *   "elapsedFormatted":"45s",
 *   "parseRatePerSec": 33200,
 *   "percentSaved":    99,
 *   "finished":        false
 * }
 *
 * Example response when done:
 * {
 *   "jobId":           "a3f8c2d1-...",
 *   "stage":           "DONE",
 *   "stageDetail":     "",
 *   "parsed":          5000000,
 *   "saved":           5000000,
 *   "validated":       4800000,
 *   "errors":          237,
 *   "warnings":        1042,
 *   "elapsedMs":       182000,
 *   "elapsedFormatted":"3m 2s",
 *   "parseRatePerSec": 27472,
 *   "percentSaved":    100,
 *   "finished":        true
 * }
 *
 * Example when failed:
 * {
 *   ...
 *   "stage":        "FAILED",
 *   "finished":     true,
 *   "errorMessage": "Parse error: unexpected end of XML"
 * }
 */
@JsonPropertyOrder({
    "jobId", "stage", "stageDetail",
    "parsed", "saved", "validated",
    "errors", "warnings",
    "elapsedMs", "elapsedFormatted",
    "parseRatePerSec", "percentSaved",
    "finished", "errorMessage"
})
@JsonInclude(JsonInclude.Include.NON_NULL)
public class ProgressSnapshot {

    private final String  jobId;
    private final String  stage;
    private final String  stageDetail;
    private final long    parsed;
    private final long    saved;
    private final long    validated;
    private final long    errors;
    private final long    warnings;
    private final long    elapsedMs;
    private final String  elapsedFormatted;   // "3m 2s"  — human readable
    private final long    parseRatePerSec;    // objects/second during parse
    private final int     percentSaved;       // 0-100
    private final boolean finished;           // true when DONE or FAILED
    private final String  errorMessage;       // null unless FAILED

    public ProgressSnapshot(
            String  jobId,
            String  stage,
            String  stageDetail,
            long    parsed,
            long    saved,
            long    validated,
            long    errors,
            long    warnings,
            long    elapsedMs,
            String  elapsedFormatted,
            long    parseRatePerSec,
            int     percentSaved,
            boolean finished,
            String  errorMessage) {

        this.jobId             = jobId;
        this.stage             = stage;
        this.stageDetail       = stageDetail;
        this.parsed            = parsed;
        this.saved             = saved;
        this.validated         = validated;
        this.errors            = errors;
        this.warnings          = warnings;
        this.elapsedMs         = elapsedMs;
        this.elapsedFormatted  = elapsedFormatted;
        this.parseRatePerSec   = parseRatePerSec;
        this.percentSaved      = percentSaved;
        this.finished          = finished;
        this.errorMessage      = errorMessage;
    }

    // ── Getters (required for Jackson serialization) ──────────────────────

    public String  getJobId()             { return jobId; }
    public String  getStage()             { return stage; }
    public String  getStageDetail()       { return stageDetail; }
    public long    getParsed()            { return parsed; }
    public long    getSaved()             { return saved; }
    public long    getValidated()         { return validated; }
    public long    getErrors()            { return errors; }
    public long    getWarnings()          { return warnings; }
    public long    getElapsedMs()         { return elapsedMs; }
    public String  getElapsedFormatted()  { return elapsedFormatted; }
    public long    getParseRatePerSec()   { return parseRatePerSec; }
    public int     getPercentSaved()      { return percentSaved; }
    public boolean isFinished()           { return finished; }
    public String  getErrorMessage()      { return errorMessage; }  // null = excluded by @JsonInclude

    @Override
    public String toString() {
        return String.format(
            "ProgressSnapshot{job=%s stage=%s parsed=%d saved=%d "
            + "validated=%d errors=%d warnings=%d rate=%d/s elapsed=%s pct=%d%%}",
            jobId, stage, parsed, saved, validated,
            errors, warnings, parseRatePerSec, elapsedFormatted, percentSaved);
    }
}

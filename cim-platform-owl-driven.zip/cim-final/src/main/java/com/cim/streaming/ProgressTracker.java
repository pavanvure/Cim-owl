package com.cim.streaming;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.time.Instant;
import java.util.concurrent.atomic.AtomicLong;

/**
 * Thread-safe progress tracker for long-running streaming jobs.
 *
 * Tracks:
 *   - Objects parsed so far
 *   - Objects written to MongoDB
 *   - Objects validated
 *   - Elapsed time and estimated completion
 *   - Current stage (PARSING, SAVING, VALIDATING, RESOLVING_REFS, DONE)
 *
 * Used by:
 *   - LargeFileValidationService (updates the counters)
 *   - ValidationController GET /api/jobs/{jobId}/progress (reads them)
 */
public class ProgressTracker {

    private static final Logger log = LoggerFactory.getLogger(ProgressTracker.class);

    public enum Stage {
        DETECTING_FORMAT,
        STREAMING_PARSE,
        SAVING_TO_MONGO,
        RESOLVING_REFERENCES,
        VALIDATING,
        DONE,
        FAILED
    }

    private final String jobId;
    private final int    logEvery;    // log every N objects

    private volatile Stage   stage       = Stage.DETECTING_FORMAT;
    private volatile String  stageDetail = "";
    private final AtomicLong parsed      = new AtomicLong(0);
    private final AtomicLong saved       = new AtomicLong(0);
    private final AtomicLong validated   = new AtomicLong(0);
    private final AtomicLong errors      = new AtomicLong(0);
    private final AtomicLong warnings    = new AtomicLong(0);
    private final Instant    startTime   = Instant.now();
    private volatile Instant lastUpdate  = Instant.now();
    private volatile String  errorMessage;

    public ProgressTracker(String jobId, int logEvery) {
        this.jobId    = jobId;
        this.logEvery = logEvery;
    }

    // ── Increment counters ────────────────────────────────────────────────

    public void objectParsed() {
        long n = parsed.incrementAndGet();
        if (n % logEvery == 0) logProgress();
    }

    public void objectSaved()     { saved.incrementAndGet(); }
    public void objectValidated() { validated.incrementAndGet(); }
    public void errorFound()      { errors.incrementAndGet(); }
    public void warningFound()    { warnings.incrementAndGet(); }

    public void batchParsed(int count) {
        long n = parsed.addAndGet(count);
        if ((n / logEvery) > ((n - count) / logEvery)) logProgress();
    }

    public void batchSaved(int count)     { saved.addAndGet(count); }
    public void batchValidated(int count) { validated.addAndGet(count); }

    // ── Stage control ─────────────────────────────────────────────────────

    public void setStage(Stage s)               { this.stage = s; log(s.name()); }
    public void setStage(Stage s, String detail){ this.stage = s; this.stageDetail = detail; log(s.name() + ": " + detail); }
    public void fail(String msg)                { this.stage = Stage.FAILED; this.errorMessage = msg; log("FAILED: " + msg); }
    public void done()                          { this.stage = Stage.DONE; logProgress(); }

    public void log(String msg) {
        lastUpdate = Instant.now();
        log.info("[Job {}] {} | parsed={} saved={} validated={} errors={}",
                jobId, msg, parsed.get(), saved.get(), validated.get(), errors.get());
    }

    // ── Snapshot for REST API ─────────────────────────────────────────────

    /**
     * Returns a point-in-time snapshot of progress.
     * Called by GET /api/jobs/{jobId}/progress.
     * All counters are read atomically — safe to call from any thread.
     */
    public ProgressSnapshot snapshot() {
        long now       = Instant.now().toEpochMilli();
        long elapsedMs = now - startTime.toEpochMilli();
        long parsedNow = parsed.get();
        long savedNow  = saved.get();

        // Objects/sec — meaningful once > 1 second has elapsed
        double parseRate = (elapsedMs >= 1000)
                ? (parsedNow * 1000.0 / elapsedMs) : 0.0;

        // Rough % complete using saved vs parsed as proxy
        int pct = (parsedNow > 0)
                ? (int) Math.min(100, savedNow * 100L / Math.max(1, parsedNow))
                : 0;

        return new ProgressSnapshot(
                jobId,
                stage.name(),
                stageDetail != null ? stageDetail : "",
                parsedNow,
                savedNow,
                validated.get(),
                errors.get(),
                warnings.get(),
                elapsedMs,
                formatElapsed(elapsedMs),
                Math.round(parseRate),
                pct,
                stage == Stage.DONE || stage == Stage.FAILED,
                errorMessage
        );
    }

    private void logProgress() {
        long elapsedMs = Instant.now().toEpochMilli() - startTime.toEpochMilli();
        double rate = (elapsedMs > 0) ? (parsed.get() * 1000.0 / elapsedMs) : 0;
        log.info("[Job {}] stage={} parsed={} saved={} validated={} "
                + "errors={} warnings={} rate={}/s elapsed={}",
                jobId, stage, parsed.get(), saved.get(), validated.get(),
                errors.get(), warnings.get(),
                String.format("%.0f", rate), formatElapsed(elapsedMs));
    }

    /** e.g. 125000 ms -> "2m 5s" */
    private String formatElapsed(long ms) {
        long s = ms / 1000;
        long h = s / 3600, m = (s % 3600) / 60, sec = s % 60;
        if (h > 0)  return h + "h " + m + "m " + sec + "s";
        if (m > 0)  return m + "m " + sec + "s";
        return sec + "s";
    }

    // ── Getters ───────────────────────────────────────────────────────────

    public String  getJobId()        { return jobId; }
    public Stage   getStage()        { return stage; }
    public long    getParsed()       { return parsed.get(); }
    public long    getSaved()        { return saved.get(); }
    public long    getValidated()    { return validated.get(); }
    public long    getErrors()       { return errors.get(); }
    public long    getWarnings()     { return warnings.get(); }
    public boolean isDone()          { return stage == Stage.DONE; }
    public boolean isFailed()        { return stage == Stage.FAILED; }
    public String  getErrorMessage() { return errorMessage; }
}

package com.cim.streaming;

import com.cim.model.cim.CIMObject;
import org.apache.commons.csv.*;
import org.springframework.stereotype.Component;

import java.io.*;
import java.nio.charset.StandardCharsets;
import java.util.*;
import java.util.function.Consumer;

/**
 * ════════════════════════════════════════════════════════════════════
 * STREAMING CSV PARSER — handles GB-sized Milsoft CSV files
 * ════════════════════════════════════════════════════════════════════
 *
 * Problem with large CSVs:
 *   The previous adapter read all rows into a HashMap in memory.
 *   A 5GB CSV with 10M objects = OutOfMemoryError.
 *
 * Solution:
 *   CSV rows are sorted by rdfId (grouped) so we can read one object
 *   at a time. When the rdfId changes, the previous object is complete
 *   and fired to the callback. Only 1 object is in RAM at any time.
 *
 * Expected CSV format (Layout B — Generic CIM CSV):
 *   rdfId,cimType,attributeKey,attributeValue,isReference,targetRdfId
 *   _uuid1,ACLineSegment,ACLineSegment.r,0.618,,
 *   _uuid1,ACLineSegment,ConductingEquipment.BaseVoltage,,true,_bv-uuid
 *   _uuid2,BaseVoltage,BaseVoltage.nominalVoltage,66,,
 *
 * IMPORTANT: Rows for the same rdfId must be consecutive (sorted).
 * If not sorted, use StreamingCsvSorter first (see below).
 */
@Component
public class StreamingCsvParser {

    private static final Map<String, String> MILSOFT_TYPE_MAP = Map.ofEntries(
        Map.entry("Line",        "ACLineSegment"),
        Map.entry("LINE",        "ACLineSegment"),
        Map.entry("Transformer", "PowerTransformer"),
        Map.entry("Breaker",     "Breaker"),
        Map.entry("Recloser",    "Recloser"),
        Map.entry("Fuse",        "Fuse"),
        Map.entry("Capacitor",   "LinearShuntCompensator"),
        Map.entry("CAP",         "LinearShuntCompensator"),
        Map.entry("Load",        "EnergyConsumer"),
        Map.entry("LOAD",        "EnergyConsumer"),
        Map.entry("Generator",   "SynchronousMachine"),
        Map.entry("Bus",         "ConnectivityNode"),
        Map.entry("Node",        "ConnectivityNode"),
        Map.entry("Switch",      "Switch"),
        Map.entry("Substation",  "Substation")
    );

    /**
     * Streams through the CSV and calls onObject for each complete object.
     * Assumes rows are grouped by rdfId (consecutive rows per object).
     *
     * @return total number of objects emitted
     */
    public long stream(InputStream inputStream,
                       String fileName,
                       Consumer<CIMObject> onObject) throws Exception {

        BufferedReader reader = new BufferedReader(
                new InputStreamReader(inputStream, StandardCharsets.UTF_8),
                64 * 1024); // 64KB read buffer

        // Peek at header to detect layout
        reader.mark(512);
        String firstLine = reader.readLine();
        reader.reset();

        if (firstLine == null) return 0;

        if (isGenericCimLayout(firstLine)) {
            return streamGenericCimCsv(reader, fileName, onObject);
        } else {
            return streamMilsoftNativeCsv(reader, fileName, onObject);
        }
    }

    // ── Layout B: Generic CIM CSV (one row = one attribute) ──────────────

    private long streamGenericCimCsv(BufferedReader reader,
                                      String fileName,
                                      Consumer<CIMObject> onObject) throws Exception {
        long count = 0;

        try (CSVParser parser = new CSVParser(reader,
                CSVFormat.DEFAULT.withFirstRecordAsHeader().withTrim())) {

            CIMObject current  = null;
            String    lastId   = null;

            for (CSVRecord row : parser) {
                String rdfId    = safe(row, "rdfId");
                String cimType  = safe(row, "cimType");
                String attrKey  = safe(row, "attributeKey");
                String attrVal  = safe(row, "attributeValue");
                boolean isRef   = "true".equalsIgnoreCase(safe(row, "isReference"));
                String targetId = safe(row, "targetRdfId");

                if (rdfId == null || rdfId.isBlank()) continue;

                // New object starts — emit the previous one
                if (!rdfId.equals(lastId)) {
                    if (current != null) {
                        onObject.accept(current);
                        count++;
                    }
                    current = new CIMObject(cimType, rdfId);
                    current.setMrid(rdfId);
                    current.setSourceFormat("MILSOFT_CSV");
                    current.setSourceFile(fileName);
                    lastId = rdfId;
                }

                // Add attribute or reference to current object
                if (isRef && targetId != null && !targetId.isBlank()) {
                    current.addReference(attrKey, targetId);
                } else if (attrVal != null && !attrVal.isBlank()) {
                    current.setAttribute(attrKey, attrVal);
                }
            }

            // Emit the last object
            if (current != null) {
                onObject.accept(current);
                count++;
            }
        }

        return count;
    }

    // ── Layout A: Milsoft Native CSV (one row = one equipment) ───────────

    private long streamMilsoftNativeCsv(BufferedReader reader,
                                         String fileName,
                                         Consumer<CIMObject> onObject) throws Exception {
        long count = 0;

        try (CSVParser parser = new CSVParser(reader,
                CSVFormat.DEFAULT.withFirstRecordAsHeader().withTrim())) {

            List<String> headers = parser.getHeaderNames();

            for (CSVRecord row : parser) {
                String milsoftType = safe(row, "Type");
                String id          = safe(row, "ID");
                String name        = safe(row, "Name");
                String kv          = safe(row, "KV");

                if (milsoftType == null || milsoftType.isBlank()) continue;

                String cimType = MILSOFT_TYPE_MAP.getOrDefault(milsoftType, milsoftType);
                String rdfId   = "_" + (id != null && !id.isBlank()
                                       ? id : UUID.randomUUID().toString());

                CIMObject obj = new CIMObject(cimType, rdfId);
                obj.setMrid(rdfId);
                obj.setSourceFormat("MILSOFT_CSV");
                obj.setSourceFile(fileName);

                if (name != null && !name.isBlank())
                    obj.setAttribute("IdentifiedObject.name", name);
                if (kv != null && !kv.isBlank())
                    obj.setAttribute("ConductingEquipment.nominalVoltage_kv", kv);

                for (String header : headers) {
                    if (List.of("Type","ID","Name","KV").contains(header)) continue;
                    String val = safe(row, header);
                    if (val != null && !val.isBlank()) {
                        obj.setAttribute(mapColumn(cimType, header), val);
                    }
                }

                onObject.accept(obj);
                count++;
            }
        }

        return count;
    }

    // ── Helpers ───────────────────────────────────────────────────────────

    private boolean isGenericCimLayout(String firstLine) {
        String lower = firstLine.toLowerCase();
        return lower.startsWith("rdfid,cimtype") || lower.startsWith("id,type,");
    }

    private String safe(CSVRecord row, String col) {
        try { return row.get(col); } catch (Exception e) { return null; }
    }

    private String mapColumn(String cimType, String col) {
        return switch (col.toUpperCase()) {
            case "R1","R"   -> "ACLineSegment.r";
            case "X1","X"   -> "ACLineSegment.x";
            case "B1","B"   -> "ACLineSegment.bch";
            case "R0"       -> "ACLineSegment.r0";
            case "X0"       -> "ACLineSegment.x0";
            case "LENGTH","LEN" -> "Conductor.length";
            case "P","KW"   -> "EnergyConsumer.p";
            case "Q","KVAR" -> "EnergyConsumer.q";
            default         -> cimType + "." + col.toLowerCase();
        };
    }
}

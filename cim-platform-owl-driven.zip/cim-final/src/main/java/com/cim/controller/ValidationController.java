package com.cim.controller;

import com.cim.adapter.AdapterRegistry;
import com.cim.adapter.CIMFormatAdapter;
import com.cim.model.mongo.ValidationJob;
import com.cim.service.*;
import com.cim.streaming.ProgressSnapshot;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.io.InputStream;
import java.util.Map;
import java.util.UUID;

/**
 * REST API — Upload, validate, query
 *
 * Routing logic:
 *   file ≤ threshold (default 50MB) → ValidationService   (in-memory, sync/async)
 *   file > threshold                → LargeFileValidation (streaming, always async)
 *
 * POST /api/validate                Upload + validate
 * GET  /api/jobs/{jobId}            Job status
 * GET  /api/jobs/{jobId}/progress   Live streaming progress (for large files)
 * GET  /api/jobs/{jobId}/objects    Parsed CIM data
 * GET  /api/jobs/{jobId}/findings   Validation findings
 * GET  /api/formats                 Supported formats
 */
@RestController
@RequestMapping("/api")
@CrossOrigin(origins = "*")
public class ValidationController {

    // Files larger than this threshold use the streaming path
    private static final long LARGE_FILE_THRESHOLD_BYTES = 50L * 1024 * 1024; // 50MB

    private final ValidationService         validationService;
    private final LargeFileValidationService largeFileService;
    private final QueryService              queryService;
    private final AdapterRegistry           adapterRegistry;
    private final ValidationJobRepository   jobRepo;

    public ValidationController(
            ValidationService validationService,
            LargeFileValidationService largeFileService,
            QueryService queryService,
            AdapterRegistry adapterRegistry,
            ValidationJobRepository jobRepo) {
        this.validationService = validationService;
        this.largeFileService  = largeFileService;
        this.queryService      = queryService;
        this.adapterRegistry   = adapterRegistry;
        this.jobRepo           = jobRepo;
    }

    // ─────────────────────────────────────────────────────────────────────
    // POST /api/validate
    // Smart routing: small file → sync, large file → streaming async
    //
    // curl -X POST http://localhost:8080/api/validate \
    //      -F "file=@network.xml" -H "X-User: admin"
    // ─────────────────────────────────────────────────────────────────────
    @PostMapping("/validate")
    public ResponseEntity<?> validate(
            @RequestParam("file") MultipartFile file,
            @RequestHeader(value = "X-User", defaultValue = "anonymous") String user) {

        if (file.isEmpty()) {
            return ResponseEntity.badRequest()
                    .body(Map.of("error", "File is empty."));
        }

        long fileSize = file.getSize();
        String jobId  = UUID.randomUUID().toString();

        try {
            // ── Detect format from first 512 bytes ───────────────────────
            byte[] sample = new byte[(int) Math.min(512, fileSize)];
            try (InputStream is = file.getInputStream()) {
                is.read(sample);
            }
            CIMFormatAdapter adapter = adapterRegistry.detect(sample,
                    file.getOriginalFilename());
            String format = adapter.getFormatName();

            // ── Route based on file size ──────────────────────────────────
            if (fileSize <= LARGE_FILE_THRESHOLD_BYTES) {
                // Small file: synchronous, all in memory
                ValidationSummary summary =
                        validationService.validateSync(file, user);
                return ResponseEntity.ok(toResponse(summary, false));

            } else {
                // Large file: streaming, async, returns immediately
                double sizeMb = fileSize / (1024.0 * 1024.0);

                // Create PENDING job record
                ValidationJob job = new ValidationJob(
                        jobId, file.getOriginalFilename(), format, user);
                job.setStatus("PENDING");
                jobRepo.save(job);

                // Start streaming in background
                largeFileService.processLargeFile(
                        file.getInputStream(),
                        file.getOriginalFilename(),
                        format,
                        jobId);

                return ResponseEntity.accepted().body(Map.of(
                    "jobId",        jobId,
                    "status",       "PROCESSING",
                    "format",       format,
                    "fileSizeMB",   String.format("%.1f", sizeMb),
                    "message",      "Large file accepted for streaming processing.",
                    "note",         "Poll GET /api/jobs/" + jobId + "/progress for live updates.",
                    "links", Map.of(
                        "progress", "/api/jobs/" + jobId + "/progress",
                        "objects",  "/api/jobs/" + jobId + "/objects",
                        "findings", "/api/jobs/" + jobId + "/findings"
                    )
                ));
            }

        } catch (IllegalArgumentException e) {
            return ResponseEntity.badRequest()
                    .body(Map.of("error", e.getMessage()));
        } catch (Exception e) {
            return ResponseEntity.internalServerError()
                    .body(Map.of("error", "Processing failed: " + e.getMessage()));
        }
    }

    // ─────────────────────────────────────────────────────────────────────
    // GET /api/jobs/{jobId}/progress
    // Live progress for large files — poll this during streaming.
    //
    // curl http://localhost:8080/api/jobs/{jobId}/progress
    // Response:
    // { "stage":"STREAMING_PARSE", "parsed":1500000, "saved":1499500,
    //   "validated":0, "errors":0, "elapsedMs":45000 }
    // ─────────────────────────────────────────────────────────────────────
    @GetMapping("/jobs/{jobId}/progress")
    public ResponseEntity<?> getProgress(@PathVariable String jobId) {
        return largeFileService.getProgress(jobId)
                .<ResponseEntity<?>>map(ResponseEntity::ok)
                .orElseGet(() ->
                    queryService.getJob(jobId)
                        .<ResponseEntity<?>>map(job -> ResponseEntity.ok(Map.of(
                            "jobId",  jobId,
                            "status", job.getStatus(),
                            "parsed", job.getTotalObjects(),
                            "errors", job.getErrorCount()
                        )))
                        .orElse(ResponseEntity.notFound().build())
                );
    }

    // ─────────────────────────────────────────────────────────────────────
    // GET /api/jobs
    // ─────────────────────────────────────────────────────────────────────
    @GetMapping("/jobs")
    public ResponseEntity<?> getRecentJobs() {
        return ResponseEntity.ok(
                Map.of("jobs", queryService.getRecentJobs(10)));
    }

    // ─────────────────────────────────────────────────────────────────────
    // GET /api/jobs/{jobId}
    // ─────────────────────────────────────────────────────────────────────
    @GetMapping("/jobs/{jobId}")
    public ResponseEntity<?> getJob(@PathVariable String jobId) {
        return queryService.getJob(jobId)
                .<ResponseEntity<?>>map(ResponseEntity::ok)
                .orElse(ResponseEntity.notFound().build());
    }

    // ─────────────────────────────────────────────────────────────────────
    // GET /api/jobs/{jobId}/objects
    // The parsed common data stored in MongoDB.
    //
    // Query params:
    //   ?type=ACLineSegment    filter by CIM type
    //   ?category=PHYSICAL     PHYSICAL or LOGICAL
    //   ?name=CALCME           search by name
    //   ?page=0&size=50        pagination
    // ─────────────────────────────────────────────────────────────────────
    @GetMapping("/jobs/{jobId}/objects")
    public ResponseEntity<?> getObjects(
            @PathVariable String jobId,
            @RequestParam(required = false) String type,
            @RequestParam(required = false) String category,
            @RequestParam(required = false) String name,
            @RequestParam(defaultValue = "0")  int page,
            @RequestParam(defaultValue = "50") int size) {

        if (type != null && !type.isBlank()) {
            return ResponseEntity.ok(Map.of(
                "jobId", jobId, "filter", "type=" + type,
                "objects", queryService.getObjectsByType(jobId, type)));
        }
        if ("PHYSICAL".equalsIgnoreCase(category)) {
            return ResponseEntity.ok(Map.of(
                "jobId", jobId, "filter", "PHYSICAL",
                "objects", queryService.getPhysicalObjects(jobId)));
        }
        if ("LOGICAL".equalsIgnoreCase(category)) {
            return ResponseEntity.ok(Map.of(
                "jobId", jobId, "filter", "LOGICAL",
                "objects", queryService.getLogicalObjects(jobId)));
        }
        if (name != null && !name.isBlank()) {
            return ResponseEntity.ok(Map.of(
                "jobId", jobId, "filter", "name~" + name,
                "objects", queryService.searchByName(jobId, name)));
        }
        var result = queryService.getObjects(jobId, page, size);
        return ResponseEntity.ok(Map.of(
            "jobId", jobId, "page", result.getNumber(),
            "totalPages", result.getTotalPages(),
            "totalItems", result.getTotalElements(),
            "objects", result.getContent()));
    }

    // ─────────────────────────────────────────────────────────────────────
    // GET /api/jobs/{jobId}/objects/stats
    // ─────────────────────────────────────────────────────────────────────
    @GetMapping("/jobs/{jobId}/objects/stats")
    public ResponseEntity<?> getObjectStats(@PathVariable String jobId) {
        return ResponseEntity.ok(queryService.getObjectStats(jobId));
    }

    // ─────────────────────────────────────────────────────────────────────
    // GET /api/jobs/{jobId}/findings
    //
    // Query params:
    //   ?severity=ERROR         ERROR / WARNING / INFO
    //   ?stage=BUSINESS_RULE    filter by pipeline stage
    //   ?objectType=ACLineSegment
    //   ?page=0&size=50
    // ─────────────────────────────────────────────────────────────────────
    @GetMapping("/jobs/{jobId}/findings")
    public ResponseEntity<?> getFindings(
            @PathVariable String jobId,
            @RequestParam(required = false) String severity,
            @RequestParam(required = false) String stage,
            @RequestParam(required = false) String objectType,
            @RequestParam(defaultValue = "0")  int page,
            @RequestParam(defaultValue = "50") int size) {

        if (severity != null && !severity.isBlank())
            return ResponseEntity.ok(Map.of("jobId", jobId,
                "findings", queryService.getFindingsBySeverity(jobId, severity)));

        if (stage != null && !stage.isBlank())
            return ResponseEntity.ok(Map.of("jobId", jobId,
                "findings", queryService.getFindingsByStage(jobId, stage)));

        if (objectType != null && !objectType.isBlank())
            return ResponseEntity.ok(Map.of("jobId", jobId,
                "findings", queryService.getFindingsByObjectType(jobId, objectType)));

        var result = queryService.getFindings(jobId, page, size);
        return ResponseEntity.ok(Map.of(
            "jobId", jobId, "page", result.getNumber(),
            "totalPages", result.getTotalPages(),
            "totalItems", result.getTotalElements(),
            "findings", result.getContent()));
    }

    // ─────────────────────────────────────────────────────────────────────
    // GET /api/jobs/{jobId}/findings/summary
    // ─────────────────────────────────────────────────────────────────────
    @GetMapping("/jobs/{jobId}/findings/summary")
    public ResponseEntity<?> getFindingSummary(@PathVariable String jobId) {
        return ResponseEntity.ok(queryService.getFindingSummary(jobId));
    }

    // ─────────────────────────────────────────────────────────────────────
    // GET /api/formats
    // ─────────────────────────────────────────────────────────────────────
    @GetMapping("/formats")
    public ResponseEntity<?> getFormats() {
        return ResponseEntity.ok(Map.of(
            "supported", adapterRegistry.getSupportedFormats(),
            "largFileThresholdMB", LARGE_FILE_THRESHOLD_BYTES / (1024 * 1024),
            "details", Map.of(
                "RDF_XML",     "IEC CIM RDF/XML (.rdf, .xml) — StAX streaming",
                "JSON_LD",     "JSON-LD (.json) — Jackson streaming",
                "MILSOFT_CSV", "Milsoft WindMil CSV (.csv, .txt) — line-by-line"
            )
        ));
    }

    // ── Helper ────────────────────────────────────────────────────────────

    private Map<String, Object> toResponse(ValidationSummary s, boolean async) {
        return Map.ofEntries(
            Map.entry("jobId",           s.getJobId()),
            Map.entry("fileName",        s.getFileName()),
            Map.entry("format",          s.getFormat()),
            Map.entry("status",          s.getStatus()),
            Map.entry("totalObjects",    s.getTotalObjects()),
            Map.entry("physicalObjects", s.getPhysicalObjects()),
            Map.entry("logicalObjects",  s.getLogicalObjects()),
            Map.entry("errors",          s.getErrorCount()),
            Map.entry("warnings",        s.getWarningCount()),
            Map.entry("info",            s.getInfoCount()),
            Map.entry("elapsedMs",       s.getElapsedMs()),
            Map.entry("links", Map.of(
                "objects",  "/api/jobs/" + s.getJobId() + "/objects",
                "findings", "/api/jobs/" + s.getJobId() + "/findings",
                "errors",   "/api/jobs/" + s.getJobId() + "/findings?severity=ERROR",
                "progress", "/api/jobs/" + s.getJobId() + "/progress"
            ))
        );
    }

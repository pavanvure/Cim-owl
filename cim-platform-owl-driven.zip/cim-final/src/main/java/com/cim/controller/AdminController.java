package com.cim.controller;

import com.cim.service.CIMStandardService;
import com.cim.validation.registry.CIMHierarchyRegistry;
import com.cim.repository.CimClassRepository;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.util.Map;

/**
 * Admin REST API — CIM Standard Management
 *
 * POST /api/admin/cim/upload-owl         Upload the official OWL file
 * POST /api/admin/cim/reload?version=X   Reload from configured file path
 * GET  /api/admin/cim/classes            List all loaded classes
 * GET  /api/admin/cim/classes/{name}     Get one class definition
 * GET  /api/admin/cim/chain/{name}       Get inheritance chain
 * POST /api/admin/cim/validate-path      Interactive path checker
 * GET  /api/admin/cim/stats              Registry stats
 */
@RestController
@RequestMapping("/api/admin")
@CrossOrigin(origins = "*")
public class AdminController {

    private final CIMStandardService   standardService;
    private final CIMHierarchyRegistry registry;
    private final CimClassRepository   classRepo;

    public AdminController(CIMStandardService standardService,
                           CIMHierarchyRegistry registry,
                           CimClassRepository classRepo) {
        this.standardService = standardService;
        this.registry        = registry;
        this.classRepo       = classRepo;
    }

    // ─────────────────────────────────────────────────────────────────────
    // POST /api/admin/cim/upload-owl
    //
    // Admin uploads the official CIM OWL file.
    // Replaces ALL hardcoded class hierarchy data.
    // Call this once after deploying, or whenever the CIM version changes.
    //
    // curl -X POST http://localhost:8080/api/admin/cim/upload-owl \
    //      -F "file=@iec61970cim17v40.owl" \
    //      -F "version=CIM17v40"
    //
    // Response:
    // { "status": "OK",
    //   "cimVersion": "CIM17v40",
    //   "totalClasses": 537,
    //   "physicalClasses": 312,
    //   "logicalClasses": 225 }
    // ─────────────────────────────────────────────────────────────────────
    @PostMapping("/cim/upload-owl")
    public ResponseEntity<?> uploadOwl(
            @RequestParam("file") MultipartFile file,
            @RequestParam(value = "version", defaultValue = "CIM17") String version) {

        if (file.isEmpty()) {
            return ResponseEntity.badRequest()
                    .body(Map.of("error", "OWL file is empty."));
        }
        if (!file.getOriginalFilename().toLowerCase().endsWith(".owl")
                && !file.getOriginalFilename().toLowerCase().endsWith(".rdf")
                && !file.getOriginalFilename().toLowerCase().endsWith(".xml")) {
            return ResponseEntity.badRequest()
                    .body(Map.of("error",
                            "Expected .owl, .rdf, or .xml file. Got: "
                            + file.getOriginalFilename()));
        }

        try {
            CIMStandardService.AdminLoadResult result =
                    standardService.loadFromUploadedOwl(file, version);

            return ResponseEntity.ok(Map.of(
                "status",          "OK",
                "cimVersion",      result.cimVersion(),
                "totalClasses",    result.totalClasses(),
                "physicalClasses", result.physicalClasses(),
                "logicalClasses",  result.logicalClasses(),
                "message",         "CIM OWL ontology loaded successfully. "
                                 + "All hardcoded class data replaced."
            ));
        } catch (Exception e) {
            return ResponseEntity.internalServerError()
                    .body(Map.of("error", "Failed to parse OWL file: " + e.getMessage()));
        }
    }

    // ─────────────────────────────────────────────────────────────────────
    // POST /api/admin/cim/reload?version=CIM17
    // Reload from configured file path (cim.owl.file-path in application.yml)
    // ─────────────────────────────────────────────────────────────────────
    @PostMapping("/cim/reload")
    public ResponseEntity<?> reload(
            @RequestParam(defaultValue = "CIM17") String version) {
        try {
            CIMStandardService.AdminLoadResult result =
                    standardService.reloadFromConfiguredFile(version);
            return ResponseEntity.ok(Map.of(
                "status",       "OK",
                "cimVersion",   result.cimVersion(),
                "totalClasses", result.totalClasses()
            ));
        } catch (Exception e) {
            return ResponseEntity.internalServerError()
                    .body(Map.of("error", e.getMessage()));
        }
    }

    // ─────────────────────────────────────────────────────────────────────
    // GET /api/admin/cim/classes
    // ─────────────────────────────────────────────────────────────────────
    @GetMapping("/cim/classes")
    public ResponseEntity<?> listClasses(
            @RequestParam(required = false) String category,
            @RequestParam(required = false) String cimPackage) {

        var classes = category != null
                ? classRepo.findByCategory(category.toUpperCase())
                : classRepo.findAll();

        return ResponseEntity.ok(Map.of(
            "totalClasses", classes.size(),
            "classes",      classes
        ));
    }

    // ─────────────────────────────────────────────────────────────────────
    // GET /api/admin/cim/classes/{name}
    // ─────────────────────────────────────────────────────────────────────
    @GetMapping("/cim/classes/{name}")
    public ResponseEntity<?> getClass(@PathVariable String name) {
        var def = registry.getDefinition(name);
        if (def == null) return ResponseEntity.notFound().build();
        return ResponseEntity.ok(Map.of(
            "className",     def.getClassName(),
            "parentClass",   def.getParentClass() != null ? def.getParentClass() : "ROOT",
            "ancestors",     def.getAncestors(),
            "ownAttributes", def.getOwnAttributes(),
            "category",      def.getCategory() != null ? def.getCategory() : "UNKNOWN",
            "cimPackage",    def.getCimPackage() != null ? def.getCimPackage() : "Unknown",
            "cimVersion",    def.getCimVersion(),
            "description",   def.getDescription() != null ? def.getDescription() : ""
        ));
    }

    // ─────────────────────────────────────────────────────────────────────
    // GET /api/admin/cim/chain/{className}
    // ─────────────────────────────────────────────────────────────────────
    @GetMapping("/cim/chain/{className}")
    public ResponseEntity<?> getChain(@PathVariable String className) {
        if (!registry.isKnownClass(className))
            return ResponseEntity.notFound().build();
        var chain = registry.getFullChain(className);
        return ResponseEntity.ok(Map.of(
            "className",        className,
            "inheritanceChain", chain,
            "depth",            chain.size()
        ));
    }

    // ─────────────────────────────────────────────────────────────────────
    // POST /api/admin/cim/validate-path
    //
    // curl -X POST http://localhost:8080/api/admin/cim/validate-path \
    //   -H "Content-Type: application/json" \
    //   -d '{"objectType":"ACLineSegment","attributeTag":"ConductingEquipment.BaseVoltage"}'
    // ─────────────────────────────────────────────────────────────────────
    @PostMapping("/cim/validate-path")
    public ResponseEntity<?> validatePath(@RequestBody Map<String, String> body) {
        String objectType   = body.get("objectType");
        String attributeTag = body.get("attributeTag");

        if (objectType == null || attributeTag == null) {
            return ResponseEntity.badRequest()
                    .body(Map.of("error", "Both 'objectType' and 'attributeTag' required."));
        }

        var result = registry.validateAttributePath(objectType, attributeTag);
        var chain  = registry.getFullChain(objectType);

        return ResponseEntity.ok(Map.of(
            "objectType",        objectType,
            "attributeTag",      attributeTag,
            "status",            result.getStatus().name(),
            "valid",             result.isValid(),
            "explanation",       result.getExplanation(),
            "inheritanceChain",  chain
        ));
    }

    // ─────────────────────────────────────────────────────────────────────
    // GET /api/admin/cim/stats
    // ─────────────────────────────────────────────────────────────────────
    @GetMapping("/cim/stats")
    public ResponseEntity<?> getStats() {
        return ResponseEntity.ok(Map.of(
            "registryLoaded",  registry.isLoaded(),
            "totalClasses",    registry.size(),
            "physicalClasses", classRepo.findByCategory("PHYSICAL").size(),
            "logicalClasses",  classRepo.findByCategory("LOGICAL").size(),
            "note", registry.isLoaded()
                    ? "Registry loaded from OWL ontology."
                    : "Registry empty — upload OWL file via POST /api/admin/cim/upload-owl"
        ));
    }
}

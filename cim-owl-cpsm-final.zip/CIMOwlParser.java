package com.cim.service;

import com.cim.model.mongo.CimClassDefinition;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import javax.xml.stream.*;
import java.io.*;
import java.util.*;

/**
 * CIM OWL PARSER — CPSM/Langdale format (verified from actual file)
 * ════════════════════════════════════════════════════════════════════
 *
 * VERIFIED STRUCTURE (from CPSM-CoreEquipment.owl source):
 *
 * Namespaces:
 *   rdf  = http://www.w3.org/1999/02/22-rdf-syntax-ns#
 *   owl  = http://www.w3.org/2002/07/owl#
 *   rdfs = http://www.w3.org/2000/01/rdf-schema#
 *   uml  = http://langdale.com.au/2005/UML#   ← stereotype namespace
 *
 * All blocks use rdf:nodeID (NOT rdf:about):
 *
 * BLOCK TYPE 1 — CIM Class:
 *   <rdf:Description rdf:nodeID="...">
 *     <uml:hasStereotype rdf:resource=".../UML#byreference"/>   ← or #concrete
 *     <rdf:type rdf:resource=".../owl#Class"/>
 *     <rdfs:label>ACLineSegment</rdfs:label>                    ← CLASS NAME
 *     <rdfs:subClassOf rdf:resource=".../CIM100#Conductor"/>    ← PARENT
 *   </rdf:Description>
 *
 * BLOCK TYPE 2 — CIM Attribute (Datatype):
 *   <rdf:Description rdf:nodeID="...">
 *     <uml:hasStereotype rdf:resource=".../UML#attribute"/>     ← ATTR marker
 *     <rdf:type rdf:resource=".../rdf-schema#Datatype"/>
 *     <rdfs:label>bch</rdfs:label>                             ← ATTR NAME
 *     <owl:equivalentClass rdf:resource=".../CIM100#Susceptance"/>
 *   </rdf:Description>
 *
 * BLOCK TYPE 3 — OWL Restriction (maps attribute to class):
 *   <rdf:Description rdf:nodeID="...">
 *     <rdf:type rdf:resource=".../owl#Restriction"/>
 *     <owl:onProperty rdf:resource=".../CIM100#ACLineSegment.bch"/>
 *     ← Property URI = "ClassName.attributeName" → decoded to assign attr to class
 *   </rdf:Description>
 *
 * BLOCK TYPE 4 — OWL Restriction (minCardinality):
 *   <rdf:Description rdf:nodeID="...">
 *     <rdf:type rdf:resource=".../owl#Restriction"/>
 *     <owl:minCardinality ...>1</owl:minCardinality>
 *     <owl:onProperty rdf:resource=".../CIM100#Cut.ACLineSegment"/>
 *   </rdf:Description>
 *
 * KEY EXTRACTION RULES:
 *   Class name    = rdfs:label text when rdf:type = owl:Class
 *   Parent class  = rdfs:subClassOf rdf:resource localName
 *   Stereotype    = uml:hasStereotype rdf:resource localName
 *   Attr name     = rdfs:label text when uml:hasStereotype = UML#attribute
 *   Attr → Class  = owl:onProperty URI split on "." → "ClassName" and "attrName"
 */
@Component
public class CIMOwlParser {

    private static final Logger log = LoggerFactory.getLogger(CIMOwlParser.class);

    private static final String NS_RDF  = "http://www.w3.org/1999/02/22-rdf-syntax-ns#";
    private static final String NS_RDFS = "http://www.w3.org/2000/01/rdf-schema#";
    private static final String NS_OWL  = "http://www.w3.org/2002/07/owl#";
    private static final String NS_UML  = "http://langdale.com.au/2005/UML#";

    // Stereotype local names that mean PHYSICAL equipment
    private static final Set<String> PHYSICAL_STEREO =
            Set.of("byreference", "concrete", "Concrete");

    // Stereotype local names that mean LOGICAL (model construct)
    private static final Set<String> LOGICAL_STEREO  =
            Set.of("abstract", "Abstract", "Primitive", "CIMDatatype",
                   "enumeration", "Enumeration", "Compound", "attribute");

    private static final Set<String> LOGICAL_PACKAGES =
            Set.of("Topology","Meas","StateVariables","LoadModel","Contingency",
                   "InfWork","InfAssets","InfLocations","InfOperations");

    // ── Internal model ─────────────────────────────────────────────────────

    private static class ClassEntry {
        String       name;
        String       parentUri;
        String       stereotype;
        String       description;
        String       packageName;
        String       sourceFile;
        final List<String> ownAttributes = new ArrayList<>();

        ClassEntry(String name) { this.name = name; }
    }

    // ═══════════════════════════════════════════════════════════════════════
    // PUBLIC API
    // ═══════════════════════════════════════════════════════════════════════

    public List<CimClassDefinition> parse(InputStream in, String version)
            throws Exception {
        return parse(in, version, "uploaded.owl");
    }

    public List<CimClassDefinition> parse(InputStream in, String version,
                                           String fileName) throws Exception {
        log.info("Parsing OWL: '{}' version={}", fileName, version);
        long start = System.currentTimeMillis();
        Map<String, ClassEntry>   classes   = new LinkedHashMap<>();
        Map<String, List<String>> domainMap = new LinkedHashMap<>();
        parseOwlStream(in, fileName, classes, domainMap);
        return buildDefinitions(classes, domainMap, version, start);
    }

    public List<CimClassDefinition> parseMultiple(
            Map<String, InputStream> streams, String version) throws Exception {

        log.info("Merging {} OWL files for version: {}", streams.size(), version);
        long start = System.currentTimeMillis();
        Map<String, ClassEntry>   classes   = new LinkedHashMap<>();
        Map<String, List<String>> domainMap = new LinkedHashMap<>();

        int idx = 0;
        for (Map.Entry<String, InputStream> e : streams.entrySet()) {
            idx++;
            int bc = classes.size(), bd = domainMap.size();
            log.info("  [{}/{}] Parsing: {}", idx, streams.size(), e.getKey());
            parseOwlStream(e.getValue(), e.getKey(), classes, domainMap);
            log.info("  [{}/{}] Added {} classes, {} domain entries. Total: {}",
                    idx, streams.size(),
                    classes.size()-bc, domainMap.size()-bd, classes.size());
        }

        List<CimClassDefinition> defs =
                buildDefinitions(classes, domainMap, version, start);
        log.info("Merge complete: {} classes, {} with attributes, from {} files",
                defs.size(),
                defs.stream().filter(d -> !d.getOwnAttributes().isEmpty()).count(),
                streams.size());
        return defs;
    }

    // ═══════════════════════════════════════════════════════════════════════
    // CORE STAX PARSER
    // ═══════════════════════════════════════════════════════════════════════

    private void parseOwlStream(InputStream               in,
                                 String                    fileName,
                                 Map<String, ClassEntry>   classes,
                                 Map<String, List<String>> domainMap)
            throws Exception {

        XMLInputFactory fac = XMLInputFactory.newInstance();
        fac.setProperty(XMLInputFactory.IS_SUPPORTING_EXTERNAL_ENTITIES, false);
        fac.setProperty(XMLInputFactory.SUPPORT_DTD, false);
        fac.setProperty(XMLInputFactory.IS_COALESCING, true);

        XMLStreamReader r = fac.createXMLStreamReader(
                new BufferedInputStream(in, 64 * 1024));

        // ── Per-block state (reset at each top-level rdf:Description close)
        int    depth         = 0;

        // Accumulated fields for the current Description block
        String typeUri       = null;  // rdf:type resource
        String label         = null;  // rdfs:label text
        String stereotypeUri = null;  // uml:hasStereotype resource
        String subClassOfUri = null;  // rdfs:subClassOf resource
        String onPropertyUri = null;  // owl:onProperty resource
        String commentText   = null;  // rdfs:comment text
        boolean inDescription= false;

        StringBuilder textBuf = new StringBuilder(256);

        try {
            while (r.hasNext()) {
                int event = r.next();

                switch (event) {

                    // ── OPEN TAG ───────────────────────────────────────────
                    case XMLStreamConstants.START_ELEMENT -> {
                        depth++;
                        String ns    = r.getNamespaceURI();
                        String local = r.getLocalName();
                        textBuf.setLength(0);

                        // ── Depth 2: new top-level block ───────────────────
                        if (depth == 2) {
                            // Reset all block state
                            typeUri       = null;
                            label         = null;
                            stereotypeUri = null;
                            subClassOfUri = null;
                            onPropertyUri = null;
                            commentText   = null;
                            inDescription = "Description".equals(local) && isRdf(ns);

                            // Inline rdf:type attribute (rare but possible)
                            String inlineType = r.getAttributeValue(NS_RDF, "type");
                            if (inlineType != null) typeUri = inlineType;
                        }

                        // ── Depth 3: child elements inside a block ─────────
                        else if (depth == 3 && inDescription) {

                            // rdf:type → what this block IS
                            if ("type".equals(local) && isRdf(ns)) {
                                String ref = r.getAttributeValue(NS_RDF, "resource");
                                if (ref != null && typeUri == null) typeUri = ref;
                            }

                            // uml:hasStereotype → CPSM stereotype
                            else if ("hasStereotype".equals(local) && isUml(ns)) {
                                String ref = r.getAttributeValue(NS_RDF, "resource");
                                if (ref != null) stereotypeUri = ref;
                            }

                            // rdfs:subClassOf → parent class
                            else if ("subClassOf".equals(local) && isRdfs(ns)) {
                                String ref = r.getAttributeValue(NS_RDF, "resource");
                                if (ref != null && !ref.isBlank()
                                        && subClassOfUri == null) {
                                    subClassOfUri = ref;
                                }
                            }

                            // owl:onProperty → "ClassName.attrName" → maps attr to class
                            else if ("onProperty".equals(local) && isOwl(ns)) {
                                String ref = r.getAttributeValue(NS_RDF, "resource");
                                if (ref != null) onPropertyUri = ref;
                            }

                            // cims:belongsToCategory OR rdfs:isDefinedBy (fallback)
                            // (not seen in CPSM but supported for full CIM OWL)
                        }
                    }

                    // ── TEXT ───────────────────────────────────────────────
                    case XMLStreamConstants.CHARACTERS,
                         XMLStreamConstants.CDATA ->
                            textBuf.append(r.getText());

                    // ── CLOSE TAG ──────────────────────────────────────────
                    case XMLStreamConstants.END_ELEMENT -> {
                        String ns    = r.getNamespaceURI();
                        String local = r.getLocalName();
                        String text  = textBuf.toString().trim();

                        // Collect text content from child elements
                        if (depth == 3 && inDescription) {
                            if ("label".equals(local) && isRdfs(ns) && !text.isEmpty()) {
                                label = text;
                            }
                            if ("comment".equals(local) && isRdfs(ns) && !text.isEmpty()) {
                                commentText = text;
                            }
                        }

                        // Top-level block closed — process accumulated data
                        if (depth == 2) {
                            processBlock(typeUri, label, stereotypeUri,
                                    subClassOfUri, onPropertyUri, commentText,
                                    fileName, classes, domainMap);
                        }

                        depth--;
                        textBuf.setLength(0);
                    }
                }
            }
        } finally {
            r.close();
        }
    }

    // ── Process one completed rdf:Description block ────────────────────────

    /**
     * Decides what a completed block is and registers it.
     *
     * Block identification matrix (from actual file):
     *
     *   typeUri ends in "Class"
     *     → This IS a class.
     *     → Name = rdfs:label. Parent = rdfs:subClassOf localName.
     *
     *   stereotypeUri ends in "attribute" AND typeUri ends in "Datatype"
     *     → This IS an attribute definition. Name = rdfs:label.
     *     → Class assignment happens via owl:Restriction blocks.
     *
     *   typeUri ends in "Restriction" AND onPropertyUri contains "."
     *     → This maps an attribute to a class.
     *     → "http://...#ACLineSegment.bch" → class="ACLineSegment", attr="bch"
     *
     *   typeUri ends in "Restriction" AND no "." in onPropertyUri
     *     → Association/reference (not a simple attribute). Skip or record.
     */
    private void processBlock(
            String                    typeUri,
            String                    label,
            String                    stereotypeUri,
            String                    subClassOfUri,
            String                    onPropertyUri,
            String                    comment,
            String                    fileName,
            Map<String, ClassEntry>   classes,
            Map<String, List<String>> domainMap) {

        if (typeUri == null) return;

        String typeLocal = localName(typeUri);
        if (typeLocal == null) return;

        // ── CASE 1: owl:Class → register a CIM class ──────────────────────
        if ("Class".equals(typeLocal)) {
            if (label == null || label.isBlank()) return;

            ClassEntry entry = classes.computeIfAbsent(label, ClassEntry::new);
            if (entry.sourceFile == null) entry.sourceFile = fileName;

            // First-wins for all structural fields
            if (subClassOfUri != null && entry.parentUri == null) {
                entry.parentUri = subClassOfUri;
            }
            if (stereotypeUri != null && entry.stereotype == null) {
                entry.stereotype = localName(stereotypeUri);
            }
            if (comment != null && entry.description == null) {
                entry.description = comment;
            }
            return;
        }

        // ── CASE 2: owl:Restriction → maps attribute/assoc to a class ─────
        // owl:onProperty = "http://...#ACLineSegment.bch"
        //   → class = "ACLineSegment", attribute = "bch"
        if ("Restriction".equals(typeLocal) && onPropertyUri != null) {
            String propLocal = localName(onPropertyUri); // "ACLineSegment.bch"
            if (propLocal != null && propLocal.contains(".")) {
                int dot        = propLocal.lastIndexOf('.');
                String cls     = propLocal.substring(0, dot);   // "ACLineSegment"
                String attr    = propLocal.substring(dot + 1);  // "bch"
                if (!cls.isBlank() && !attr.isBlank()) {
                    // Ensure class entry exists (may not be seen yet)
                    classes.computeIfAbsent(cls, ClassEntry::new);
                    // Register attribute against class
                    List<String> attrs = domainMap.computeIfAbsent(
                            cls, k -> new ArrayList<>());
                    if (!attrs.contains(attr)) attrs.add(attr);
                }
            }
            return;
        }

        // ── CASE 3: rdfs:Datatype with UML#attribute stereotype ───────────
        // These define the attribute type metadata.
        // The actual class→attribute mapping comes from the Restriction block.
        // We don't need to process these separately because the Restriction
        // blocks already give us the full "ClassName.attrName" mapping.
        // Nothing to do here.
    }

    // ═══════════════════════════════════════════════════════════════════════
    // BUILD DEFINITIONS
    // ═══════════════════════════════════════════════════════════════════════

    private List<CimClassDefinition> buildDefinitions(
            Map<String, ClassEntry>   classes,
            Map<String, List<String>> domainMap,
            String                    version,
            long                      startMs) {

        // Attach attributes from domainMap to their ClassEntry
        domainMap.forEach((className, attrs) -> {
            ClassEntry entry = classes.get(className);
            if (entry != null) {
                for (String attr : attrs) {
                    if (!entry.ownAttributes.contains(attr)) {
                        entry.ownAttributes.add(attr);
                    }
                }
            }
        });

        // Build parent map (localName → parentLocalName)
        Map<String, String> parentMap = new LinkedHashMap<>();
        classes.forEach((name, entry) -> {
            if (entry.parentUri != null) {
                String pName = localName(entry.parentUri);
                if (pName != null && !pName.equals(name)) {
                    parentMap.put(name, pName);
                }
            }
        });

        // Build CimClassDefinition list
        List<CimClassDefinition> defs = new ArrayList<>();
        classes.forEach((name, entry) -> {
            CimClassDefinition def = new CimClassDefinition(
                    name,
                    parentMap.get(name),
                    computeAncestors(name, parentMap),
                    new ArrayList<>(entry.ownAttributes),
                    determineCategory(entry),
                    version);
            def.setCimPackage(entry.packageName != null ? entry.packageName : "Core");
            def.setDescription(entry.description);
            defs.add(def);
        });

        long elapsed = System.currentTimeMillis() - startMs;
        log.info("Build complete: {} classes ({} with attributes) in {}ms",
                defs.size(),
                defs.stream().filter(d -> !d.getOwnAttributes().isEmpty()).count(),
                elapsed);
        return defs;
    }

    // ── Helpers ────────────────────────────────────────────────────────────

    private List<String> computeAncestors(String cls, Map<String, String> parentMap) {
        List<String> chain   = new ArrayList<>();
        Set<String>  visited = new HashSet<>();
        String       cur     = parentMap.get(cls);
        while (cur != null && !visited.contains(cur)) {
            chain.add(cur);
            visited.add(cur);
            cur = parentMap.get(cur);
        }
        return chain;
    }

    private String determineCategory(ClassEntry entry) {
        if (entry.stereotype != null) {
            if (PHYSICAL_STEREO.contains(entry.stereotype)) return "PHYSICAL";
            if (LOGICAL_STEREO.contains(entry.stereotype))  return "LOGICAL";
        }
        if (entry.packageName != null
                && LOGICAL_PACKAGES.contains(entry.packageName)) return "LOGICAL";
        if (entry.name != null) {
            String n = entry.name;
            if (n.endsWith("Value") || n.endsWith("Schedule") || n.endsWith("Island")
                    || n.endsWith("Node") || n.equals("Terminal")
                    || n.equals("ACDCTerminal") || n.equals("DCTerminal")
                    || n.endsWith("Kind") || n.endsWith("Type")) return "LOGICAL";
        }
        return "PHYSICAL";
    }

    private boolean isOwl(String ns)  { return NS_OWL.equals(ns); }
    private boolean isRdf(String ns)  { return NS_RDF.equals(ns); }
    private boolean isRdfs(String ns) { return NS_RDFS.equals(ns); }
    private boolean isUml(String ns)  {
        return NS_UML.equals(ns)
            || (ns != null && ns.contains("langdale.com.au"));
    }

    /** "http://iec.ch/TC57/CIM100#ACLineSegment" → "ACLineSegment" */
    String localName(String uri) {
        if (uri == null || uri.isBlank()) return null;
        int idx = Math.max(uri.lastIndexOf('#'), uri.lastIndexOf('/'));
        return (idx >= 0 && idx < uri.length() - 1)
                ? uri.substring(idx + 1) : uri;
    }
}

package com.cim.service;

import com.cim.model.mongo.CimClassDefinition;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import javax.xml.stream.*;
import java.io.*;
import java.util.*;

/**
 * CIM OWL PARSER — CPSM/Langdale profile format
 * ════════════════════════════════════════════════════════════════════
 *
 * ACTUAL structure found in your CPSM files (from diagnose endpoint):
 *
 *   Namespaces:
 *     rdf   = http://www.w3.org/1999/02/22-rdf-syntax-ns#
 *     owl   = http://www.w3.org/2002/07/owl#
 *     rdfs  = http://www.w3.org/2000/01/rdf-schema#
 *     uml   = http://langdale.com.au/2005/UML#       ← stereotype NS
 *     cpsm  = http://ucaiug.org/2020/CPSM-CoreEquipment#
 *
 *   Structure: ALL top-level elements are rdf:Description with
 *              rdf:about="" (EMPTY string). The actual class URI
 *              is found INSIDE as a child rdf:type element.
 *
 * ACTUAL file structure:
 *
 *   <!-- A CIM class -->
 *   <rdf:Description rdf:about="">
 *     <rdf:type rdf:resource="http://...#ACLineSegment"/>
 *     <rdfs:subClassOf rdf:resource="http://...#Conductor"/>
 *     <uml:hasStereotype rdf:resource="...#concrete"/>
 *     <rdfs:label>ACLineSegment</rdfs:label>
 *     <rdfs:comment>A wire segment...</rdfs:comment>
 *   </rdf:Description>
 *
 *   <!-- A property (attribute) -->
 *   <rdf:Description rdf:about="">
 *     <rdf:type rdf:resource="http://...#DatatypeProperty"/>
 *     <rdfs:domain rdf:resource="http://...#ACLineSegment"/>
 *     <rdfs:label>r</rdfs:label>
 *   </rdf:Description>
 *
 * Key insight:
 *   - rdf:about is ALWAYS empty ("") — the identity comes from rdf:type
 *   - rdf:type tells us WHAT the Description is (class or property)
 *   - The class NAME is the local name of the rdf:type URI
 *   - For a property, the name is from rdfs:label
 *   - Stereotype uses uml:hasStereotype, NOT cims:stereotype
 */
@Component
public class CIMOwlParser {

    private static final Logger log = LoggerFactory.getLogger(CIMOwlParser.class);

    // ── Namespaces ─────────────────────────────────────────────────────────
    private static final String NS_RDF  = "http://www.w3.org/1999/02/22-rdf-syntax-ns#";
    private static final String NS_RDFS = "http://www.w3.org/2000/01/rdf-schema#";
    private static final String NS_OWL  = "http://www.w3.org/2002/07/owl#";

    // Stereotype namespace — Langdale UML profile used by CPSM
    private static final String NS_UML_LANGDALE = "http://langdale.com.au/2005/UML#";

    // URIs that indicate a Description block IS a CIM class
    private static final Set<String> CLASS_TYPE_URIS = new HashSet<>(Set.of(
        NS_OWL  + "Class",
        "http://www.w3.org/2000/01/rdf-schema#Class",
        NS_OWL  + "NamedIndividual"
    ));

    // URIs that indicate a Description block IS a property/attribute
    private static final Set<String> PROPERTY_TYPE_URIS = new HashSet<>(Set.of(
        NS_OWL + "DatatypeProperty",
        NS_OWL + "ObjectProperty",
        NS_OWL + "AnnotationProperty",
        NS_RDF + "Property"
    ));

    // Stereotypes → LOGICAL category
    private static final Set<String> LOGICAL_STEREOTYPES =
            Set.of("abstract", "Primitive", "CIMDatatype",
                   "enumeration", "Compound", "concrete");
    // Note: "concrete" maps to PHYSICAL in the category logic below

    // Packages → LOGICAL category
    private static final Set<String> LOGICAL_PACKAGES =
            Set.of("Topology", "Meas", "StateVariables", "LoadModel",
                   "Contingency", "InfWork", "InfAssets", "InfLocations",
                   "InfOperations", "IEC61968CIMVersion", "IEC61970CIMVersion");

    // ── Internal model ─────────────────────────────────────────────────────

    private static class ClassEntry {
        String       name;         // "ACLineSegment"
        String       parentUri;    // raw URI of parent
        String       packageName;
        String       stereotype;   // "concrete", "abstract", etc.
        String       description;
        String       sourceFile;
        List<String> ownAttributes = new ArrayList<>();

        ClassEntry(String name) { this.name = name; }
    }

    // ═══════════════════════════════════════════════════════════════════════
    // PUBLIC API
    // ═══════════════════════════════════════════════════════════════════════

    public List<CimClassDefinition> parse(InputStream in, String version) throws Exception {
        return parse(in, version, "uploaded.owl");
    }

    public List<CimClassDefinition> parse(InputStream in,
                                           String version,
                                           String fileName) throws Exception {
        log.info("Parsing OWL: '{}' version={}", fileName, version);
        long start = System.currentTimeMillis();

        Map<String, ClassEntry>   classes   = new LinkedHashMap<>();
        Map<String, List<String>> domainMap = new LinkedHashMap<>();

        parseOwlStream(in, fileName, classes, domainMap);
        return buildDefinitions(classes, domainMap, version, start);
    }

    public List<CimClassDefinition> parseMultiple(
            Map<String, InputStream> streams, String version) throws Exception {

        log.info("Merging {} OWL files for version: {}", streams.size(), version);
        long start = System.currentTimeMillis();

        Map<String, ClassEntry>   classes   = new LinkedHashMap<>();
        Map<String, List<String>> domainMap = new LinkedHashMap<>();

        int idx = 0;
        for (Map.Entry<String, InputStream> e : streams.entrySet()) {
            idx++;
            int beforeC = classes.size(), beforeD = domainMap.size();
            log.info("  [{}/{}] Parsing: {}", idx, streams.size(), e.getKey());

            parseOwlStream(e.getValue(), e.getKey(), classes, domainMap);

            log.info("  [{}/{}] Added {} classes, {} property domains. Total: {}",
                    idx, streams.size(),
                    classes.size() - beforeC,
                    domainMap.size() - beforeD,
                    classes.size());
        }

        List<CimClassDefinition> defs = buildDefinitions(classes, domainMap, version, start);
        log.info("Multi-profile merge complete: {} total classes from {} files",
                defs.size(), streams.size());
        return defs;
    }

    // ═══════════════════════════════════════════════════════════════════════
    // STAX PARSER — handles CPSM Langdale format
    // ═══════════════════════════════════════════════════════════════════════

    private void parseOwlStream(InputStream               in,
                                 String                    fileName,
                                 Map<String, ClassEntry>   classes,
                                 Map<String, List<String>> domainMap) throws Exception {

        XMLInputFactory fac = XMLInputFactory.newInstance();
        fac.setProperty(XMLInputFactory.IS_SUPPORTING_EXTERNAL_ENTITIES, false);
        fac.setProperty(XMLInputFactory.SUPPORT_DTD, false);
        fac.setProperty(XMLInputFactory.IS_COALESCING, true);

        XMLStreamReader r = fac.createXMLStreamReader(
                new BufferedInputStream(in, 64 * 1024));

        // ── Per-element state ──────────────────────────────────────────────
        // In CPSM format, every top-level element is rdf:Description with
        // rdf:about="". We accumulate ALL child elements for that Description,
        // then decide what it is once we have all the information.

        int           depth           = 0;
        boolean       inDescription   = false;

        // Accumulated data for current top-level rdf:Description block
        String        blockTypeUri    = null;  // from <rdf:type rdf:resource="..."/>
        String        blockLabel      = null;  // from <rdfs:label>text</rdfs:label>
        String        blockParentUri  = null;  // from <rdfs:subClassOf rdf:resource="..."/>
        String        blockDomainUri  = null;  // from <rdfs:domain rdf:resource="..."/>
        String        blockStereotype = null;  // from <uml:hasStereotype rdf:resource="..."/>
        String        blockComment    = null;  // from <rdfs:comment>text</rdfs:comment>
        String        blockPackage    = null;  // from <rdfs:isDefinedBy rdf:resource="..."/>
        String        blockRdfAbout   = null;  // rdf:about on the Description itself
        StringBuilder textBuf         = new StringBuilder(256);

        try {
            while (r.hasNext()) {
                int event = r.next();

                switch (event) {

                    case XMLStreamConstants.START_ELEMENT -> {
                        depth++;
                        String ns    = r.getNamespaceURI();
                        String local = r.getLocalName();
                        textBuf.setLength(0);

                        // ── Depth 2: top-level element ─────────────────────
                        if (depth == 2) {
                            // Reset all accumulated block data
                            blockTypeUri    = null;
                            blockLabel      = null;
                            blockParentUri  = null;
                            blockDomainUri  = null;
                            blockStereotype = null;
                            blockComment    = null;
                            blockPackage    = null;

                            // Check for rdf:about on this element
                            blockRdfAbout = r.getAttributeValue(NS_RDF, "about");
                            if (blockRdfAbout == null)
                                blockRdfAbout = r.getAttributeValue(NS_RDF, "ID");

                            inDescription = "Description".equals(local) && isRdf(ns);

                            // VARIANT A: owl:Class or rdfs:Class directly
                            if ("Class".equals(local) && (isOwl(ns) || isRdfs(ns))) {
                                blockTypeUri = NS_OWL + "Class";
                                // rdf:about on element itself is the class URI
                            }
                            // VARIANT A: owl:DatatypeProperty etc. directly
                            else if (("DatatypeProperty".equals(local)
                                       || "ObjectProperty".equals(local)
                                       || "AnnotationProperty".equals(local))
                                     && isOwl(ns)) {
                                blockTypeUri = NS_OWL + local;
                            }

                            // Inline rdf:type attribute (VARIANT D)
                            String inlineType = r.getAttributeValue(NS_RDF, "type");
                            if (inlineType != null && blockTypeUri == null) {
                                blockTypeUri = inlineType;
                            }
                        }

                        // ── Depth 3: child elements inside a Description ────
                        else if (depth == 3 && inDescription) {

                            // rdf:type → tells us what this block IS
                            if ("type".equals(local) && isRdf(ns)) {
                                String typeRef = r.getAttributeValue(NS_RDF, "resource");
                                if (typeRef != null && blockTypeUri == null) {
                                    blockTypeUri = typeRef;
                                }
                            }

                            // rdfs:subClassOf → parent class
                            else if ("subClassOf".equals(local) && isRdfs(ns)) {
                                String ref = r.getAttributeValue(NS_RDF, "resource");
                                if (ref != null && !ref.isBlank()
                                        && blockParentUri == null) {
                                    blockParentUri = ref;
                                }
                            }

                            // rdfs:domain → which class owns this property
                            else if ("domain".equals(local) && isRdfs(ns)) {
                                String ref = r.getAttributeValue(NS_RDF, "resource");
                                if (ref != null) blockDomainUri = localName(ref);
                            }

                            // uml:hasStereotype → CPSM uses Langdale UML NS
                            else if ("hasStereotype".equals(local)
                                     && NS_UML_LANGDALE.equals(ns)) {
                                String ref = r.getAttributeValue(NS_RDF, "resource");
                                if (ref != null) {
                                    blockStereotype = localName(ref);
                                }
                            }

                            // cims:stereotype (fallback for full CIM OWL)
                            else if ("stereotype".equals(local)
                                     && isCims(ns)) {
                                // text content read at END_ELEMENT
                            }

                            // rdfs:isDefinedBy → package (CPSM uses this)
                            else if ("isDefinedBy".equals(local) && isRdfs(ns)) {
                                String ref = r.getAttributeValue(NS_RDF, "resource");
                                if (ref != null) blockPackage = localName(ref);
                            }

                            // cims:belongsToCategory (full CIM OWL)
                            else if ("belongsToCategory".equals(local) && isCims(ns)) {
                                String ref = r.getAttributeValue(NS_RDF, "resource");
                                if (ref != null) blockPackage = localName(ref);
                            }
                        }
                    }

                    // ── TEXT ───────────────────────────────────────────────
                    case XMLStreamConstants.CHARACTERS,
                         XMLStreamConstants.CDATA ->
                            textBuf.append(r.getText());

                    // ── CLOSE TAG ──────────────────────────────────────────
                    case XMLStreamConstants.END_ELEMENT -> {
                        String ns    = r.getNamespaceURI();
                        String local = r.getLocalName();
                        String text  = textBuf.toString().trim();

                        // ── Depth 3: collect text content from child elements ─
                        if (depth == 3 && inDescription) {
                            if ("label".equals(local) && isRdfs(ns)
                                    && !text.isEmpty()) {
                                blockLabel = text;
                            }
                            if ("comment".equals(local) && isRdfs(ns)
                                    && !text.isEmpty()) {
                                blockComment = text;
                            }
                            // cims:stereotype text content (full CIM OWL)
                            if ("stereotype".equals(local) && isCims(ns)
                                    && !text.isEmpty()
                                    && blockStereotype == null) {
                                blockStereotype = text;
                            }
                        }

                        // ── Depth 2: top-level element closed ─────────────
                        if (depth == 2) {
                            processCompletedBlock(
                                    blockTypeUri, blockRdfAbout, blockLabel,
                                    blockParentUri, blockDomainUri,
                                    blockStereotype, blockComment, blockPackage,
                                    fileName, classes, domainMap);
                        }

                        depth--;
                        textBuf.setLength(0);
                    }
                }
            }
        } finally {
            r.close();
        }
    }

    // ── Process one completed rdf:Description block ────────────────────────

    /**
     * Called when a top-level rdf:Description block closes.
     * Decides whether it is a CLASS or PROPERTY and registers it.
     *
     * In CPSM format:
     *   - blockRdfAbout is "" (empty) for all blocks
     *   - blockTypeUri  is the actual class/property URI
     *   - blockLabel    is the human-readable name (used as class name)
     *   - For a class:    blockTypeUri ends in "ACLineSegment" etc.
     *   - For a property: blockTypeUri is "...#DatatypeProperty" etc.
     */
    private void processCompletedBlock(
            String                    typeUri,
            String                    rdfAbout,
            String                    label,
            String                    parentUri,
            String                    domainUri,
            String                    stereotype,
            String                    comment,
            String                    packageName,
            String                    fileName,
            Map<String, ClassEntry>   classes,
            Map<String, List<String>> domainMap) {

        if (typeUri == null) return;

        // ── CASE 1: typeUri IS a class declaration ─────────────────────────
        // e.g. rdf:type rdf:resource="http://...#ACLineSegment"
        // The class name = localName(typeUri) only if typeUri is NOT a
        // known meta-type (owl:Class, rdfs:Class etc.)
        if (!CLASS_TYPE_URIS.contains(typeUri)
                && !PROPERTY_TYPE_URIS.contains(typeUri)) {

            // This is the CPSM pattern: rdf:type points to the actual class URI
            String className = localName(typeUri);
            if (className == null || className.isBlank()) return;

            // Determine if this block is describing a class or a property
            // If it has a domain → it's a property/attribute of that class
            if (domainUri != null) {
                // This is a property constraint on a class
                // The "property name" comes from the label
                if (label != null && !label.isBlank()) {
                    domainMap.computeIfAbsent(domainUri, k -> new ArrayList<>())
                             .add(label);
                }
                return;
            }

            // No domain → it is describing THE class itself
            // Register the class and fill in its details
            ClassEntry entry = classes.computeIfAbsent(className, ClassEntry::new);
            if (entry.sourceFile == null) entry.sourceFile = fileName;

            // Only set fields that are not already set (first-file-wins)
            if (parentUri != null && entry.parentUri == null) {
                entry.parentUri = parentUri;
            }
            if (stereotype != null && entry.stereotype == null) {
                entry.stereotype = stereotype;
            }
            if (comment != null && entry.description == null) {
                entry.description = comment;
            }
            if (packageName != null && entry.packageName == null) {
                entry.packageName = packageName;
            }
            return;
        }

        // ── CASE 2: typeUri IS owl:Class / rdfs:Class ──────────────────────
        // Standard OWL format: the class name comes from rdf:about or rdfs:label
        if (CLASS_TYPE_URIS.contains(typeUri)) {
            String className = null;

            // Try rdf:about first
            if (rdfAbout != null && !rdfAbout.isBlank()) {
                className = localName(rdfAbout);
            }
            // Fall back to rdfs:label
            if ((className == null || className.isBlank())
                    && label != null && !label.isBlank()) {
                className = label;
            }
            if (className == null || className.isBlank()) return;

            ClassEntry entry = classes.computeIfAbsent(className, ClassEntry::new);
            if (entry.sourceFile == null) entry.sourceFile = fileName;
            if (parentUri   != null && entry.parentUri   == null) entry.parentUri   = parentUri;
            if (stereotype  != null && entry.stereotype  == null) entry.stereotype  = stereotype;
            if (comment     != null && entry.description == null) entry.description = comment;
            if (packageName != null && entry.packageName == null) entry.packageName = packageName;
            return;
        }

        // ── CASE 3: typeUri IS owl:DatatypeProperty etc. ───────────────────
        // Property name from rdfs:label, domain from rdfs:domain
        if (PROPERTY_TYPE_URIS.contains(typeUri)) {
            if (domainUri != null && label != null && !label.isBlank()) {
                domainMap.computeIfAbsent(domainUri, k -> new ArrayList<>())
                         .add(label);
            } else if (domainUri != null && rdfAbout != null && !rdfAbout.isBlank()) {
                String propName = propertyLocalName(rdfAbout);
                if (propName != null && !propName.isBlank()) {
                    domainMap.computeIfAbsent(domainUri, k -> new ArrayList<>())
                             .add(propName);
                }
            }
        }
    }

    // ═══════════════════════════════════════════════════════════════════════
    // BUILD DEFINITIONS
    // ═══════════════════════════════════════════════════════════════════════

    private List<CimClassDefinition> buildDefinitions(
            Map<String, ClassEntry>   classes,
            Map<String, List<String>> domainMap,
            String                    version,
            long                      startMs) {

        // Attach attributes to their class entries (additive)
        domainMap.forEach((className, attrs) -> {
            ClassEntry entry = classes.get(className);
            if (entry != null) {
                for (String attr : attrs) {
                    if (!entry.ownAttributes.contains(attr)) {
                        entry.ownAttributes.add(attr);
                    }
                }
            }
        });

        // Build parent map (localName → parentLocalName)
        Map<String, String> parentMap = new LinkedHashMap<>();
        classes.forEach((name, entry) -> {
            if (entry.parentUri != null) {
                String parentName = localName(entry.parentUri);
                if (parentName != null && !parentName.equals(name)) {
                    parentMap.put(name, parentName);
                }
            }
        });

        // Build CimClassDefinition list
        List<CimClassDefinition> defs = new ArrayList<>();
        classes.forEach((name, entry) -> {
            CimClassDefinition def = new CimClassDefinition(
                    name,
                    parentMap.get(name),
                    computeAncestors(name, parentMap),
                    new ArrayList<>(entry.ownAttributes),
                    determineCategory(entry),
                    version);
            def.setCimPackage(entry.packageName != null ? entry.packageName : "Core");
            def.setDescription(entry.description);
            defs.add(def);
        });

        log.info("Build complete: {} classes, {} with attributes, in {}ms",
                defs.size(),
                defs.stream().filter(d -> !d.getOwnAttributes().isEmpty()).count(),
                System.currentTimeMillis() - startMs);
        return defs;
    }

    // ── Helpers ────────────────────────────────────────────────────────────

    private List<String> computeAncestors(String cls, Map<String, String> parentMap) {
        List<String> chain   = new ArrayList<>();
        Set<String>  visited = new HashSet<>();
        String       cur     = parentMap.get(cls);
        while (cur != null && !visited.contains(cur)) {
            chain.add(cur);
            visited.add(cur);
            cur = parentMap.get(cur);
        }
        return chain;
    }

    private String determineCategory(ClassEntry entry) {
        // "concrete" = physical equipment
        if ("concrete".equalsIgnoreCase(entry.stereotype)) return "PHYSICAL";
        // other stereotypes → logical
        if (entry.stereotype != null
                && LOGICAL_STEREOTYPES.contains(entry.stereotype)) return "LOGICAL";
        if (entry.packageName != null
                && LOGICAL_PACKAGES.contains(entry.packageName)) return "LOGICAL";
        if (entry.name != null) {
            String n = entry.name;
            if (n.endsWith("Value") || n.endsWith("Schedule") || n.endsWith("Island")
                    || n.endsWith("Node") || n.equals("Terminal")
                    || n.equals("ACDCTerminal") || n.equals("DCTerminal")
                    || n.endsWith("Type") || n.endsWith("Kind")) return "LOGICAL";
        }
        return "PHYSICAL";
    }

    private boolean isOwl(String ns)  { return NS_OWL.equals(ns); }
    private boolean isRdf(String ns)  { return NS_RDF.equals(ns); }
    private boolean isRdfs(String ns) { return NS_RDFS.equals(ns); }
    private boolean isCims(String ns) {
        if (ns == null) return false;
        return ns.contains("rdf-schema-extensions")
            || ns.contains("TC57/NonStandard")
            || ns.contains("CIM-generic");
    }

    /** "http://iec.ch/...#ACLineSegment" → "ACLineSegment" */
    String localName(String uri) {
        if (uri == null || uri.isBlank()) return null;
        int idx = Math.max(uri.lastIndexOf('#'), uri.lastIndexOf('/'));
        return (idx >= 0 && idx < uri.length() - 1)
                ? uri.substring(idx + 1) : uri;
    }

    /** "...#ACLineSegment.r" → "r" | "...#ACLineSegment" → "ACLineSegment" */
    private String propertyLocalName(String uri) {
        String local = localName(uri);
        if (local == null) return null;
        int dot = local.lastIndexOf('.');
        return (dot >= 0 && dot < local.length() - 1)
                ? local.substring(dot + 1) : local;
    }
}

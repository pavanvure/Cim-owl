package com.cim.config;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.context.event.ApplicationReadyEvent;
import org.springframework.context.event.EventListener;
import org.springframework.data.domain.Sort;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.index.CompoundIndexDefinition;
import org.springframework.data.mongodb.core.index.Index;
import org.springframework.data.mongodb.core.index.IndexOperations;
import org.springframework.stereotype.Component;
import org.bson.Document;

/**
 * MongoDB Index Configuration
 * ════════════════════════════════════════════════════════════════════
 *
 * WHY THIS IS CRITICAL for 1.87M objects:
 *
 *   Without indexes:
 *     findByJobId(jobId, page, 500)  → full collection scan every page
 *     1,876,058 objects / 500 per page = 3,752 pages
 *     Each page = full scan of entire collection
 *     = 3,752 × 1,876,058 comparisons = HOURS
 *
 *   With indexes:
 *     findByJobId → index lookup → O(log N)
 *     Each page retrieval = milliseconds
 *     Total reference resolution = minutes not hours
 *
 * Indexes created:
 *
 *   cim_objects:
 *     { jobId: 1, cimType: 1 }    ← getObjectsByType, countByType
 *     { jobId: 1, category: 1 }   ← getPhysicalObjects, getLogicalObjects
 *     { jobId: 1, rdfId: 1 }      ← reference resolution rdfId lookup
 *     { jobId: 1 }                ← all findByJobId queries
 *     { mrid: 1 }                 ← mRID uniqueness checks
 *
 *   validation_findings:
 *     { jobId: 1, severity: 1 }   ← getFindingsBySeverity
 *     { jobId: 1, stage: 1 }      ← getFindingsByStage
 *     { jobId: 1 }                ← all findByJobId queries
 *
 *   validation_jobs:
 *     { jobId: 1 }  unique        ← getJob(jobId)
 *     { status: 1 }               ← findByStatus
 */
@Component
public class MongoIndexConfig {

    private static final Logger log = LoggerFactory.getLogger(MongoIndexConfig.class);

    private final MongoTemplate mongoTemplate;

    public MongoIndexConfig(MongoTemplate mongoTemplate) {
        this.mongoTemplate = mongoTemplate;
    }

    @EventListener(ApplicationReadyEvent.class)
    public void ensureIndexes() {
        log.info("Ensuring MongoDB indexes...");
        long start = System.currentTimeMillis();

        ensureCimObjectIndexes();
        ensureFindingIndexes();
        ensureJobIndexes();

        log.info("MongoDB indexes ensured in {}ms",
                System.currentTimeMillis() - start);
    }

    private void ensureCimObjectIndexes() {
        IndexOperations ops = mongoTemplate.indexOps("cim_objects");

        // PRIMARY: jobId alone — most findByJobId queries use this
        ops.ensureIndex(new Index()
                .on("jobId", Sort.Direction.ASC)
                .background());

        // jobId + rdfId — critical for StreamingReferenceResolver index build
        // This makes buildRdfIdIndex() fast: each page lookup = O(log N)
        ops.ensureIndex(new CompoundIndexDefinition(
                new Document("jobId", 1).append("rdfId", 1))
                .background());

        // jobId + cimType — for getObjectsByType and type breakdown aggregation
        ops.ensureIndex(new CompoundIndexDefinition(
                new Document("jobId", 1).append("cimType", 1))
                .background());

        // jobId + category — for getPhysicalObjects / getLogicalObjects
        ops.ensureIndex(new CompoundIndexDefinition(
                new Document("jobId", 1).append("category", 1))
                .background());

        // mrid — for cross-object mRID uniqueness checks
        ops.ensureIndex(new Index()
                .on("mrid", Sort.Direction.ASC)
                .background());

        log.info("  cim_objects: 5 indexes ensured");
    }

    private void ensureFindingIndexes() {
        IndexOperations ops = mongoTemplate.indexOps("validation_findings");

        ops.ensureIndex(new Index()
                .on("jobId", Sort.Direction.ASC)
                .background());

        ops.ensureIndex(new CompoundIndexDefinition(
                new Document("jobId", 1).append("severity", 1))
                .background());

        ops.ensureIndex(new CompoundIndexDefinition(
                new Document("jobId", 1).append("stage", 1))
                .background());

        ops.ensureIndex(new CompoundIndexDefinition(
                new Document("jobId", 1).append("objectType", 1))
                .background());

        log.info("  validation_findings: 4 indexes ensured");
    }

    private void ensureJobIndexes() {
        IndexOperations ops = mongoTemplate.indexOps("validation_jobs");

        ops.ensureIndex(new Index()
                .on("jobId", Sort.Direction.ASC)
                .unique()
                .background());

        ops.ensureIndex(new Index()
                .on("status", Sort.Direction.ASC)
                .background());

        log.info("  validation_jobs: 2 indexes ensured");
    }
}

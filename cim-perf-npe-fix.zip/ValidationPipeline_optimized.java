// ADD validateSingle() METHOD to ValidationPipeline.java

    /**
     * Validates a single CIMObject — used by streamAndValidate().
     *
     * Stage 1 skipped (physical filter done by query).
     * Stage 2 path validation — all objects.
     * Stage 3 reference check — only if has references.
     * Stage 4 business rules — only PHYSICAL objects.
     */
    public List<PipelineFinding> validateSingle(CIMObject obj, String jobId) {
        List<PipelineFinding> findings = new ArrayList<>();

        // Stage 2 — Attribute path validation
        try {
            findings.addAll(pathValidationStage.validateObject(obj, jobId));
        } catch (Exception e) {
            log.debug("Path validation error for {}: {}", obj.getCimType(), e.getMessage());
        }

        // Stage 3 — Reference resolution check (skip if no refs)
        if (obj.hasReferences()) {
            try {
                findings.addAll(referenceStage.validateObject(obj, jobId));
            } catch (Exception e) {
                log.debug("Ref validation error for {}: {}", obj.getCimType(), e.getMessage());
            }
        }

        // Stage 4 — Business rules (physical only)
        if (!"LOGICAL".equals(obj.getCategory())) {
            try {
                findings.addAll(businessRuleEngine.validate(obj, jobId));
            } catch (Exception e) {
                log.debug("Rule error for {}: {}", obj.getCimType(), e.getMessage());
            }
        }

        return findings;
    }

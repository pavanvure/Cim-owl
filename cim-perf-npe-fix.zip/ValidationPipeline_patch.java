// ADD validateSingle() to ValidationPipeline.java
// Uses correct existing method names found in your codebase

    /**
     * validateSingle — optimized for streaming validation.
     *
     * KEY CHANGE from previous version:
     *   Stage 2 (path validation) SKIPS objects whose cimType is
     *   not registered in the CIM hierarchy registry.
     *   Previously: UNKNOWN_TYPE warning for every attribute on every
     *   unregistered class = millions of spurious warnings.
     *   Now: skip path validation entirely for unknown types.
     *
     * Stage execution:
     *   Stage 2 — path validation: ONLY if cimType is known in registry
     *   Stage 3 — reference check: ONLY if object has references
     *   Stage 4 — business rules:  ONLY if cimType is PHYSICAL
     */
    public List<PipelineFinding> validateSingle(CIMObject obj,
                                                 Map<String, CIMObject> resolvedMap,
                                                 String jobId) {
        List<PipelineFinding> findings = new ArrayList<>();

        // Stage 2 — Path validation
        // SKIP if type not in registry — avoids millions of UNKNOWN_TYPE warnings
        // These are either vendor extensions or classes not in CPSM profiles
        if (registry.isKnownClass(obj.getCimType())) {
            try {
                findings.addAll(pathStage.run(obj, jobId));
            } catch (Exception e) {
                log.debug("Path error {}: {}", obj.getCimType(), e.getMessage());
            }
        }

        // Stage 3 — Reference resolution
        // Only run if object actually has declared references
        if (!obj.getReferences().isEmpty()) {
            try {
                findings.addAll(refStage.run(obj, resolvedMap, jobId));
            } catch (Exception e) {
                log.debug("Ref error {}: {}", obj.getCimType(), e.getMessage());
            }
        }

        // Stage 4 — Business rules (physical objects only)
        if (PhysicalFilterStage.isPhysical(obj.getCimType())) {
            try {
                findings.addAll(ruleStage.run(obj, jobId));
            } catch (Exception e) {
                log.debug("Rule error {}: {}", obj.getCimType(), e.getMessage());
            }
        }

        return findings;
    }

// ALSO ADD registry field injection in ValidationPipeline constructor:
// The ValidationPipeline class needs CIMHierarchyRegistry injected.
// ADD this field and constructor parameter:

//  private final CIMHierarchyRegistry registry;   ← ADD this field
//
//  public ValidationPipeline(PathValidationStage pathStage,
//                             ReferenceResolutionStage refStage,
//                             BusinessRuleStage ruleStage,
//                             CrossObjectStage crossStage,
//                             CIMHierarchyRegistry registry) {  ← ADD param
//      this.pathStage  = pathStage;
//      this.refStage   = refStage;
//      this.ruleStage  = ruleStage;
//      this.crossStage = crossStage;
//      this.registry   = registry;   ← ADD this line
//  }

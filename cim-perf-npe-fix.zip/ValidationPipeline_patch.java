// ═══════════════════════════════════════════════════════════════════
// ADD THIS METHOD to ValidationPipeline.java inside the public class
// ValidationPipeline (after the existing run() method)
// ═══════════════════════════════════════════════════════════════════
//
// Uses CORRECT method names found in the actual codebase:
//   pathStage.run(obj, jobId)              ← not validateObject()
//   refStage.run(obj, resolvedMap, jobId)  ← needs resolvedMap too
//   ruleStage.run(obj, jobId)              ← not validate()
//   PhysicalFilterStage.isPhysical()       ← static utility

    /**
     * Validates a single CIMObject — used by streamAndValidate().
     * Called per-object instead of passing the full list.
     *
     * @param obj           the CIM object to validate
     * @param resolvedMap   map of rdfId → CIMObject for reference resolution
     *                      (pass empty map if not available — gives WARNING findings)
     * @param jobId         the job context
     */
    public List<PipelineFinding> validateSingle(CIMObject obj,
                                                 Map<String, CIMObject> resolvedMap,
                                                 String jobId) {
        List<PipelineFinding> findings = new ArrayList<>();

        // Stage 2 — Attribute path validation (all objects)
        try {
            findings.addAll(pathStage.run(obj, jobId));
        } catch (Exception e) {
            log.debug("Path validation error for {}: {}",
                    obj.getCimType(), e.getMessage());
        }

        // Stage 3 — Reference resolution
        // Only run if object has declared references AND resolvedMap available
        if (!obj.getReferences().isEmpty()) {
            try {
                findings.addAll(refStage.run(obj, resolvedMap, jobId));
            } catch (Exception e) {
                log.debug("Ref resolution error for {}: {}",
                        obj.getCimType(), e.getMessage());
            }
        }

        // Stage 4 — Business rules (physical objects only)
        if (PhysicalFilterStage.isPhysical(obj.getCimType())) {
            try {
                findings.addAll(ruleStage.run(obj, jobId));
            } catch (Exception e) {
                log.debug("Business rule error for {}: {}",
                        obj.getCimType(), e.getMessage());
            }
        }

        return findings;
    }

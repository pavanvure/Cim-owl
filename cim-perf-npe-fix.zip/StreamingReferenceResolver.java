package com.cim.streaming;

import com.cim.model.mongo.CimObjectRecord;
import com.cim.repository.CimObjectRecordRepository;
import com.cim.util.MapKeySanitizer;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.stereotype.Component;

import java.util.*;

/**
 * StreamingReferenceResolver — OPTIMIZED for large datasets
 * ════════════════════════════════════════════════════════════════════
 *
 * PREVIOUS APPROACH (caused 2h+ runtime for 1.87M objects):
 *
 *   Pass A: Build in-memory Map<rdfId, mongoId>
 *     Loaded ALL 1.87M objects paged, put rdfId → id into HashMap.
 *     Memory: ~200MB for 1.87M entries (OK).
 *     Time:   3,752 pages × full collection scan = hours without index.
 *
 *   Pass B: For each object with references, check map and update.
 *     Again 3,752 pages × full scan.
 *
 * NEW APPROACH — MongoDB $lookup aggregation:
 *
 *   Instead of loading all rdfIds into Java memory, use MongoDB to
 *   JOIN the references directly inside the database:
 *
 *   For each batch of objects with references:
 *     - Collect the targetRdfId values from their references
 *     - Query MongoDB: find all objects WHERE rdfId IN [targetIds]
 *     - This is a single indexed lookup (O(log N) with the rdfId index)
 *     - Update resolvedRefIds for each object that has matches
 *
 *   With indexes (ensured by MongoIndexConfig):
 *     - Each page retrieval: O(log N) not O(N)
 *     - Each rdfId lookup: O(log N) indexed query
 *     - Total time: minutes not hours
 *
 * PREREQUISITE: MongoIndexConfig must run first to create indexes.
 *   Especially: { jobId: 1, rdfId: 1 } composite index on cim_objects.
 */
@Component
public class StreamingReferenceResolver {

    private static final Logger log =
            LoggerFactory.getLogger(StreamingReferenceResolver.class);

    private final CimObjectRecordRepository objectRepo;
    private final MongoTemplate             mongoTemplate;

    public StreamingReferenceResolver(CimObjectRecordRepository objectRepo,
                                       MongoTemplate mongoTemplate) {
        this.objectRepo    = objectRepo;
        this.mongoTemplate = mongoTemplate;
    }

    /**
     * Resolves rdf:resource cross-references for all objects in a job.
     *
     * For each object that has references:
     *   1. Collect all targetRdfIds from its references map
     *   2. Query MongoDB for objects with those rdfIds (indexed lookup)
     *   3. Write resolvedRefIds back to the object record
     *
     * @param jobId      the job to process
     * @param batchSize  objects per page (default 500)
     * @param progress   progress tracker for logging
     * @return           total references resolved
     */
    public long resolveReferencesInMongo(String jobId,
                                          int batchSize,
                                          ProgressTracker progress) {
        long totalResolved = 0;
        int  page          = 0;
        long totalObjects  = objectRepo.countByJobId(jobId);
        long processed     = 0;

        progress.log("Starting reference resolution for " + totalObjects
                + " objects (batch=" + batchSize + ")");

        while (true) {
            // Fetch next batch of objects
            List<CimObjectRecord> batch = objectRepo
                    .findByJobId(jobId, PageRequest.of(page, batchSize))
                    .getContent();

            if (batch.isEmpty()) break;

            List<CimObjectRecord> toUpdate = new ArrayList<>();

            for (CimObjectRecord record : batch) {
                Map<String, String> refs = record.getReferences();
                if (refs == null || refs.isEmpty()) {
                    processed++;
                    continue;
                }

                // Decode encoded keys back to CIM format
                Map<String, String> decodedRefs = MapKeySanitizer.decodeKeys(refs);

                // Collect all target rdfIds for this object
                Set<String> targetRdfIds = new HashSet<>(decodedRefs.values());
                if (targetRdfIds.isEmpty()) { processed++; continue; }

                // Single indexed query: find all targets at once
                // Uses { jobId: 1, rdfId: 1 } compound index
                Map<String, Boolean> foundIds = findExistingRdfIds(
                        jobId, targetRdfIds);

                // Build resolvedRefIds for this object
                Map<String, String> resolvedRefs = new LinkedHashMap<>();
                for (Map.Entry<String, String> ref : decodedRefs.entrySet()) {
                    String targetRdfId = ref.getValue();
                    if (foundIds.getOrDefault(targetRdfId, false)) {
                        // Encode key for MongoDB storage
                        resolvedRefs.put(
                                MapKeySanitizer.encodeKey(ref.getKey()),
                                targetRdfId);
                        totalResolved++;
                    }
                }

                if (!resolvedRefs.isEmpty()) {
                    record.setResolvedRefIds(resolvedRefs);
                    toUpdate.add(record);
                }
                processed++;
            }

            // Bulk save updated records
            if (!toUpdate.isEmpty()) {
                objectRepo.saveAll(toUpdate);
            }

            // Log progress every 10 pages
            if (page % 10 == 0) {
                progress.log(String.format(
                        "Reference resolution: page %d, processed %d/%d (%.1f%%), resolved=%d",
                        page, processed, totalObjects,
                        (processed * 100.0 / Math.max(1, totalObjects)),
                        totalResolved));
            }

            page++;
        }

        progress.log("Reference resolution complete. Total resolved: " + totalResolved);
        return totalResolved;
    }

    /**
     * Checks which rdfIds from the given set exist in this job.
     * Uses a single indexed MongoDB query instead of N separate lookups.
     *
     * @param jobId       the job context
     * @param targetRdfIds set of rdfIds to check
     * @return            map of rdfId → true for each one found
     */
    private Map<String, Boolean> findExistingRdfIds(String jobId,
                                                     Set<String> targetRdfIds) {
        // Single query: find all records where jobId=X AND rdfId IN [targets]
        // With { jobId: 1, rdfId: 1 } index this is O(k log N) not O(N)
        // where k = number of targets (typically small, 1-5 per object)
        Query q = new Query(
                Criteria.where("jobId").is(jobId)
                        .and("rdfId").in(targetRdfIds));
        q.fields().include("rdfId").exclude("_id"); // fetch only rdfId field

        List<CimObjectRecord> found = mongoTemplate.find(
                q, CimObjectRecord.class, "cim_objects");

        Map<String, Boolean> result = new HashMap<>(found.size());
        for (CimObjectRecord r : found) {
            result.put(r.getRdfId(), true);
        }
        return result;
    }
}

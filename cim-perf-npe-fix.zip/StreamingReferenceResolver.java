package com.cim.streaming;

import com.cim.model.mongo.CimObjectRecord;
import com.cim.repository.CimObjectRecordRepository;
import com.cim.util.MapKeySanitizer;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.BulkOperations;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.data.mongodb.core.query.Update;
import org.springframework.stereotype.Component;
import org.bson.Document;

import java.util.*;

/**
 * StreamingReferenceResolver — Step 3 optimized
 * ════════════════════════════════════════════════════════════════════
 *
 * PROBLEM with previous Step 3 (from logs):
 *   Paged through ALL 1.9M objects at 500/page = 3,752 pages.
 *   Most pages had zero resolved refs and did nothing.
 *   page=200 → processed=100,500 → resolved=7,930 (only 7.9% resolved)
 *   Means ~92% of objects have no references → wasted page fetches.
 *
 * THREE IMPROVEMENTS:
 *
 *   Improvement 1 — Filter in Step 3 query:
 *     Only fetch objects WHERE references exists AND is not empty.
 *     Skip the 92% of objects with no references entirely.
 *     3,752 pages → ~300 pages (only objects with references).
 *
 *   Improvement 2 — MongoDB BulkWrite for updates:
 *     Instead of objectRepo.saveAll() which does N individual updates,
 *     use MongoTemplate.bulkOps() which sends all updates in ONE
 *     round trip to MongoDB.
 *     saveAll(500 docs) = 500 round trips
 *     bulkOps.updateOne() × 500 + execute() = 1 round trip
 *
 *   Improvement 3 — $set only resolvedRefIds field:
 *     saveAll() re-writes the entire document (attributes, references,
 *     all fields). BulkWrite $set only updates the resolvedRefIds field.
 *     Much less data written per update.
 */
@Component
public class StreamingReferenceResolver {

    private static final Logger log =
            LoggerFactory.getLogger(StreamingReferenceResolver.class);

    private static final int RDF_LOOKUP_BATCH = 500;
    private static final int WRITE_BATCH      = 500;

    private final CimObjectRecordRepository objectRepo;
    private final MongoTemplate             mongoTemplate;

    public StreamingReferenceResolver(CimObjectRecordRepository objectRepo,
                                       MongoTemplate mongoTemplate) {
        this.objectRepo    = objectRepo;
        this.mongoTemplate = mongoTemplate;
    }

    // ═══════════════════════════════════════════════════════════════════
    // MAIN
    // ═══════════════════════════════════════════════════════════════════

    public long resolveReferencesInMongo(String jobId,
                                          int batchSize,
                                          ProgressTracker progress) {
        progress.log("Reference resolution starting");
        long start = System.currentTimeMillis();

        // STEP 1: Extract all target rdfIds via aggregation (server-side)
        progress.log("Step 1: Extracting reference targets...");
        Set<String> allTargets = extractTargetRdfIds(jobId, progress);
        progress.log("Step 1 done in " + elapsed(start) + "s — "
                + allTargets.size() + " unique targets");

        if (allTargets.isEmpty()) {
            progress.log("No references found. Done.");
            return 0;
        }

        // STEP 2: Verify which targets exist (batched $in + compound index)
        progress.log("Step 2: Verifying targets (batch=" + RDF_LOOKUP_BATCH + ")...");
        Set<String> existingRdfIds = verifyExistence(jobId, allTargets, progress);
        progress.log("Step 2 done in " + elapsed(start) + "s — "
                + existingRdfIds.size() + "/" + allTargets.size() + " confirmed");

        // STEP 3: Write resolvedRefIds — ONLY objects that have references
        progress.log("Step 3: Writing resolvedRefIds (bulk, refs-only filter)...");
        long totalResolved = writeResolvedRefsBulk(
                jobId, existingRdfIds, progress);

        progress.log("Done in " + elapsed(start) + "s — "
                + totalResolved + " references resolved");
        return totalResolved;
    }

    // ═══════════════════════════════════════════════════════════════════
    // STEP 1 — Aggregation (unchanged, already fast)
    // ═══════════════════════════════════════════════════════════════════

    private Set<String> extractTargetRdfIds(String jobId,
                                              ProgressTracker progress) {
        try {
            return extractTargetRdfIdsAggregation(jobId, progress);
        } catch (Exception e) {
            log.warn("Aggregation failed ({}), using paged fallback",
                    e.getMessage());
            return extractTargetRdfIdsPaged(jobId, progress);
        }
    }

    private Set<String> extractTargetRdfIdsAggregation(
            String jobId, ProgressTracker progress) throws Exception {

        String pipelineJson = String.format(
                "{ aggregate: 'cim_objects',"
              + "  pipeline: ["
              + "    { $match: { jobId: '%s',"
              + "                references: { $exists: true },"
              + "                $expr: { $gt: [{ $size: { $objectToArray: '$references' } }, 0] }"
              + "    }},"
              + "    { $project: { _id: 0, refs: { $objectToArray: '$references' } } },"
              + "    { $unwind: '$refs' },"
              + "    { $group: { _id: '$refs.v' } }"
              + "  ],"
              + "  cursor: { batchSize: 50000 },"
              + "  allowDiskUse: true"
              + "}",
                jobId);

        Document result = mongoTemplate.getDb()
                .runCommand(Document.parse(pipelineJson));

        Set<String> targets = new HashSet<>();
        Document cursor = (Document) result.get("cursor");
        if (cursor != null) {
            @SuppressWarnings("unchecked")
            List<Document> batch = (List<Document>) cursor.get("firstBatch");
            if (batch != null) {
                for (Document doc : batch) {
                    Object id = doc.get("_id");
                    if (id != null && !id.toString().isBlank()) {
                        targets.add(id.toString());
                    }
                }
            }
        }
        progress.log("  Aggregation: " + targets.size() + " unique targets");
        return targets;
    }

    private Set<String> extractTargetRdfIdsPaged(String jobId,
                                                   ProgressTracker progress) {
        Set<String> targets = new HashSet<>();
        int page = 0;
        while (true) {
            Query q = new Query(Criteria.where("jobId").is(jobId)
                    .and("references").exists(true));
            q.fields().include("references").exclude("_id");
            q.with(PageRequest.of(page, 2000));
            List<CimObjectRecord> batch = mongoTemplate.find(
                    q, CimObjectRecord.class, "cim_objects");
            if (batch.isEmpty()) break;
            for (CimObjectRecord r : batch) {
                if (r.getReferences() != null) {
                    targets.addAll(r.getReferences().values());
                }
            }
            if (page % 100 == 0) {
                progress.log("  Fallback page " + page
                        + ", targets=" + targets.size());
            }
            page++;
        }
        return targets;
    }

    // ═══════════════════════════════════════════════════════════════════
    // STEP 2 — Verify existence (unchanged, already fast)
    // ═══════════════════════════════════════════════════════════════════

    private Set<String> verifyExistence(String jobId,
                                         Set<String> targetRdfIds,
                                         ProgressTracker progress) {
        Set<String> existing = new HashSet<>();
        List<String> targetList = new ArrayList<>(targetRdfIds);
        int total = targetList.size();

        for (int i = 0; i < total; i += RDF_LOOKUP_BATCH) {
            int end = Math.min(i + RDF_LOOKUP_BATCH, total);
            List<String> batch = targetList.subList(i, end);

            Query q = new Query(
                    Criteria.where("jobId").is(jobId)
                            .and("rdfId").in(batch));
            q.fields().include("rdfId").exclude("_id");
            q.withHint(Document.parse("{jobId:1,rdfId:1}"));

            List<CimObjectRecord> found = mongoTemplate.find(
                    q, CimObjectRecord.class, "cim_objects");
            for (CimObjectRecord r : found) {
                if (r.getRdfId() != null) existing.add(r.getRdfId());
            }

            int batchNum = i / RDF_LOOKUP_BATCH + 1;
            if (batchNum % 50 == 0) {
                progress.log(String.format(
                        "  Verify: %d/%d batches, %d found",
                        batchNum,
                        (int) Math.ceil((double) total / RDF_LOOKUP_BATCH),
                        existing.size()));
            }
        }
        return existing;
    }

    // ═══════════════════════════════════════════════════════════════════
    // STEP 3 — OPTIMIZED: filter + bulk write
    // ═══════════════════════════════════════════════════════════════════

    /**
     * OPTIMIZATION 1 — Filter query: only fetch objects WITH references.
     *   Previous: page through ALL 1.9M objects (3,752 pages)
     *   Now:      page through only objects WHERE references != empty
     *             If 8% have refs → ~300 pages instead of 3,752
     *
     * OPTIMIZATION 2 — MongoDB BulkWrite:
     *   Previous: objectRepo.saveAll(batch) → rewrites entire document
     *             N individual writes per batch
     *   Now:      bulkOps.updateOne($set: {resolvedRefIds: ...})
     *             Only updates the resolvedRefIds field
     *             All updates in ONE MongoDB round trip per batch
     *
     * OPTIMIZATION 3 — $set only changed field:
     *   saveAll() writes all fields: rdfId, mrid, cimType, attributes,
     *             references, resolvedRefIds, sourceFormat... everything
     *   $set      writes ONLY resolvedRefIds → much less data over wire
     */
    private long writeResolvedRefsBulk(String jobId,
                                        Set<String> existingRdfIds,
                                        ProgressTracker progress) {
        long totalResolved = 0;
        long processed     = 0;
        int  page          = 0;

        // Count only objects with references (for accurate progress reporting)
        long totalWithRefs = mongoTemplate.count(
                new Query(Criteria.where("jobId").is(jobId)
                        .and("references").exists(true)
                        .and("references").ne(new Document())),
                "cim_objects");
        progress.log("  Objects with references: " + totalWithRefs
                + " (skipping " + (1876058 - totalWithRefs) + " empty)");

        while (true) {
            // ── OPTIMIZATION 1: fetch ONLY objects with references ─────
            Query q = new Query(
                    Criteria.where("jobId").is(jobId)
                            .and("references").exists(true)
                            .and("references").ne(new Document()));
            q.with(PageRequest.of(page, WRITE_BATCH));

            List<CimObjectRecord> batch = mongoTemplate.find(
                    q, CimObjectRecord.class, "cim_objects");
            if (batch.isEmpty()) break;

            // ── OPTIMIZATION 2: prepare bulk write operations ──────────
            BulkOperations bulkOps = mongoTemplate.bulkOps(
                    BulkOperations.BulkMode.UNORDERED, "cim_objects");
            int updatesInBatch = 0;

            for (CimObjectRecord record : batch) {
                Map<String, String> refs = record.getReferences();
                if (refs == null || refs.isEmpty()) { processed++; continue; }

                Map<String, String> decoded  = MapKeySanitizer.decodeKeys(refs);
                Map<String, String> resolved = new LinkedHashMap<>();

                for (Map.Entry<String, String> e : decoded.entrySet()) {
                    if (existingRdfIds.contains(e.getValue())) {
                        resolved.put(
                                MapKeySanitizer.encodeKey(e.getKey()),
                                e.getValue());
                        totalResolved++;
                    }
                }

                if (!resolved.isEmpty()) {
                    // ── OPTIMIZATION 3: $set ONLY resolvedRefIds ──────
                    Query matchById = new Query(
                            Criteria.where("_id").is(record.getId()));
                    Update update = new Update()
                            .set("resolvedRefIds", resolved);
                    bulkOps.updateOne(matchById, update);
                    updatesInBatch++;
                }
                processed++;
            }

            // Execute all updates in ONE MongoDB round trip
            if (updatesInBatch > 0) {
                bulkOps.execute();
            }

            if (page % 20 == 0) {
                progress.log(String.format(
                        "  Write back: page=%d processed=%d/%d (%.1f%%) resolved=%d",
                        page, processed, totalWithRefs,
                        (processed * 100.0 / Math.max(1, totalWithRefs)),
                        totalResolved));
            }
            page++;
        }
        return totalResolved;
    }

    // ── Helper ─────────────────────────────────────────────────────────

    private long elapsed(long startMs) {
        return (System.currentTimeMillis() - startMs) / 1000;
    }
}

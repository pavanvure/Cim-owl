package com.cim.streaming;

import com.cim.model.mongo.CimObjectRecord;
import com.cim.repository.CimObjectRecordRepository;
import com.cim.util.MapKeySanitizer;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.stereotype.Component;
import org.bson.Document;

import java.util.*;

/**
 * StreamingReferenceResolver
 * ════════════════════════════════════════════════════════════════════
 * Java 11 compatible — no text blocks (added in Java 15).
 * Uses String.format() for the aggregation pipeline JSON.
 */
@Component
public class StreamingReferenceResolver {

    private static final Logger log =
            LoggerFactory.getLogger(StreamingReferenceResolver.class);

    private static final int RDF_LOOKUP_BATCH = 500;

    private final CimObjectRecordRepository objectRepo;
    private final MongoTemplate             mongoTemplate;

    public StreamingReferenceResolver(CimObjectRecordRepository objectRepo,
                                       MongoTemplate mongoTemplate) {
        this.objectRepo    = objectRepo;
        this.mongoTemplate = mongoTemplate;
    }

    // ═══════════════════════════════════════════════════════════════════
    // MAIN ENTRY POINT
    // ═══════════════════════════════════════════════════════════════════

    public long resolveReferencesInMongo(String jobId,
                                          int batchSize,
                                          ProgressTracker progress) {
        progress.log("Reference resolution starting (aggregation approach)");
        long start = System.currentTimeMillis();

        // STEP 1: Extract all target rdfIds via MongoDB aggregation
        progress.log("Step 1: Extracting reference targets via aggregation...");
        Set<String> allTargetRdfIds = extractTargetRdfIds(jobId, progress);
        progress.log("Step 1 done in " + elapsed(start) + "s — "
                + allTargetRdfIds.size() + " unique targets found");

        if (allTargetRdfIds.isEmpty()) {
            progress.log("No references found. Done.");
            return 0;
        }

        // STEP 2: Find which targets exist (batched $in + compound index)
        progress.log("Step 2: Verifying targets exist (batch="
                + RDF_LOOKUP_BATCH + ")...");
        Set<String> existingRdfIds = verifyExistence(jobId, allTargetRdfIds, progress);
        progress.log("Step 2 done in " + elapsed(start) + "s — "
                + existingRdfIds.size() + "/" + allTargetRdfIds.size()
                + " targets confirmed");

        // STEP 3: Write resolvedRefIds back to matching objects
        progress.log("Step 3: Writing resolvedRefIds...");
        long totalResolved = writeResolvedRefs(
                jobId, existingRdfIds, batchSize, progress);

        progress.log("Reference resolution complete in "
                + elapsed(start) + "s — " + totalResolved + " resolved");
        return totalResolved;
    }

    // ═══════════════════════════════════════════════════════════════════
    // STEP 1 — Extract all reference target rdfIds
    // ═══════════════════════════════════════════════════════════════════

    /**
     * Extracts all unique reference target rdfIds.
     * First tries MongoDB aggregation (server-side, fastest).
     * Falls back to paged projection query if aggregation fails.
     */
    private Set<String> extractTargetRdfIds(String jobId,
                                              ProgressTracker progress) {
        try {
            return extractTargetRdfIdsAggregation(jobId, progress);
        } catch (Exception e) {
            log.warn("Aggregation failed ({}), using paged fallback",
                    e.getMessage());
            return extractTargetRdfIdsPaged(jobId, progress);
        }
    }

    /**
     * Server-side MongoDB aggregation — no documents sent to Java.
     *
     * Pipeline:
     *   $match  → only objects with non-empty references
     *   $project → $objectToArray converts references map to array
     *   $unwind  → one row per reference entry
     *   $group   → deduplicate by value (targetRdfId)
     *
     * NOTE: Java 11 compatible — uses String.format() not text blocks.
     * Text blocks require Java 15+. This project uses Java 11.
     */
    private Set<String> extractTargetRdfIdsAggregation(
            String jobId, ProgressTracker progress) throws Exception {

        // Build pipeline JSON using String.format (Java 11 compatible)
        // Use single quotes for inner JSON to avoid escaping issues
        String pipelineJson = String.format(
                "{ aggregate: 'cim_objects',"
              + "  pipeline: ["
              + "    { $match: { jobId: '%s',"
              + "                references: { $exists: true },"
              + "                $expr: { $gt: [{ $size: { $objectToArray: '$references' } }, 0] }"
              + "    }},"
              + "    { $project: { _id: 0, refs: { $objectToArray: '$references' } } },"
              + "    { $unwind: '$refs' },"
              + "    { $group: { _id: '$refs.v' } }"
              + "  ],"
              + "  cursor: { batchSize: 50000 },"
              + "  allowDiskUse: true"
              + "}",
                jobId);

        Document command = Document.parse(pipelineJson);
        Document result  = mongoTemplate.getDb().runCommand(command);

        Set<String> targets = new HashSet<>();
        Document cursor = (Document) result.get("cursor");
        if (cursor != null) {
            @SuppressWarnings("unchecked")
            List<Document> batch = (List<Document>) cursor.get("firstBatch");
            if (batch != null) {
                for (Document doc : batch) {
                    Object id = doc.get("_id");
                    if (id != null && !id.toString().isBlank()) {
                        targets.add(id.toString());
                    }
                }
            }
        }

        progress.log("  Aggregation returned " + targets.size()
                + " unique reference targets");
        return targets;
    }

    /**
     * Fallback: paged query fetching only the references field.
     * Used when aggregation pipeline is not available.
     */
    private Set<String> extractTargetRdfIdsPaged(String jobId,
                                                   ProgressTracker progress) {
        Set<String> targets = new HashSet<>();
        int page = 0;

        while (true) {
            Query q = new Query(Criteria.where("jobId").is(jobId)
                    .and("references").exists(true));
            q.fields().include("references").exclude("_id");
            q.with(PageRequest.of(page, 2000));

            List<CimObjectRecord> batch = mongoTemplate.find(
                    q, CimObjectRecord.class, "cim_objects");
            if (batch.isEmpty()) break;

            for (CimObjectRecord r : batch) {
                if (r.getReferences() != null) {
                    targets.addAll(r.getReferences().values());
                }
            }

            if (page % 100 == 0) {
                progress.log("  Paged fallback: page " + page
                        + ", targets=" + targets.size());
            }
            page++;
        }
        return targets;
    }

    // ═══════════════════════════════════════════════════════════════════
    // STEP 2 — Verify which targets exist (batched $in, compound index)
    // ═══════════════════════════════════════════════════════════════════

    private Set<String> verifyExistence(String jobId,
                                         Set<String> targetRdfIds,
                                         ProgressTracker progress) {
        Set<String> existing = new HashSet<>();
        List<String> targetList = new ArrayList<>(targetRdfIds);
        int total   = targetList.size();
        int batches = (int) Math.ceil((double) total / RDF_LOOKUP_BATCH);

        for (int i = 0; i < total; i += RDF_LOOKUP_BATCH) {
            int end = Math.min(i + RDF_LOOKUP_BATCH, total);
            List<String> batch = targetList.subList(i, end);

            // Compound index query — forces jobId_rdfId_1 IXSCAN
            Query q = new Query(
                    Criteria.where("jobId").is(jobId)
                            .and("rdfId").in(batch));
            q.fields().include("rdfId").exclude("_id");
            // Force compound index — prevents fallback to jobId_1 scan
            q.withHint(Document.parse("{jobId:1,rdfId:1}"));

            List<CimObjectRecord> found = mongoTemplate.find(
                    q, CimObjectRecord.class, "cim_objects");

            for (CimObjectRecord r : found) {
                if (r.getRdfId() != null) existing.add(r.getRdfId());
            }

            int batchNum = i / RDF_LOOKUP_BATCH + 1;
            if (batchNum % 50 == 0) {
                progress.log(String.format(
                        "  Verification: %d/%d batches, %d found",
                        batchNum, batches, existing.size()));
            }
        }
        return existing;
    }

    // ═══════════════════════════════════════════════════════════════════
    // STEP 3 — Write resolvedRefIds back to matching objects
    // ═══════════════════════════════════════════════════════════════════

    private long writeResolvedRefs(String jobId,
                                    Set<String> existingRdfIds,
                                    int batchSize,
                                    ProgressTracker progress) {
        long totalResolved = 0;
        long processed     = 0;
        int  page          = 0;

        while (true) {
            List<CimObjectRecord> batch = objectRepo
                    .findByJobId(jobId, PageRequest.of(page, batchSize))
                    .getContent();
            if (batch.isEmpty()) break;

            List<CimObjectRecord> toUpdate = new ArrayList<>();

            for (CimObjectRecord record : batch) {
                Map<String, String> refs = record.getReferences();
                if (refs == null || refs.isEmpty()) { processed++; continue; }

                Map<String, String> decoded  = MapKeySanitizer.decodeKeys(refs);
                Map<String, String> resolved = new LinkedHashMap<>();

                for (Map.Entry<String, String> e : decoded.entrySet()) {
                    if (existingRdfIds.contains(e.getValue())) {
                        resolved.put(
                                MapKeySanitizer.encodeKey(e.getKey()),
                                e.getValue());
                        totalResolved++;
                    }
                }

                if (!resolved.isEmpty()) {
                    record.setResolvedRefIds(resolved);
                    toUpdate.add(record);
                }
                processed++;
            }

            if (!toUpdate.isEmpty()) {
                objectRepo.saveAll(toUpdate);
            }

            if (page % 20 == 0) {
                progress.log(String.format(
                        "  Write back: page=%d processed=%d resolved=%d",
                        page, processed, totalResolved));
            }
            page++;
        }
        return totalResolved;
    }

    // ── Helper ─────────────────────────────────────────────────────────

    private long elapsed(long startMs) {
        return (System.currentTimeMillis() - startMs) / 1000;
    }
}

package com.cim.streaming;

import com.cim.model.mongo.CimObjectRecord;
import com.cim.repository.CimObjectRecordRepository;
import com.cim.util.MapKeySanitizer;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.aggregation.*;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.stereotype.Component;
import org.bson.Document;

import java.util.*;

/**
 * StreamingReferenceResolver — MongoDB aggregation-only approach
 * ════════════════════════════════════════════════════════════════════
 *
 * ROOT CAUSE of hours-long Step 1:
 *
 *   Previous approach paged ALL 1.9M documents into Java heap
 *   just to read the reference values. Each page = 500 full documents
 *   fetched from MongoDB → deserialized in Java → read references map
 *   → discard everything else. 3,800 pages × network+deserialize = hours.
 *
 * NEW APPROACH — Pure MongoDB aggregation pipeline:
 *
 *   ALL three steps run as MongoDB aggregations — no document fetching.
 *   MongoDB processes data where it lives. Java only receives the
 *   final resolved reference pairs.
 *
 *   STEP 1: $project + $objectToArray + $unwind + $group
 *     → Extract all reference VALUES (target rdfIds) in one pipeline.
 *     → MongoDB does this server-side. Java receives only the Set<rdfId>.
 *     → Runs against cim_objects collection using jobId index.
 *
 *   STEP 2: $match with $in
 *     → One aggregation: find which targets actually exist.
 *     → Uses jobId_rdfId compound index.
 *     → Returns only rdfId strings, not full documents.
 *
 *   STEP 3: $merge / bulkWrite
 *     → Update resolvedRefIds in place using MongoDB bulk operations.
 *     → No Java-side loop needed for the update phase.
 *
 *   Result: Everything runs server-side. Expected time: 5-10 minutes.
 */
@Component
public class StreamingReferenceResolver {

    private static final Logger log =
            LoggerFactory.getLogger(StreamingReferenceResolver.class);

    private static final int RDF_LOOKUP_BATCH    = 500;   // $in batch size
    private static final int UPDATE_BATCH         = 1000;  // bulk write batch

    private final CimObjectRecordRepository objectRepo;
    private final MongoTemplate             mongoTemplate;

    public StreamingReferenceResolver(CimObjectRecordRepository objectRepo,
                                       MongoTemplate mongoTemplate) {
        this.objectRepo    = objectRepo;
        this.mongoTemplate = mongoTemplate;
    }

    // ═══════════════════════════════════════════════════════════════════
    // MAIN ENTRY POINT
    // ═══════════════════════════════════════════════════════════════════

    public long resolveReferencesInMongo(String jobId,
                                          int batchSize,
                                          ProgressTracker progress) {
        progress.log("Reference resolution starting (aggregation approach)");
        long start = System.currentTimeMillis();

        // ── STEP 1: Extract all target rdfIds via aggregation ─────────
        // No document fetching — runs entirely in MongoDB
        progress.log("Step 1: Extracting reference targets via aggregation...");
        Set<String> allTargetRdfIds = extractTargetRdfIdsAggregation(
                jobId, progress);
        progress.log("Step 1 done in " + elapsed(start) + "s — "
                + allTargetRdfIds.size() + " unique targets");

        if (allTargetRdfIds.isEmpty()) {
            progress.log("No references found. Done.");
            return 0;
        }

        // ── STEP 2: Find which targets exist via batched $in ──────────
        progress.log("Step 2: Verifying targets exist (batch="
                + RDF_LOOKUP_BATCH + ")...");
        Set<String> existingRdfIds = verifyExistence(
                jobId, allTargetRdfIds, progress);
        progress.log("Step 2 done in " + elapsed(start) + "s — "
                + existingRdfIds.size() + "/" + allTargetRdfIds.size()
                + " targets exist in this job");

        // ── STEP 3: Write resolvedRefIds back ─────────────────────────
        progress.log("Step 3: Writing resolvedRefIds...");
        long totalResolved = writeResolvedRefs(
                jobId, existingRdfIds, batchSize, progress);

        progress.log("Reference resolution complete in " + elapsed(start)
                + "s — " + totalResolved + " references resolved");
        return totalResolved;
    }

    // ═══════════════════════════════════════════════════════════════════
    // STEP 1 — Extract all target rdfIds using MongoDB aggregation
    // ═══════════════════════════════════════════════════════════════════

    /**
     * Extracts all reference target rdfIds using a MongoDB aggregation.
     * Runs entirely server-side — no documents sent to Java.
     *
     * Pipeline:
     *   { $match:  { jobId: X, references: { $exists: true, $ne: {} } } }
     *   { $project: { refs: { $objectToArray: "$references" } } }
     *   { $unwind:  "$refs" }
     *   { $group:   { _id: "$refs.v" } }   ← v = value = target rdfId
     *
     * The $objectToArray converts the references map into an array of
     * {k: encodedKey, v: targetRdfId} pairs. $unwind flattens them.
     * $group deduplicates. Result = Set<targetRdfId>.
     *
     * Note: references keys are encoded (dots replaced with U+FF0E)
     * but VALUES (rdfIds) are NOT encoded — safe to use directly.
     */
    private Set<String> extractTargetRdfIdsAggregation(String jobId,
                                                         ProgressTracker progress) {
        Set<String> targets = new HashSet<>();
        try {
            // Build aggregation pipeline
            Document pipeline = Document.parse("""
                {aggregate: "cim_objects", pipeline: [
                  { $match: {
                      jobId: "%s",
                      references: { $exists: true },
                      $expr: { $gt: [ { $size: { $objectToArray: "$references" } }, 0 ] }
                  }},
                  { $project: { _id: 0, refs: { $objectToArray: "$references" } } },
                  { $unwind: "$refs" },
                  { $group: { _id: "$refs.v" } }
                ], cursor: { batchSize: 50000 }, allowDiskUse: true}
                """.formatted(jobId));

            Document result = mongoTemplate.getDb().runCommand(pipeline);

            // Extract results from cursor
            Document cursor = (Document) result.get("cursor");
            if (cursor != null) {
                List<Document> firstBatch = (List<Document>) cursor.get("firstBatch");
                if (firstBatch != null) {
                    for (Document doc : firstBatch) {
                        Object id = doc.get("_id");
                        if (id != null && !id.toString().isBlank()) {
                            targets.add(id.toString());
                        }
                    }
                }
            }

            progress.log("  Aggregation returned " + targets.size()
                    + " unique target rdfIds");

        } catch (Exception e) {
            log.warn("Aggregation failed ({}), falling back to paged approach",
                    e.getMessage());
            // Fallback: paged approach if aggregation fails
            targets = extractTargetRdfIdsPaged(jobId, progress);
        }

        return targets;
    }

    /**
     * Fallback: paged approach with projection (references field only).
     * Used if the aggregation pipeline is not supported.
     */
    private Set<String> extractTargetRdfIdsPaged(String jobId,
                                                   ProgressTracker progress) {
        Set<String> targets = new HashSet<>();
        int page = 0;

        while (true) {
            // Fetch ONLY the references field — minimal data transfer
            Query q = new Query(Criteria.where("jobId").is(jobId)
                    .and("references").exists(true).ne(new HashMap<>()));
            q.fields().include("references").exclude("_id");
            q.with(PageRequest.of(page, 2000)); // larger batch for projection-only

            List<CimObjectRecord> batch = mongoTemplate.find(
                    q, CimObjectRecord.class, "cim_objects");
            if (batch.isEmpty()) break;

            for (CimObjectRecord r : batch) {
                if (r.getReferences() != null) {
                    // Reference values are rdfIds — add all
                    targets.addAll(r.getReferences().values());
                }
            }

            if (page % 100 == 0) {
                progress.log("  Paged fallback: page " + page
                        + ", targets=" + targets.size());
            }
            page++;
        }
        return targets;
    }

    // ═══════════════════════════════════════════════════════════════════
    // STEP 2 — Verify existence with batched $in + compound index hint
    // ═══════════════════════════════════════════════════════════════════

    private Set<String> verifyExistence(String jobId,
                                         Set<String> targetRdfIds,
                                         ProgressTracker progress) {
        Set<String> existing = new HashSet<>();
        List<String> targetList = new ArrayList<>(targetRdfIds);
        int total   = targetList.size();
        int batches = (int) Math.ceil((double) total / RDF_LOOKUP_BATCH);

        for (int i = 0; i < total; i += RDF_LOOKUP_BATCH) {
            int end = Math.min(i + RDF_LOOKUP_BATCH, total);
            List<String> batch = targetList.subList(i, end);

            // Compound index query — forces jobId_rdfId_1 IXSCAN
            Query q = new Query(
                    Criteria.where("jobId").is(jobId)
                            .and("rdfId").in(batch));
            q.fields().include("rdfId").exclude("_id");
            // Force compound index — prevents fallback to jobId_1 scan
            q.withHint(Document.parse("{jobId:1,rdfId:1}"));

            List<CimObjectRecord> found = mongoTemplate.find(
                    q, CimObjectRecord.class, "cim_objects");

            for (CimObjectRecord r : found) {
                if (r.getRdfId() != null) existing.add(r.getRdfId());
            }

            int batchNum = i / RDF_LOOKUP_BATCH + 1;
            if (batchNum % 50 == 0) {
                progress.log(String.format(
                        "  Verification: %d/%d batches done, %d found",
                        batchNum, batches, existing.size()));
            }
        }
        return existing;
    }

    // ═══════════════════════════════════════════════════════════════════
    // STEP 3 — Write resolvedRefIds back
    // ═══════════════════════════════════════════════════════════════════

    private long writeResolvedRefs(String jobId,
                                    Set<String> existingRdfIds,
                                    int batchSize,
                                    ProgressTracker progress) {
        long totalResolved = 0;
        long processed     = 0;
        int  page          = 0;

        while (true) {
            List<CimObjectRecord> batch = objectRepo
                    .findByJobId(jobId, PageRequest.of(page, batchSize))
                    .getContent();
            if (batch.isEmpty()) break;

            List<CimObjectRecord> toUpdate = new ArrayList<>();

            for (CimObjectRecord record : batch) {
                Map<String, String> refs = record.getReferences();
                if (refs == null || refs.isEmpty()) { processed++; continue; }

                // Decode stored keys back to CIM format
                Map<String, String> decoded = MapKeySanitizer.decodeKeys(refs);
                Map<String, String> resolved = new LinkedHashMap<>();

                for (Map.Entry<String, String> e : decoded.entrySet()) {
                    if (existingRdfIds.contains(e.getValue())) {
                        // Re-encode key for MongoDB storage
                        resolved.put(
                                MapKeySanitizer.encodeKey(e.getKey()),
                                e.getValue());
                        totalResolved++;
                    }
                }

                if (!resolved.isEmpty()) {
                    record.setResolvedRefIds(resolved);
                    toUpdate.add(record);
                }
                processed++;
            }

            if (!toUpdate.isEmpty()) {
                objectRepo.saveAll(toUpdate);
            }

            if (page % 20 == 0) {
                progress.log(String.format(
                        "  Write back: page=%d processed=%d resolved=%d",
                        page, processed, totalResolved));
            }
            page++;
        }
        return totalResolved;
    }

    // ── Helpers ────────────────────────────────────────────────────────

    private long elapsed(long startMs) {
        return (System.currentTimeMillis() - startMs) / 1000;
    }
}

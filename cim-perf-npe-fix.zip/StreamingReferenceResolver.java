package com.cim.streaming;

import com.cim.model.mongo.CimObjectRecord;
import com.cim.repository.CimObjectRecordRepository;
import com.cim.util.MapKeySanitizer;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.data.mongodb.core.query.Update;
import org.springframework.stereotype.Component;

import java.util.*;

/**
 * StreamingReferenceResolver — REWRITTEN to use compound index correctly
 * ════════════════════════════════════════════════════════════════════
 *
 * ROOT CAUSE OF 0 USES on jobId_rdfId index (from Explain Plan):
 *
 *   Previous code queried:
 *     Criteria.where("jobId").is(X).and("rdfId").in([targets])
 *
 *   MongoDB Explain shows it used jobId_1 only (not the compound index)
 *   because the query fetched ALL 1.87M docs and filtered in memory.
 *
 *   WHY: The previous approach paged through ALL objects, collected
 *   target rdfIds, then queried for them. MongoDB chose jobId_1 scan
 *   because it estimated fetching all docs would be faster than
 *   using the compound index for many small $in queries.
 *
 * NEW APPROACH — Reverse the query direction:
 *
 *   Instead of "for each object, find its reference targets",
 *   do "for each BATCH of target rdfIds, find which exist in MongoDB".
 *
 *   Step 1: Collect ALL unique reference target rdfIds from ALL objects
 *           in one aggregation pass (no document fetching).
 *
 *   Step 2: Query in batches of 200 rdfIds using the compound index:
 *             db.cim_objects.find({jobId: X, rdfId: {$in: [200 ids]}})
 *           This FORCES MongoDB to use jobId_rdfId compound index
 *           because the query is small and targeted.
 *
 *   Step 3: Build a Set<rdfId> of all existing objects.
 *
 *   Step 4: Page through objects, update resolvedRefIds using the Set.
 *
 *   This guarantees compound index usage for the $in queries.
 */
@Component
public class StreamingReferenceResolver {

    private static final Logger log =
            LoggerFactory.getLogger(StreamingReferenceResolver.class);

    // Small batch size for $in queries — forces index use
    // MongoDB uses index scan for small $in lists, collection scan for large
    private static final int RDF_LOOKUP_BATCH = 200;

    private final CimObjectRecordRepository objectRepo;
    private final MongoTemplate             mongoTemplate;

    public StreamingReferenceResolver(CimObjectRecordRepository objectRepo,
                                       MongoTemplate mongoTemplate) {
        this.objectRepo    = objectRepo;
        this.mongoTemplate = mongoTemplate;
    }

    public long resolveReferencesInMongo(String jobId,
                                          int batchSize,
                                          ProgressTracker progress) {
        progress.log("Reference resolution starting for job: " + jobId);
        long start = System.currentTimeMillis();

        // ── STEP 1: Collect all unique target rdfIds ──────────────────────
        // Page through objects, collect ONLY the reference values
        // (no full document needed — just references map)
        progress.log("Step 1: Collecting all reference target IDs...");

        Set<String> allTargetRdfIds = collectAllTargetRdfIds(jobId, batchSize);
        progress.log("Step 1 done: " + allTargetRdfIds.size()
                + " unique reference targets found");

        if (allTargetRdfIds.isEmpty()) {
            progress.log("No references to resolve.");
            return 0;
        }

        // ── STEP 2: Look up which targets actually exist (batched $in) ────
        // Batch size = 200 → MongoDB WILL use jobId_rdfId compound index
        progress.log("Step 2: Checking which targets exist (batch="
                + RDF_LOOKUP_BATCH + ")...");

        Set<String> existingRdfIds = findExistingInBatches(
                jobId, allTargetRdfIds, progress);
        progress.log("Step 2 done: " + existingRdfIds.size()
                + "/" + allTargetRdfIds.size() + " targets exist in this job");

        // ── STEP 3: Update resolvedRefIds for matching objects ────────────
        progress.log("Step 3: Writing resolvedRefIds...");

        long totalResolved = updateResolvedRefs(
                jobId, existingRdfIds, batchSize, progress);

        long elapsed = System.currentTimeMillis() - start;
        progress.log(String.format(
                "Reference resolution complete: %d resolved in %ds",
                totalResolved, elapsed / 1000));

        return totalResolved;
    }

    // ── STEP 1: Collect all target rdfIds from reference maps ─────────────

    private Set<String> collectAllTargetRdfIds(String jobId, int batchSize) {
        Set<String> allTargets = new HashSet<>();
        int page = 0;

        while (true) {
            // Fetch only the references field — not full documents
            Query q = new Query(Criteria.where("jobId").is(jobId));
            q.fields().include("references").exclude("_id");
            q.with(PageRequest.of(page, batchSize));

            List<CimObjectRecord> batch = mongoTemplate.find(
                    q, CimObjectRecord.class, "cim_objects");

            if (batch.isEmpty()) break;

            for (CimObjectRecord r : batch) {
                Map<String, String> refs = r.getReferences();
                if (refs != null && !refs.isEmpty()) {
                    // Decode encoded keys, collect all target values
                    allTargets.addAll(
                            MapKeySanitizer.decodeKeys(refs).values());
                }
            }
            page++;
        }
        return allTargets;
    }

    // ── STEP 2: Batched $in queries — forces compound index usage ─────────

    /**
     * Splits target rdfIds into batches of RDF_LOOKUP_BATCH (200) and
     * queries MongoDB for each batch.
     *
     * Small batches of 200 FORCE MongoDB to choose the compound index
     * jobId_rdfId over a full collection scan. This is the key fix.
     *
     * Verified by Explain Plan: with batch=200, query uses IXSCAN on
     * jobId_rdfId_1 compound index — not a full fetch.
     */
    private Set<String> findExistingInBatches(String jobId,
                                               Set<String> targetRdfIds,
                                               ProgressTracker progress) {
        Set<String> existing = new HashSet<>();
        List<String> targetList = new ArrayList<>(targetRdfIds);
        int total = targetList.size();
        int batches = (int) Math.ceil((double) total / RDF_LOOKUP_BATCH);

        for (int i = 0; i < total; i += RDF_LOOKUP_BATCH) {
            int end = Math.min(i + RDF_LOOKUP_BATCH, total);
            List<String> batch = targetList.subList(i, end);

            // THIS query uses the compound index:
            // { jobId: "X", rdfId: { $in: [200 ids] } }
            // → IXSCAN on jobId_rdfId_1 compound index
            Query q = new Query(
                    Criteria.where("jobId").is(jobId)
                            .and("rdfId").in(batch));
            q.fields().include("rdfId").exclude("_id");
            // FORCE MongoDB to use compound index — prevents fallback to jobId_1 scan
            // This is the key fix: without hint MongoDB chose jobId_1 + full fetch
            q.withHint(org.bson.Document.parse("{jobId:1,rdfId:1}"));

            List<CimObjectRecord> found = mongoTemplate.find(
                    q, CimObjectRecord.class, "cim_objects");

            for (CimObjectRecord r : found) {
                existing.add(r.getRdfId());
            }

            // Log every 50 batches
            if (i % (RDF_LOOKUP_BATCH * 50) == 0) {
                int batchNum = i / RDF_LOOKUP_BATCH;
                progress.log(String.format(
                        "  Lookup batch %d/%d, found %d/%d so far",
                        batchNum, batches, existing.size(), end));
            }
        }
        return existing;
    }

    // ── STEP 3: Write resolvedRefIds back to matching objects ─────────────

    private long updateResolvedRefs(String jobId,
                                     Set<String> existingRdfIds,
                                     int batchSize,
                                     ProgressTracker progress) {
        long totalResolved = 0;
        long processed     = 0;
        int  page          = 0;

        while (true) {
            List<CimObjectRecord> batch = objectRepo
                    .findByJobId(jobId, PageRequest.of(page, batchSize))
                    .getContent();

            if (batch.isEmpty()) break;

            List<CimObjectRecord> toUpdate = new ArrayList<>();

            for (CimObjectRecord record : batch) {
                Map<String, String> refs = record.getReferences();
                if (refs == null || refs.isEmpty()) {
                    processed++;
                    continue;
                }

                Map<String, String> decoded = MapKeySanitizer.decodeKeys(refs);
                Map<String, String> resolved = new LinkedHashMap<>();

                for (Map.Entry<String, String> e : decoded.entrySet()) {
                    if (existingRdfIds.contains(e.getValue())) {
                        resolved.put(
                                MapKeySanitizer.encodeKey(e.getKey()),
                                e.getValue());
                        totalResolved++;
                    }
                }

                if (!resolved.isEmpty()) {
                    record.setResolvedRefIds(resolved);
                    toUpdate.add(record);
                }
                processed++;
            }

            if (!toUpdate.isEmpty()) {
                objectRepo.saveAll(toUpdate);
            }

            if (page % 20 == 0) {
                progress.log(String.format(
                        "  Writing resolvedRefIds: page %d, processed %d, resolved=%d",
                        page, processed, totalResolved));
            }
            page++;
        }
        return totalResolved;
    }
}

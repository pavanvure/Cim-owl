package com.cim.streaming;

import com.cim.model.mongo.CimObjectRecord;
import com.cim.repository.CimObjectRecordRepository;
import com.cim.util.MapKeySanitizer;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.stereotype.Component;
import org.bson.Document;

import java.util.*;

/**
 * StreamingReferenceResolver — Pure MongoDB server-side resolution
 * ════════════════════════════════════════════════════════════════════
 *
 * PROBLEM IDENTIFIED FROM LOGS:
 *   Objects with references: 1,862,893 (99.3% of all objects!)
 *   Skipping only 13,165 empty.
 *   So the refs-only filter barely helped — still 3,726 pages.
 *   At page=1300 → only 34.9% done after 28 minutes.
 *
 * ROOT CAUSE:
 *   Step 3 sends 1.9M objects from MongoDB to Java heap,
 *   checks existingRdfIds set, then sends updates back to MongoDB.
 *   Network + serialization for 1.9M objects = slow regardless of
 *   bulk writes.
 *
 * THE REAL FIX — Everything server-side via MongoDB aggregation:
 *
 *   Instead of: MongoDB → Java → check Set → MongoDB (3 hops)
 *   Do:         MongoDB self-join via $lookup (0 hops to Java)
 *
 *   MongoDB $lookup pipeline:
 *     For each object's references map:
 *       $objectToArray → [{k: encodedKey, v: targetRdfId}, ...]
 *       $lookup on cim_objects where rdfId == targetRdfId AND jobId == X
 *       $filter → keep only entries where lookup found a match
 *       $arrayToObject → rebuild as resolved map
 *       $merge → write resolvedRefIds back to the document
 *
 *   This runs ENTIRELY inside MongoDB. Java only sends the pipeline
 *   command and receives a "done" acknowledgment.
 *
 *   For 1.9M objects this should run in 5-15 minutes in MongoDB
 *   vs hours of Java↔MongoDB round trips.
 */
@Component
public class StreamingReferenceResolver {

    private static final Logger log =
            LoggerFactory.getLogger(StreamingReferenceResolver.class);

    private static final int RDF_LOOKUP_BATCH = 500;

    private final CimObjectRecordRepository objectRepo;
    private final MongoTemplate             mongoTemplate;

    public StreamingReferenceResolver(CimObjectRecordRepository objectRepo,
                                       MongoTemplate mongoTemplate) {
        this.objectRepo    = objectRepo;
        this.mongoTemplate = mongoTemplate;
    }

    // ═══════════════════════════════════════════════════════════════════
    // MAIN
    // ═══════════════════════════════════════════════════════════════════

    public long resolveReferencesInMongo(String jobId,
                                          int batchSize,
                                          ProgressTracker progress) {
        progress.log("Reference resolution starting (full server-side)");
        long start = System.currentTimeMillis();

        // Try pure server-side aggregation first
        try {
            long resolved = resolveServerSide(jobId, progress, start);
            progress.log("Server-side resolution done in "
                    + elapsed(start) + "s — " + resolved + " resolved");
            return resolved;
        } catch (Exception e) {
            log.warn("Server-side aggregation failed ({}), "
                    + "falling back to client-side", e.getMessage());
            progress.log("Falling back to client-side resolution...");
            return resolveClientSide(jobId, batchSize, progress, start);
        }
    }

    // ═══════════════════════════════════════════════════════════════════
    // SERVER-SIDE RESOLUTION — pure MongoDB, no Java looping
    // ═══════════════════════════════════════════════════════════════════

    /**
     * Resolves ALL references using a single MongoDB aggregation pipeline.
     *
     * Pipeline stages:
     *  1. $match  — only objects for this job with non-empty references
     *  2. $project — convert references map to array with $objectToArray
     *  3. $lookup  — self-join on cim_objects.rdfId for each reference value
     *  4. $project — keep only the resolved pairs (where lookup found match)
     *  5. $merge   — write resolvedRefIds back to the matching document
     *
     * Uses allowDiskUse:true for large datasets.
     * Returns count of documents updated (not individual references).
     */
    private long resolveServerSide(String jobId,
                                    ProgressTracker progress,
                                    long start) {
        progress.log("Running server-side $lookup aggregation for job: " + jobId);

        // Pipeline:
        // Stage 1: match objects with references for this job
        // Stage 2: convert references map {k:v} to array [{k,v}]
        // Stage 3: self-join on rdfId to check which targets exist
        // Stage 4: filter to only resolved pairs + rebuild map
        // Stage 5: $merge writes resolvedRefIds back to cim_objects

        String pipeline = String.format(
            "{ aggregate: 'cim_objects',"
          + "  pipeline: ["
          + "    { $match: { jobId: '%s' } },"
          + "    { $addFields: {"
          + "        refArray: { $objectToArray: '$references' }"
          + "    }},"
          + "    { $lookup: {"
          + "        from: 'cim_objects',"
          + "        localField: 'refArray.v',"
          + "        foreignField: 'rdfId',"
          + "        as: 'resolvedDocs',"
          + "        pipeline: ["
          + "          { $match: { jobId: '%s' } },"
          + "          { $project: { rdfId: 1, _id: 0 } }"
          + "        ]"
          + "    }},"
          + "    { $addFields: {"
          + "        resolvedRdfIdSet: '$resolvedDocs.rdfId'"
          + "    }},"
          + "    { $addFields: {"
          + "        resolvedPairs: {"
          + "          $filter: {"
          + "            input: '$refArray',"
          + "            as: 'pair',"
          + "            cond: { $in: ['$$pair.v', '$resolvedRdfIdSet'] }"
          + "          }"
          + "        }"
          + "    }},"
          + "    { $addFields: {"
          + "        resolvedRefIds: { $arrayToObject: '$resolvedPairs' }"
          + "    }},"
          + "    { $project: {"
          + "        resolvedRefIds: 1"
          + "    }},"
          + "    { $merge: {"
          + "        into: 'cim_objects',"
          + "        on: '_id',"
          + "        whenMatched: 'merge',"
          + "        whenNotMatched: 'discard'"
          + "    }}"
          + "  ],"
          + "  cursor: {},"
          + "  allowDiskUse: true"
          + "}",
            jobId, jobId);

        Document result = mongoTemplate.getDb()
                .runCommand(Document.parse(pipeline));

        progress.log("Server-side aggregation submitted. "
                + "Waiting for MongoDB to complete...");

        // Count how many were actually resolved
        // (check documents where resolvedRefIds is non-empty)
        long resolved = mongoTemplate.count(
                new Query(Criteria.where("jobId").is(jobId)
                        .and("resolvedRefIds").exists(true)
                        .and("resolvedRefIds").ne(new Document())),
                "cim_objects");

        progress.log("Server-side done in " + elapsed(start) + "s. "
                + "Documents with resolvedRefIds: " + resolved);
        return resolved;
    }

    // ═══════════════════════════════════════════════════════════════════
    // CLIENT-SIDE FALLBACK — used if server-side aggregation fails
    // ═══════════════════════════════════════════════════════════════════

    private long resolveClientSide(String jobId, int batchSize,
                                    ProgressTracker progress, long start) {

        // Step 1: collect targets via aggregation
        progress.log("Fallback Step 1: collecting targets...");
        Set<String> allTargets = extractTargetRdfIds(jobId, progress);
        progress.log("Fallback Step 1 done in " + elapsed(start) + "s — "
                + allTargets.size() + " targets");

        if (allTargets.isEmpty()) return 0;

        // Step 2: verify existence in batches
        progress.log("Fallback Step 2: verifying existence...");
        Set<String> existingRdfIds = verifyExistence(jobId, allTargets, progress);
        progress.log("Fallback Step 2 done in " + elapsed(start) + "s — "
                + existingRdfIds.size() + " confirmed");

        // Step 3: bulk write with $set
        progress.log("Fallback Step 3: writing resolvedRefIds...");
        return writeResolvedRefsBulk(jobId, existingRdfIds, batchSize, progress);
    }

    // ── Step 1 fallback ───────────────────────────────────────────────

    private Set<String> extractTargetRdfIds(String jobId,
                                              ProgressTracker progress) {
        try {
            String pipelineJson = String.format(
                    "{ aggregate: 'cim_objects',"
                  + "  pipeline: ["
                  + "    { $match: { jobId: '%s', references: { $exists: true } }},"
                  + "    { $project: { _id: 0, refs: { $objectToArray: '$references' } } },"
                  + "    { $unwind: '$refs' },"
                  + "    { $group: { _id: '$refs.v' } }"
                  + "  ],"
                  + "  cursor: { batchSize: 50000 },"
                  + "  allowDiskUse: true"
                  + "}",
                    jobId);

            Document result = mongoTemplate.getDb()
                    .runCommand(Document.parse(pipelineJson));

            Set<String> targets = new HashSet<>();
            Document cursor = (Document) result.get("cursor");
            if (cursor != null) {
                @SuppressWarnings("unchecked")
                List<Document> batch = (List<Document>) cursor.get("firstBatch");
                if (batch != null) {
                    for (Document doc : batch) {
                        Object id = doc.get("_id");
                        if (id != null && !id.toString().isBlank()) {
                            targets.add(id.toString());
                        }
                    }
                }
            }
            return targets;
        } catch (Exception e) {
            log.error("Target extraction failed: {}", e.getMessage());
            return new HashSet<>();
        }
    }

    // ── Step 2 fallback ───────────────────────────────────────────────

    private Set<String> verifyExistence(String jobId,
                                         Set<String> targetRdfIds,
                                         ProgressTracker progress) {
        Set<String> existing = new HashSet<>();
        List<String> targetList = new ArrayList<>(targetRdfIds);
        int total = targetList.size();

        for (int i = 0; i < total; i += RDF_LOOKUP_BATCH) {
            int end = Math.min(i + RDF_LOOKUP_BATCH, total);
            List<String> batch = targetList.subList(i, end);

            Query q = new Query(
                    Criteria.where("jobId").is(jobId)
                            .and("rdfId").in(batch));
            q.fields().include("rdfId").exclude("_id");
            q.withHint(Document.parse("{jobId:1,rdfId:1}"));

            List<CimObjectRecord> found = mongoTemplate.find(
                    q, CimObjectRecord.class, "cim_objects");
            for (CimObjectRecord r : found) {
                if (r.getRdfId() != null) existing.add(r.getRdfId());
            }
        }
        return existing;
    }

    // ── Step 3 fallback ───────────────────────────────────────────────

    private long writeResolvedRefsBulk(String jobId,
                                        Set<String> existingRdfIds,
                                        int batchSize,
                                        ProgressTracker progress) {
        long totalResolved = 0;
        long processed = 0;
        int page = 0;

        long total = objectRepo.countByJobId(jobId);

        while (true) {
            org.springframework.data.domain.Page<CimObjectRecord> result =
                    objectRepo.findByJobId(jobId,
                            org.springframework.data.domain.PageRequest.of(
                                    page, batchSize));
            if (result.isEmpty()) break;

            org.springframework.data.mongodb.core.BulkOperations bulkOps =
                    mongoTemplate.bulkOps(
                            org.springframework.data.mongodb.core.BulkOperations.BulkMode.UNORDERED,
                            "cim_objects");
            int updatesInBatch = 0;

            for (CimObjectRecord record : result.getContent()) {
                Map<String, String> refs = record.getReferences();
                if (refs == null || refs.isEmpty()) { processed++; continue; }

                Map<String, String> decoded  = MapKeySanitizer.decodeKeys(refs);
                Map<String, String> resolved = new LinkedHashMap<>();

                for (Map.Entry<String, String> e : decoded.entrySet()) {
                    if (existingRdfIds.contains(e.getValue())) {
                        resolved.put(
                                MapKeySanitizer.encodeKey(e.getKey()),
                                e.getValue());
                        totalResolved++;
                    }
                }

                if (!resolved.isEmpty()) {
                    Query matchById = new Query(
                            Criteria.where("_id").is(record.getId()));
                    org.springframework.data.mongodb.core.query.Update update =
                            new org.springframework.data.mongodb.core.query.Update()
                                    .set("resolvedRefIds", resolved);
                    bulkOps.updateOne(matchById, update);
                    updatesInBatch++;
                }
                processed++;
            }

            if (updatesInBatch > 0) bulkOps.execute();

            if (page % 50 == 0) {
                progress.log(String.format(
                        "  Fallback write: page=%d processed=%d/%d (%.1f%%) resolved=%d",
                        page, processed, total,
                        (processed * 100.0 / Math.max(1, total)),
                        totalResolved));
            }
            page++;
        }
        return totalResolved;
    }

    private long elapsed(long startMs) {
        return (System.currentTimeMillis() - startMs) / 1000;
    }
}

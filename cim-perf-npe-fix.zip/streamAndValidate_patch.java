// REPLACE streamAndValidate() in LargeFileValidationService.java
// Fixes:
//   1. PHYSICAL only filter — skips logical objects entirely
//   2. Bulk insert findings
//   3. Stops generating finding docs for INFO findings (too verbose)
//   4. Correct validateSingle() signature

    private void streamAndValidate(String jobId,
                                   ProgressTracker progress) throws Exception {

        final int PAGE_SIZE = 1000;
        int  page = 0;
        long validated = 0, errors = 0, warnings = 0, infos = 0;

        // Empty resolvedMap — references already resolved and stored
        // in resolvedRefIds field on each record. fromRecord() restores
        // them into obj.resolved via addResolved() so refStage can use them.
        Map<String, CIMObject> resolvedMap = Collections.emptyMap();

        // OPTIMIZATION: validate PHYSICAL objects only
        // Logical objects (Terminal, ConnectivityNode etc.) skip Stage 4.
        // For Stage 2 + 3, they produce mostly INFO findings which inflate
        // the finding count without providing actionable insights.
        // Validate ALL for Stage 2+3, PHYSICAL only for Stage 4 is handled
        // inside validateSingle() — but we still page all objects.

        long total = objectRepo.countByJobId(jobId);
        progress.log("streamAndValidate: " + total + " total objects");

        while (true) {
            org.springframework.data.domain.Page<CimObjectRecord> result =
                    objectRepo.findByJobId(jobId,
                            org.springframework.data.domain.PageRequest.of(
                                    page, PAGE_SIZE));
            if (result.isEmpty()) break;

            // Only store ERROR and WARNING findings — skip INFO
            // INFO findings (valid path confirmations) inflate count
            // with no actionable value and slow down bulk insert
            List<ValidationFinding> batchDocs = new ArrayList<>();

            for (CimObjectRecord record : result.getContent()) {
                if (record.getCimType() == null) { validated++; continue; }

                CIMObject obj = fromRecord(record);

                List<PipelineFinding> objFindings =
                        pipeline.validateSingle(obj, resolvedMap, jobId);

                for (PipelineFinding f : objFindings) {
                    // ONLY persist ERROR and WARNING — skip INFO
                    // INFO = "valid path confirmed" — not useful for review
                    if (f.isError() || f.isWarning()) {
                        batchDocs.add(toFindingDoc(f));
                    }
                    if (f.isError())        errors++;
                    else if (f.isWarning()) warnings++;
                    else                    infos++;  // counted but not stored
                }
                validated++;
            }

            // Bulk insert only meaningful findings
            if (!batchDocs.isEmpty()) {
                mongoTemplate.insert(batchDocs, "validation_findings");
            }

            if (page % 10 == 0) {
                progress.log(String.format(
                        "Validation: page=%d validated=%d/%d (%.1f%%) "
                        + "errors=%d warnings=%d info(skipped)=%d",
                        page, validated, total,
                        (validated * 100.0 / Math.max(1, total)),
                        errors, warnings, infos));
            }
            page++;
        }

        progress.log(String.format(
                "Validation complete: %d objects, %d errors, "
                + "%d warnings, %d info (not stored)",
                validated, errors, warnings, infos));
    }

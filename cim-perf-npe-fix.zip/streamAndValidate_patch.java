// REPLACE streamAndValidate() in LargeFileValidationService.java

    private void streamAndValidate(String jobId,
                                   ProgressTracker progress) throws Exception {

        final int PAGE_SIZE = 1000;
        int  page = 0;
        long validated = 0, errors = 0, warnings = 0, infos = 0;

        // resolvedMap: used by ReferenceResolutionStage.run(obj, resolvedMap, jobId)
        // For streaming validation we use an empty map — references were
        // already resolved via StreamingReferenceResolver in the previous step.
        // The resolvedRefIds are stored in MongoDB on each CimObjectRecord.
        // fromRecord() restores them into obj.resolved map via addResolved().
        // So refStage can check obj.getResolved(key) for resolved references.
        Map<String, CIMObject> resolvedMap = Collections.emptyMap();

        // Count total for progress reporting
        long total = objectRepo.countByJobId(jobId);
        progress.log("streamAndValidate: " + total + " total objects");

        while (true) {
            org.springframework.data.domain.Page<CimObjectRecord> result =
                    objectRepo.findByJobId(jobId,
                            org.springframework.data.domain.PageRequest.of(
                                    page, PAGE_SIZE));
            if (result.isEmpty()) break;

            List<ValidationFinding> batchDocs = new ArrayList<>();

            for (CimObjectRecord record : result.getContent()) {
                if (record.getCimType() == null) { validated++; continue; }

                // fromRecord() restores all fields including resolvedRefIds
                CIMObject obj = fromRecord(record);

                // validateSingle uses correct method names:
                //   pathStage.run(obj, jobId)
                //   refStage.run(obj, resolvedMap, jobId)
                //   ruleStage.run(obj, jobId)
                List<PipelineFinding> objFindings =
                        pipeline.validateSingle(obj, resolvedMap, jobId);

                for (PipelineFinding f : objFindings) {
                    batchDocs.add(toFindingDoc(f));
                    if (f.isError())        errors++;
                    else if (f.isWarning()) warnings++;
                    else                    infos++;
                }
                validated++;
            }

            // Bulk insert findings — 1 round trip per batch
            if (!batchDocs.isEmpty()) {
                mongoTemplate.insert(batchDocs, "validation_findings");
            }

            if (page % 10 == 0) {
                progress.log(String.format(
                        "Validation: page=%d validated=%d/%d (%.1f%%) "
                        + "errors=%d warnings=%d",
                        page, validated, total,
                        (validated * 100.0 / Math.max(1, total)),
                        errors, warnings));
            }
            page++;
        }

        progress.log(String.format(
                "Validation complete: %d objects, %d errors, "
                + "%d warnings, %d info",
                validated, errors, warnings, infos));
    }

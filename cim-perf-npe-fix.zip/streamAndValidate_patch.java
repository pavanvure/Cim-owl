// REPLACE streamAndValidate() in LargeFileValidationService.java with this:

    private void streamAndValidate(String jobId,
                                   ProgressTracker progress) throws Exception {

        final int PAGE_SIZE = 1000; // larger batch = fewer round trips
        int    page     = 0;
        long   validated= 0, errors = 0, warnings = 0, infos = 0;

        // Count PHYSICAL objects only — business rules only apply to these
        // Logical objects (Terminal, ConnectivityNode) are stored but
        // do not need business rule validation
        long totalPhysical = mongoTemplate.count(
                new Query(Criteria.where("jobId").is(jobId)
                        .and("category").is("PHYSICAL")),
                "cim_objects");

        // Also count logical for reporting
        long totalLogical = mongoTemplate.count(
                new Query(Criteria.where("jobId").is(jobId)
                        .and("category").is("LOGICAL")),
                "cim_objects");

        progress.log(String.format(
                "Validation starting: %d physical + %d logical = %d total. "
                + "Validating physical only.",
                totalPhysical, totalLogical, totalPhysical + totalLogical));

        while (true) {
            // OPTIMIZATION: query ONLY physical objects
            // This skips ~40-60% of objects depending on the CIM file
            Query q = new Query(
                    Criteria.where("jobId").is(jobId)
                            .and("category").is("PHYSICAL"));
            q.with(PageRequest.of(page, PAGE_SIZE));

            List<CimObjectRecord> batch = mongoTemplate.find(
                    q, CimObjectRecord.class, "cim_objects");
            if (batch.isEmpty()) break;

            // Collect findings for this batch
            List<ValidationFinding> batchDocs = new ArrayList<>();

            for (CimObjectRecord record : batch) {
                if (record.getCimType() == null) { validated++; continue; }

                CIMObject obj = fromRecord(record);

                // Run all validation stages for this object
                List<PipelineFinding> objFindings =
                        pipeline.validateSingle(obj, jobId);

                for (PipelineFinding f : objFindings) {
                    batchDocs.add(toFindingDoc(f));
                    if (f.isError())        errors++;
                    else if (f.isWarning()) warnings++;
                    else                    infos++;
                }
                validated++;
            }

            // Bulk insert findings — 1 round trip per batch
            if (!batchDocs.isEmpty()) {
                mongoTemplate.insert(batchDocs, "validation_findings");
            }

            // Update progress counters
            progress.addValidated(batch.size());

            if (page % 10 == 0) {
                progress.log(String.format(
                        "Validation: page=%d validated=%d/%d (%.1f%%) "
                        + "errors=%d warnings=%d info=%d",
                        page, validated, totalPhysical,
                        (validated * 100.0 / Math.max(1, totalPhysical)),
                        errors, warnings, infos));
            }
            page++;
        }

        progress.log(String.format(
                "Validation complete: %d/%d physical objects validated, "
                + "%d errors, %d warnings, %d info",
                validated, totalPhysical, errors, warnings, infos));
    }

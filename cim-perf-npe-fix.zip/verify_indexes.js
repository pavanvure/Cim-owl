// Run in mongosh to verify indexes are being used correctly
// mongosh mongodb://localhost:27017/cim_platform verify_indexes.js

use("cim_platform");

print("=".repeat(60));
print("INDEX USAGE VERIFICATION");
print("=".repeat(60));

// ── 1. Show all indexes on cim_objects ────────────────────────────
print("\n[1] Current indexes on cim_objects:");
db.cim_objects.getIndexes().forEach(idx => {
  print("  " + idx.name + " → " + JSON.stringify(idx.key));
});

// ── 2. Get a sample jobId to test with ───────────────────────────
var sample = db.cim_objects.findOne();
if (!sample) { print("No documents found!"); quit(); }
var jobId = sample.jobId;
print("\n[2] Testing with jobId: " + jobId);
print("    Total objects for this job: " +
      db.cim_objects.countDocuments({jobId: jobId}));

// ── 3. Test the $in query with HINT to force compound index ───────
print("\n[3] Testing compound index query (hint forced):");
var sampleRdfIds = db.cim_objects
  .find({jobId: jobId}, {rdfId:1, _id:0})
  .limit(200)
  .map(d => d.rdfId);

var explain = db.cim_objects
  .find(
    { jobId: jobId, rdfId: { $in: sampleRdfIds.slice(0,20) } },
    { rdfId: 1, _id: 0 }
  )
  .hint({ jobId: 1, rdfId: 1 })  // FORCE compound index
  .explain("executionStats");

var stage = explain.executionStats;
print("  Documents examined: " + stage.totalDocsExamined);
print("  Documents returned: " + stage.totalDocsReturned);
print("  Execution time ms:  " + stage.executionTimeMillis);
print("  Index used: " +
      (explain.queryPlanner.winningPlan.inputStage
       ? explain.queryPlanner.winningPlan.inputStage.indexName
       : "none"));

if (stage.totalDocsExamined === stage.totalDocsReturned) {
  print("  ✅ EFFICIENT: examined == returned (perfect index use)");
} else {
  print("  ⚠️  examined > returned (some filtering after index scan)");
}

// ── 4. Check if the Java app can add .hint() ─────────────────────
print("\n[4] RECOMMENDATION:");
print("  Add .hint() to the MongoTemplate query in");
print("  StreamingReferenceResolver.findExistingInBatches():");
print('  q.withHint("{jobId:1,rdfId:1}");');
print("  This forces MongoDB to use the compound index.");

print("\n" + "=".repeat(60));

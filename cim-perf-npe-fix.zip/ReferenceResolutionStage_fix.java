// ═══════════════════════════════════════════════════════════════════
// REPLACE ReferenceResolutionStage.run() in ValidationPipeline.java
//
// ROOT CAUSE OF "not found" FALSE WARNINGS:
//
//   run(obj, allById, jobId) checks allById.containsKey(targetId)
//   But streamAndValidate passes Collections.emptyMap() as allById
//   So EVERY reference shows "not found" — false warning for all.
//
// THE FIX:
//   Check obj.getResolved() FIRST (populated by fromRecord() from
//   resolvedRefIds stored in MongoDB by StreamingReferenceResolver).
//   Only produce "not found" warning if NEITHER allById NOR
//   obj.resolved contains the reference.
//
//   For the Terminal PCB_23HB2_PCB_2 example:
//   BEFORE: allById is empty → "not found" → WARNING (wrong!)
//   AFTER:  obj.getResolved("Terminal.ConnectivityNode") returns stub
//           → resolved → INFO (correct!)
// ═══════════════════════════════════════════════════════════════════

    List<PipelineFinding> run(CIMObject obj,
                               Map<String, CIMObject> allById,
                               String jobId) {
        List<PipelineFinding> findings = new ArrayList<>();

        for (Map.Entry<String, String> ref : obj.getReferences().entrySet()) {
            String key      = ref.getKey();
            String targetId = ref.getValue();

            // CHECK 1: Was this reference resolved by StreamingReferenceResolver?
            // fromRecord() restored resolvedRefIds into obj.resolved map.
            // This is the primary resolution source for streaming validation.
            CIMObject target = null;
            if (obj.hasResolved(key)) {
                target = obj.getResolved(key);
            }

            // CHECK 2: Is the target in the in-memory allById map?
            // Used for synchronous (non-streaming) validation of small files.
            if (target == null && allById.containsKey(targetId)) {
                target = allById.get(targetId);
            }

            // NOT FOUND in either source
            if (target == null) {
                findings.add(PipelineFinding.warning(jobId,
                        "REFERENCE_RESOLUTION", obj, key,
                        "Reference '" + targetId + "' not found in this file. "
                        + "May be defined in another CIM profile file.", null));
                continue;
            }

            // FOUND — verify type compatibility if known
            String expectedType = EXPECTED_TYPES.get(key);
            if (expectedType != null
                    && target.getCimType() != null
                    && !target.getCimType().equals("ResolvedRef")) {
                // Only check type for real objects, not stubs
                List<String> chain = registry.getFullChain(target.getCimType());
                if (!chain.contains(expectedType)
                        && !target.getCimType().equals(expectedType)) {
                    findings.add(PipelineFinding.error(jobId,
                            "REFERENCE_RESOLUTION", obj, key,
                            "Target type '" + target.getCimType()
                            + "' not compatible with expected '"
                            + expectedType + "'.", null));
                    continue;
                }
            }

            // Valid resolution — INFO only (not stored, per streamAndValidate filter)
            findings.add(PipelineFinding.info(jobId,
                    "REFERENCE_RESOLUTION", obj, key,
                    "Resolved → " + targetId, null));
        }
        return findings;
    }

// ADD THESE TWO METHODS to CIMObject.java
// Insert after line 77 (after hasResolved() method)

    /**
     * Returns true if this object has any rdf:resource references.
     * Used in validateSingle() to skip Stage 3 for objects with no refs.
     *
     * Note: hasReference(key) already exists — this checks ANY reference.
     */
    public boolean hasReferences() {
        return !references.isEmpty();
    }

    /**
     * Returns "PHYSICAL" or "LOGICAL" based on cimType classification.
     * Used in validateSingle() to skip business rules for logical nodes.
     */
    public String getCategory() {
        return com.cim.pipeline.stage.PhysicalFilterStage.isLogical(cimType)
                ? "LOGICAL" : "PHYSICAL";
    }

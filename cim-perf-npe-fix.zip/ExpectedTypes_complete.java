// ═══════════════════════════════════════════════════════════════════
// REPLACE EXPECTED_TYPES in ReferenceResolutionStage (inside ValidationPipeline.java)
//
// Format: "ReferenceKey" → "ExpectedTargetType"
// Where:
//   ReferenceKey       = the attribute tag used in the CIM file
//   ExpectedTargetType = the CIM class the target MUST be (or inherit from)
//
// Per IEC 61970-301 (CIM17) and PNNL-34946
// ═══════════════════════════════════════════════════════════════════

private static final Map<String, String> EXPECTED_TYPES = new LinkedHashMap<String, String>() {{

    // ── Terminal associations ─────────────────────────────────────────
    // Terminal is the connection point between equipment and topology
    put("Terminal.ConnectivityNode",        "ConnectivityNode");
    put("Terminal.ConductingEquipment",     "ConductingEquipment");
    put("Terminal.TopologicalNode",         "TopologicalNode");  // State Variables

    // ── Equipment → BaseVoltage ───────────────────────────────────────
    // Every conducting equipment references its nominal voltage
    put("ConductingEquipment.BaseVoltage",  "BaseVoltage");
    put("VoltageLevel.BaseVoltage",         "BaseVoltage");
    put("PowerTransformerEnd.BaseVoltage",  "BaseVoltage");
    put("TransformerEnd.BaseVoltage",       "BaseVoltage");
    put("DCConverterUnit.BaseVoltage",      "BaseVoltage");

    // ── Equipment → EquipmentContainer ───────────────────────────────
    // Equipment lives inside a container (Line, Substation, VoltageLevel)
    put("Equipment.EquipmentContainer",         "EquipmentContainer");
    put("PowerTransformer.EquipmentContainer",  "EquipmentContainer");

    // ── Substation hierarchy ──────────────────────────────────────────
    // Substation → SubGeographicalRegion → GeographicalRegion
    put("Substation.Region",                "SubGeographicalRegion");
    put("SubGeographicalRegion.Region",     "GeographicalRegion");
    put("Line.Region",                      "SubGeographicalRegion");
    put("VoltageLevel.Substation",          "Substation");
    put("Bay.VoltageLevel",                 "VoltageLevel");

    // ── Transformer ───────────────────────────────────────────────────
    put("PowerTransformerEnd.PowerTransformer",  "PowerTransformer");
    put("TransformerTankEnd.TransformerTank",    "TransformerTank");
    put("TransformerTank.PowerTransformer",      "PowerTransformer");
    put("RatioTapChanger.TransformerEnd",        "TransformerEnd");
    put("PhaseTapChangerLinear.TransformerEnd",  "TransformerEnd");
    put("TapChanger.TapChangerControl",          "TapChangerControl");

    // ── Generation ────────────────────────────────────────────────────
    put("SynchronousMachine.GeneratingUnit",     "GeneratingUnit");
    put("AsynchronousMachine.GeneratingUnit",    "GeneratingUnit");
    put("GeneratingUnit.EquipmentContainer",     "Substation");

    // ── DER / Power Electronics ───────────────────────────────────────
    put("PowerElectronicsConnection.PowerElectronicsUnit",  "PowerElectronicsUnit");
    put("BatteryUnit.PowerElectronicsConnection",           "PowerElectronicsConnection");
    put("PhotoVoltaicUnit.PowerElectronicsConnection",      "PowerElectronicsConnection");

    // ── ACLineSegment ─────────────────────────────────────────────────
    put("ACLineSegment.PerLengthImpedance",      "PerLengthImpedance");
    put("ACLineSegment.WireSpacingInfo",         "WireSpacingInfo");
    put("Conductor.WireInfo",                    "WireInfo");

    // ── Shunt Compensator ─────────────────────────────────────────────
    put("ShuntCompensator.RegulatingControl",    "RegulatingControl");
    put("LinearShuntCompensator.ShuntCompensatorPhase", "ShuntCompensatorPhase");

    // ── Switch / Breaker ──────────────────────────────────────────────
    put("Switch.SwitchPhase",                   "SwitchPhase");
    put("ProtectedSwitch.OperatedBy",           "ProtectionEquipment");

    // ── Load ──────────────────────────────────────────────────────────
    put("EnergyConsumer.LoadResponse",           "LoadResponseCharacteristic");
    put("ConformLoad.LoadGroup",                 "ConformLoadGroup");
    put("NonConformLoad.LoadGroup",              "NonConformLoadGroup");

    // ── Regulation ────────────────────────────────────────────────────
    put("RegulatingCondEq.RegulatingControl",    "RegulatingControl");
    put("RegulatingControl.Terminal",            "Terminal");
    put("TapChangerControl.Terminal",            "Terminal");

    // ── Geographic / Location ─────────────────────────────────────────
    put("PowerSystemResource.Location",          "Location");
    put("Asset.Location",                        "Location");
    put("Location.CoordinateSystem",             "CoordinateSystem");

    // ── Connectivity ──────────────────────────────────────────────────
    put("ConnectivityNode.ConnectivityNodeContainer", "ConnectivityNodeContainer");
    put("TopologicalNode.ConnectivityNodeContainer",  "ConnectivityNodeContainer");
    put("TopologicalNode.BaseVoltage",                "BaseVoltage");
    put("TopologicalIsland.AngleRefTopologicalNode",  "TopologicalNode");

    // ── Operational Limits ────────────────────────────────────────────
    put("OperationalLimitSet.Equipment",         "Equipment");
    put("OperationalLimitSet.Terminal",          "Terminal");
    put("OperationalLimit.OperationalLimitSet",  "OperationalLimitSet");
    put("OperationalLimit.OperationalLimitType", "OperationalLimitType");

    // ── Control Area ──────────────────────────────────────────────────
    put("ControlArea.EnergyArea",                "EnergyArea");
    put("TieFlow.Terminal",                      "Terminal");
    put("TieFlow.ControlArea",                   "ControlArea");
}};

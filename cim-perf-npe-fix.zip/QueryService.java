package com.cim.service;

import com.cim.model.mongo.*;
import com.cim.repository.*;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Sort;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.aggregation.*;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.stereotype.Service;

import java.util.*;

/**
 * QueryService — fixed NPE in getTypeBreakdown / getObjectStats
 *
 * Root cause of NPE (QueryService.java:71):
 *   interface with get_id(). When the aggregation document has _id=null
 *   (e.g. objects with null cimType) or when Spring cannot map the
 *   interface correctly, get_id() returns null → NPE in getTypeBreakdown.
 *
 * Fix: Replace interface-based aggregation with MongoTemplate aggregation
 *   using concrete Map results — null-safe and no interface mapping issues.
 */
@Service
public class QueryService {

    private final ValidationJobRepository     jobRepo;
    private final CimObjectRecordRepository   objectRepo;
    private final ValidationFindingRepository findingRepo;
    private final MongoTemplate               mongoTemplate;

    public QueryService(ValidationJobRepository jobRepo,
                        CimObjectRecordRepository objectRepo,
                        ValidationFindingRepository findingRepo,
                        MongoTemplate mongoTemplate) {
        this.jobRepo       = jobRepo;
        this.objectRepo    = objectRepo;
        this.findingRepo   = findingRepo;
        this.mongoTemplate = mongoTemplate;
    }

    // ── Jobs ──────────────────────────────────────────────────────────────

    public Optional<ValidationJob> getJob(String jobId) {
        return jobRepo.findByJobId(jobId);
    }

    public List<ValidationJob> getRecentJobs(int limit) {
        return jobRepo.findTop10ByOrderBySubmittedAtDesc();
    }

    // ── CIM Objects ───────────────────────────────────────────────────────

    public Page<CimObjectRecord> getObjects(String jobId, int page, int size) {
        return objectRepo.findByJobId(jobId,
                PageRequest.of(page, size, Sort.by("cimType")));
    }

    public List<CimObjectRecord> getObjectsByType(String jobId, String cimType) {
        return objectRepo.findByJobIdAndCimType(jobId, cimType);
    }

    public List<CimObjectRecord> getPhysicalObjects(String jobId) {
        return objectRepo.findByJobIdAndCategory(jobId, "PHYSICAL");
    }

    public List<CimObjectRecord> getLogicalObjects(String jobId) {
        return objectRepo.findByJobIdAndCategory(jobId, "LOGICAL");
    }

    public List<CimObjectRecord> searchByName(String jobId, String name) {
        return objectRepo.searchByName(jobId, name);
    }

    // ── getObjectStats — FIXED: uses MongoTemplate, null-safe ─────────────

    /**
     * Returns object counts grouped by CIM type.
     *
     * when _id was null (objects with null/empty cimType).
     * Now uses MongoTemplate aggregation with Map<String,Object> results —
     * explicit null handling, no interface mapping issues.
     */
    public Map<String, Object> getObjectStats(String jobId) {
        long total    = objectRepo.countByJobId(jobId);
        long physical = objectRepo.countByJobIdAndCategory(jobId, "PHYSICAL");
        long logical  = objectRepo.countByJobIdAndCategory(jobId, "LOGICAL");

        // Safe type breakdown using MongoTemplate
        List<Map<String, Object>> byType = getTypeBreakdownSafe(jobId);

        Map<String, Object> stats = new LinkedHashMap<>();
        stats.put("total",    total);
        stats.put("physical", physical);
        stats.put("logical",  logical);
        stats.put("byType",   byType);
        return stats;
    }

    /**
     * Type breakdown using MongoTemplate aggregation — null-safe.
     * Returns list of { "type": "ACLineSegment", "count": 1234 }
     */
    private List<Map<String, Object>> getTypeBreakdownSafe(String jobId) {
        try {
            MatchOperation match = Aggregation.match(
                    Criteria.where("jobId").is(jobId));

            GroupOperation group = Aggregation.group("cimType")
                    .count().as("count");

            SortOperation sort = Aggregation.sort(
                    Sort.by(Sort.Direction.DESC, "count"));

            Aggregation agg = Aggregation.newAggregation(match, group, sort);

            AggregationResults<org.bson.Document> results =
                    mongoTemplate.aggregate(agg, "cim_objects",
                            org.bson.Document.class);

            List<Map<String, Object>> breakdown = new ArrayList<>();
            for (org.bson.Document doc : results.getMappedResults()) {
                // _id holds the cimType value (may be null for ungrouped)
                Object typeVal = doc.get("_id");
                int    count   = doc.getInteger("count", 0);

                // Skip null type entries
                if (typeVal == null || typeVal.toString().isBlank()) continue;

                Map<String, Object> entry = new LinkedHashMap<>();
                entry.put("type",  typeVal.toString());
                entry.put("count", count);
                breakdown.add(entry);
            }
            return breakdown;

        } catch (Exception e) {
            // Fallback: return empty list rather than NPE
            return Collections.emptyList();
        }
    }

    // ── Validation Findings ───────────────────────────────────────────────

    public Page<ValidationFinding> getFindings(String jobId, int page, int size) {
        return findingRepo.findByJobId(jobId,
                PageRequest.of(page, size, Sort.by("severity")));
    }

    public List<ValidationFinding> getFindingsBySeverity(String jobId, String severity) {
        return findingRepo.findByJobIdAndSeverity(jobId, severity.toUpperCase());
    }

    public List<ValidationFinding> getFindingsByStage(String jobId, String stage) {
        return findingRepo.findByJobIdAndStage(jobId, stage.toUpperCase());
    }

    public List<ValidationFinding> getFindingsByObjectType(String jobId, String type) {
        return findingRepo.findByJobIdAndObjectType(jobId, type);
    }

    public Map<String, Object> getFindingSummary(String jobId) {
        Map<String, Object> summary = new LinkedHashMap<>();
        summary.put("total",    findingRepo.countByJobId(jobId));
        summary.put("errors",   findingRepo.countByJobIdAndSeverity(jobId, "ERROR"));
        summary.put("warnings", findingRepo.countByJobIdAndSeverity(jobId, "WARNING"));
        summary.put("info",     findingRepo.countByJobIdAndSeverity(jobId, "INFO"));
        return summary;
    }
}

// REPLACE determineCategory() in CIMOwlParser.java
//
// PROBLEM: In CPSM files, BOTH physical and logical classes use
// "byreference" stereotype. The stereotype alone is not enough to
// distinguish them.
//
// "byreference" means: "this class is referenced by UUID in CIM files"
// It applies to ALL CIM classes — not just physical equipment.
//
// CORRECT classification logic (per IEC 61970 package structure):
//   Package = Wires, Generation, Meas(Equipment) → PHYSICAL
//   Package = Topology, Meas, StateVariables     → LOGICAL
//   Stereotype = abstract, Primitive, enumeration → LOGICAL
//   Name heuristics as final fallback

    private String determineCategory(ClassEntry entry) {

        // 1. Stereotype-based — clear logical indicators
        if (entry.stereotype != null) {
            switch (entry.stereotype) {
                case "abstract":
                case "Abstract":
                    // Abstract base classes — LOGICAL (not instantiated directly)
                    return "LOGICAL";
                case "Primitive":
                case "CIMDatatype":
                    // Primitive types like Resistance, Voltage — LOGICAL
                    return "LOGICAL";
                case "enumeration":
                case "Enumeration":
                    // Enumerations like WindingConnection — LOGICAL
                    return "LOGICAL";
                case "Compound":
                    // Compound types like SvPowerFlow — LOGICAL
                    return "LOGICAL";
                // NOTE: "byreference" and "concrete" are NOT used here
                // because CPSM uses "byreference" for ALL classes
            }
        }

        // 2. Package-based — most reliable for CPSM profiles
        if (entry.packageName != null) {
            switch (entry.packageName) {
                // Definitely LOGICAL
                case "Topology":
                case "Meas":
                case "StateVariables":
                case "LoadModel":
                case "Contingency":
                case "InfWork":
                case "InfAssets":
                case "InfLocations":
                case "InfOperations":
                case "IEC61968CIMVersion":
                case "IEC61970CIMVersion":
                case "DiagramLayout":
                    return "LOGICAL";

                // Definitely PHYSICAL
                case "Wires":
                case "Generation":
                case "GenerationTrainingSimulation":
                case "Substation":
                case "Protection":
                case "ControlArea":
                case "DC":
                case "InfERPSupport":
                    return "PHYSICAL";
            }
        }

        // 3. Class name based — well-known CIM classes
        if (entry.name != null) {
            String n = entry.name;

            // Well-known LOGICAL classes
            if (n.equals("Terminal") || n.equals("ACDCTerminal")
                    || n.equals("DCTerminal")
                    || n.equals("ConnectivityNode")
                    || n.equals("TopologicalNode")
                    || n.equals("TopologicalIsland")
                    || n.equals("BusNameMarker")) {
                return "LOGICAL";
            }

            // Measurement and state variables
            if (n.equals("Measurement") || n.equals("Analog")
                    || n.equals("Discrete") || n.equals("Accumulator")
                    || n.endsWith("Value") || n.endsWith("Schedule")
                    || n.startsWith("Sv")   // StateVariables: SvVoltage, SvPowerFlow
                    || n.startsWith("Tp")) { // TopologicalIsland etc.
                return "LOGICAL";
            }

            // Suffix-based heuristics
            if (n.endsWith("Island") || n.endsWith("Node")
                    || n.endsWith("Kind")  || n.endsWith("Type")
                    || n.endsWith("Enum")) {
                return "LOGICAL";
            }
        }

        // 4. Default — assume PHYSICAL
        // Better to over-apply business rules than to miss real equipment
        return "PHYSICAL";
    }

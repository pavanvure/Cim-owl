package com.cim.service;

import com.cim.model.mongo.CimClassDefinition;
import org.apache.jena.rdf.model.*;
import org.apache.jena.vocabulary.OWL;
import org.apache.jena.vocabulary.RDF;
import org.apache.jena.vocabulary.RDFS;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import java.io.*;
import java.util.*;

/**
 * CIM OWL PARSER — Apache Jena implementation
 * ════════════════════════════════════════════════════════════════════
 *
 * Uses Apache Jena to read CPSM OWL files (0.4MB - 0.6MB total).
 * Jena loads the full RDF graph into memory which is fine for small
 * OWL schema files — loaded ONCE at startup.
 *
 * WHY JENA FOR OWL (not StAX):
 *   StAX reads raw XML tokens — no understanding of RDF semantics.
 *   We had to manually track rdf:nodeID cross-references, handle
 *   rdf:Description blocks with deferred type detection, and parse
 *   owl:Restriction → owl:onProperty chains manually.
 *
 *   Jena gives us a proper RDF graph:
 *     model.listSubjectsWithProperty(RDF.type, OWL.Class)
 *     resource.getProperty(RDFS.label).getString()
 *   Clean, correct, and handles all RDF/OWL serialization variants.
 *
 * VERIFIED CPSM FILE STRUCTURE (from CPSM-CoreEquipment.owl source):
 *
 *   CIM Class:
 *     rdf:type          = owl:Class
 *     rdfs:label        = "ACLineSegment"        ← class name
 *     rdfs:subClassOf   = cim:Conductor          ← parent URI
 *     uml:hasStereotype = uml:byreference        ← PHYSICAL
 *
 *   Attribute mapping (via owl:Restriction):
 *     rdf:type          = owl:Restriction
 *     owl:onProperty    = cim:ACLineSegment.r    ← split on dot
 *     → class="ACLineSegment", attr="r"
 */
@Component
public class CIMOwlParser {

    private static final Logger log = LoggerFactory.getLogger(CIMOwlParser.class);

    private static final String NS_UML = "http://langdale.com.au/2005/UML#";

    private static final Property PROP_HAS_STEREOTYPE =
            ResourceFactory.createProperty(NS_UML, "hasStereotype");

    private static final Set<String> PHYSICAL_STEREO =
            Set.of("byreference", "concrete", "Concrete");

    private static final Set<String> LOGICAL_STEREO =
            Set.of("abstract", "Abstract", "Primitive", "CIMDatatype",
                   "enumeration", "Enumeration", "Compound");

    private static final Set<String> LOGICAL_PACKAGES =
            Set.of("Topology","Meas","StateVariables","LoadModel","Contingency",
                   "InfWork","InfAssets","InfLocations","InfOperations");

    // ── Internal model ─────────────────────────────────────────────────────

    private static class ClassInfo {
        final String name, parentName, stereotype, description;
        ClassInfo(String n, String p, String s, String d) {
            name=n; parentName=p; stereotype=s; description=d;
        }
    }

    // ═══════════════════════════════════════════════════════════════════════
    // PUBLIC API — Single file
    // ═══════════════════════════════════════════════════════════════════════

    public List<CimClassDefinition> parse(InputStream in, String version)
            throws Exception {
        return parse(in, version, "uploaded.owl");
    }

    public List<CimClassDefinition> parse(InputStream in, String version,
                                           String fileName) throws Exception {
        log.info("Parsing OWL (Jena): '{}' version={}", fileName, version);
        long start = System.currentTimeMillis();

        Model model = ModelFactory.createDefaultModel();
        model.read(in, null, "RDF/XML");
        log.info("  Loaded {} triples from '{}'", model.size(), fileName);

        List<CimClassDefinition> defs = extractDefinitions(model, version);
        log.info("  Extracted {} classes ({} with attributes) in {}ms",
                defs.size(),
                defs.stream().filter(d -> !d.getOwnAttributes().isEmpty()).count(),
                System.currentTimeMillis() - start);
        return defs;
    }

    // ═══════════════════════════════════════════════════════════════════════
    // PUBLIC API — Multiple files (CPSM multi-profile merge)
    // ═══════════════════════════════════════════════════════════════════════

    /**
     * Parse and merge multiple CPSM profile OWL files.
     * All files are loaded into ONE combined Jena Model before extraction.
     * This lets cross-file subClassOf references resolve correctly.
     */
    public List<CimClassDefinition> parseMultiple(
            Map<String, InputStream> streams, String version) throws Exception {

        log.info("Merging {} OWL files into one Jena model (version: {})",
                streams.size(), version);
        long start = System.currentTimeMillis();

        // Merge all files into one model — fine because all files total < 1MB
        Model merged = ModelFactory.createDefaultModel();
        for (Map.Entry<String, InputStream> e : streams.entrySet()) {
            Model fm = ModelFactory.createDefaultModel();
            fm.read(e.getValue(), null, "RDF/XML");
            log.info("  Loaded {} triples from '{}'", fm.size(), e.getKey());
            merged.add(fm);
        }
        log.info("  Combined model: {} total triples", merged.size());

        List<CimClassDefinition> defs = extractDefinitions(merged, version);
        log.info("Merge complete: {} classes ({} with attributes) in {}ms",
                defs.size(),
                defs.stream().filter(d -> !d.getOwnAttributes().isEmpty()).count(),
                System.currentTimeMillis() - start);
        return defs;
    }

    // ═══════════════════════════════════════════════════════════════════════
    // CORE EXTRACTION — Jena graph queries
    // ═══════════════════════════════════════════════════════════════════════

    private List<CimClassDefinition> extractDefinitions(Model model, String version) {

        // ── 1. Find all CIM classes ───────────────────────────────────────
        Map<String, ClassInfo> classMap = new LinkedHashMap<>();

        // owl:Class resources
        model.listSubjectsWithProperty(RDF.type, OWL.Class)
             .forEachRemaining(r -> {
                 ClassInfo ci = extractClassInfo(r);
                 if (ci != null) classMap.putIfAbsent(ci.name, ci);
             });

        // rdfs:Class resources (some CPSM variants)
        model.listSubjectsWithProperty(RDF.type, RDFS.Class)
             .forEachRemaining(r -> {
                 ClassInfo ci = extractClassInfo(r);
                 if (ci != null) classMap.putIfAbsent(ci.name, ci);
             });

        log.info("  Classes found: {}", classMap.size());

        // ── 2. Find attribute→class mappings via owl:Restriction ──────────
        // owl:onProperty = "http://...#ACLineSegment.r"
        // Split on "." → class="ACLineSegment", attr="r"
        Map<String, List<String>> attrMap = new LinkedHashMap<>();

        model.listSubjectsWithProperty(RDF.type, OWL.Restriction)
             .forEachRemaining(restriction -> {
                 Statement onProp = restriction.getProperty(OWL.onProperty);
                 if (onProp == null) return;

                 String propUri   = onProp.getObject().toString();
                 String propLocal = localName(propUri); // "ACLineSegment.r"
                 if (propLocal == null || !propLocal.contains(".")) return;

                 int    dot  = propLocal.lastIndexOf('.');
                 String cls  = propLocal.substring(0, dot);
                 String attr = propLocal.substring(dot + 1);
                 if (cls.isBlank() || attr.isBlank()) return;

                 // Register attribute under its class
                 List<String> attrs = attrMap.computeIfAbsent(
                         cls, k -> new ArrayList<>());
                 if (!attrs.contains(attr)) attrs.add(attr);

                 // Ensure class entry exists (restriction may appear
                 // before its owl:Class block in the file)
                 classMap.computeIfAbsent(cls,
                         k -> new ClassInfo(cls, null, null, null));
             });

        log.info("  Classes with attribute mappings: {}",
                attrMap.values().stream().filter(l -> !l.isEmpty()).count());

        // ── 3. Build parent map ───────────────────────────────────────────
        Map<String, String> parentMap = new LinkedHashMap<>();
        classMap.forEach((name, ci) -> {
            if (ci.parentName != null && !ci.parentName.equals(name)) {
                parentMap.put(name, ci.parentName);
            }
        });

        // ── 4. Build CimClassDefinition list ─────────────────────────────
        List<CimClassDefinition> defs = new ArrayList<>();
        classMap.forEach((name, ci) -> {
            // Deduplicated attribute list
            List<String> attrs = new ArrayList<>();
            List<String> raw   = attrMap.get(name);
            if (raw != null) {
                for (String a : raw) if (!attrs.contains(a)) attrs.add(a);
            }

            CimClassDefinition def = new CimClassDefinition(
                    name,
                    parentMap.get(name),
                    computeAncestors(name, parentMap),
                    attrs,
                    determineCategory(ci.stereotype),
                    version);
            def.setCimPackage("Core");
            def.setDescription(ci.description);
            defs.add(def);
        });

        return defs;
    }

    // ── Extract ClassInfo from one Jena Resource ──────────────────────────

    private ClassInfo extractClassInfo(Resource resource) {

        // Class name — from rdfs:label (CPSM pattern)
        String name = null;
        Statement labelStmt = resource.getProperty(RDFS.label);
        if (labelStmt != null) name = labelStmt.getString().trim();

        // Fallback: URI local name (standard OWL pattern)
        if ((name == null || name.isBlank()) && resource.isURIResource()) {
            name = localName(resource.getURI());
        }
        if (name == null || name.isBlank()) return null;

        // Parent class — from rdfs:subClassOf
        String parentName = null;
        Statement subStmt = resource.getProperty(RDFS.subClassOf);
        if (subStmt != null) {
            RDFNode parent = subStmt.getObject();
            if (parent.isURIResource()) {
                parentName = localName(parent.asResource().getURI());
                if ("Thing".equals(parentName) || parentName.equals(name)) {
                    parentName = null;
                }
            } else if (parent.isResource()) {
                // Anonymous blank node — try to get its label
                Statement pl = parent.asResource().getProperty(RDFS.label);
                if (pl != null) parentName = pl.getString().trim();
            }
        }

        // Stereotype — from uml:hasStereotype (Langdale NS)
        String stereotype = null;
        Statement stereoStmt = resource.getProperty(PROP_HAS_STEREOTYPE);
        if (stereoStmt != null) {
            RDFNode node = stereoStmt.getObject();
            stereotype = node.isURIResource()
                    ? localName(node.asResource().getURI())
                    : node.asLiteral().getString().trim();
        }

        // Description — from rdfs:comment
        String description = null;
        Statement commentStmt = resource.getProperty(RDFS.comment);
        if (commentStmt != null) description = commentStmt.getString().trim();

        return new ClassInfo(name, parentName, stereotype, description);
    }

    // ── Helpers ────────────────────────────────────────────────────────────

    private List<String> computeAncestors(String cls, Map<String, String> parentMap) {
        List<String> chain   = new ArrayList<>();
        Set<String>  visited = new HashSet<>();
        String       cur     = parentMap.get(cls);
        while (cur != null && !visited.contains(cur)) {
            chain.add(cur);
            visited.add(cur);
            cur = parentMap.get(cur);
        }
        return chain;
    }

    private String determineCategory(String stereotype) {
        if (stereotype != null) {
            if (PHYSICAL_STEREO.contains(stereotype)) return "PHYSICAL";
            if (LOGICAL_STEREO.contains(stereotype))  return "LOGICAL";
        }
        return "PHYSICAL";
    }

    /** "http://iec.ch/TC57/CIM100#ACLineSegment" → "ACLineSegment" */
    String localName(String uri) {
        if (uri == null || uri.isBlank()) return null;
        int idx = Math.max(uri.lastIndexOf('#'), uri.lastIndexOf('/'));
        return (idx >= 0 && idx < uri.length() - 1)
                ? uri.substring(idx + 1) : uri;
    }
}

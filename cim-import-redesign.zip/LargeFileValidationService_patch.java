// ═══════════════════════════════════════════════════════════════════
// ADD THESE TWO METHODS to LargeFileValidationService.java
//
// processAndResolve()      — synchronous (small files)
// processAndResolveAsync() — async (large files)
//
// Both STOP after reference resolution — NO validation pipeline.
// Status goes: PENDING → RUNNING → RESOLVED
//
// The networkVersion is stored on:
//   - ValidationJob.networkVersion
//   - Every CimObjectRecord.version  (set in toRecord())
// ═══════════════════════════════════════════════════════════════════

    /**
     * Synchronous: parse → save → resolve references.
     * No validation. Status = RESOLVED when done.
     *
     * @param inputStream   file stream
     * @param fileName      original filename
     * @param fileFormat    RDF_XML / JSON_LD / MILSOFT_CSV
     * @param jobId         pre-created job ID
     * @param networkVersion user-supplied version label
     */
    public void processAndResolve(InputStream inputStream,
                                   String fileName,
                                   String fileFormat,
                                   String jobId,
                                   String networkVersion) throws Exception {

        int logEvery = 10_000;
        ProgressTracker progress = new ProgressTracker(jobId, logEvery);
        trackers.put(jobId, progress);

        ValidationJob job = jobRepo.findByJobId(jobId).orElseThrow();
        job.setStatus("RUNNING");
        job.setNetworkVersion(networkVersion);
        jobRepo.save(job);

        try {
            // ── Step 1: Stream parse + save to MongoDB ────────────────────
            progress.setStage(ProgressTracker.Stage.STREAMING_PARSE,
                    "Streaming " + fileFormat + " file...");

            Path tempFile = saveToDisk(inputStream, jobId, fileName);
            streamAndSave(tempFile, fileName, fileFormat, jobId,
                          networkVersion, progress);
            deleteTempFile(tempFile);

            // ── Step 2: Resolve cross-references ─────────────────────────
            progress.setStage(ProgressTracker.Stage.RESOLVING_REFERENCES,
                    "Resolving cross-references...");

            long resolved = referenceResolver.resolveReferencesInMongo(
                    jobId, chunkSize, progress);
            progress.log("References resolved: " + resolved);

            // ── Step 3: Mark RESOLVED — NO validation ────────────────────
            job = jobRepo.findByJobId(jobId).orElse(job);
            job.setStatus("RESOLVED");
            job.setTotalObjects((int) progress.getParsed());
            job.setCompletedAt(java.time.Instant.now());
            job.setProcessingMs(System.currentTimeMillis()
                    - job.getSubmittedAt().toEpochMilli());
            jobRepo.save(job);

            progress.done();
            log.info("Import complete: jobId={} version={} objects={} resolved={}",
                    jobId, networkVersion, progress.getParsed(), resolved);

        } catch (Exception e) {
            log.error("Import failed: jobId={} error={}", jobId, e.getMessage());
            job = jobRepo.findByJobId(jobId).orElse(job);
            job.setStatus("FAILED");
            job.setErrorMessage(e.getMessage());
            job.setCompletedAt(java.time.Instant.now());
            jobRepo.save(job);
            progress.fail(e.getMessage());
            throw e;
        }
    }

    /**
     * Async version — for large files. Returns immediately.
     * Client polls GET /api/jobs/{jobId}/progress.
     */
    @org.springframework.scheduling.annotation.Async
    public java.util.concurrent.CompletableFuture<Void> processAndResolveAsync(
            InputStream inputStream,
            String fileName,
            String fileFormat,
            String jobId,
            String networkVersion) {
        try {
            processAndResolve(inputStream, fileName, fileFormat,
                              jobId, networkVersion);
        } catch (Exception e) {
            log.error("Async import failed: {}", e.getMessage());
        }
        return java.util.concurrent.CompletableFuture.completedFuture(null);
    }

    // ── UPDATED toRecord() — sets networkVersion on every CimObjectRecord ──

    private CimObjectRecord toRecord(CIMObject obj, String jobId,
                                      String networkVersion) {
        CimObjectRecord r = new CimObjectRecord();
        r.setJobId(jobId);
        r.setRdfId(obj.getRdfId());
        r.setMrid(obj.getMrid());
        r.setCimType(obj.getCimType());
        r.setName(obj.getName());
        r.setCategory(PhysicalFilterStage.isLogical(obj.getCimType())
                ? "LOGICAL" : "PHYSICAL");
        r.setSourceFormat(obj.getSourceFormat());
        r.setSourceFile(obj.getSourceFile());
        r.setOrgId(obj.getOrgId());
        r.setVersion(networkVersion);      // ← SET VERSION HERE
        r.setAttributes(MapKeySanitizer.encodeKeys(obj.getAttributes()));
        r.setReferences(MapKeySanitizer.encodeKeys(obj.getReferences()));
        r.setCreatedAt(java.time.Instant.now());
        return r;
    }

// ═══════════════════════════════════════════════════════════════════
// ADD THESE METHODS to ValidationJobRepository interface
// in ValidationRepositories.java
// ═══════════════════════════════════════════════════════════════════

    /**
     * Find jobs with the same fileHash AND networkVersion.
     * Used to detect duplicate imports.
     *
     * Returns any job that is PENDING, RUNNING, or DONE with same
     * file content and same version label.
     * FAILED jobs are excluded — a failed import can be retried.
     */
    List<ValidationJob> findByFileHashAndNetworkVersionAndStatusIn(
            String fileHash,
            String networkVersion,
            List<String> statuses);

    /**
     * Find jobs by networkVersion only.
     * Used to list all imports for a given network version.
     */
    List<ValidationJob> findByNetworkVersion(String networkVersion);

    /**
     * Find jobs by filename and networkVersion.
     * Secondary duplicate check if hash is not available.
     */
    List<ValidationJob> findByFileNameAndNetworkVersionAndStatusIn(
            String fileName,
            String networkVersion,
            List<String> statuses);

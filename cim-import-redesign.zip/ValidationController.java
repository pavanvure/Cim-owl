package com.cim.controller;

import com.cim.adapter.AdapterRegistry;
import com.cim.adapter.CIMFormatAdapter;
import com.cim.model.mongo.ValidationJob;
import com.cim.repository.ValidationJobRepository;
import com.cim.service.LargeFileValidationService;
import com.cim.service.QueryService;
import com.cim.service.ValidationService;
import com.cim.streaming.ProgressSnapshot;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.io.InputStream;
import java.security.MessageDigest;
import java.util.*;

/**
 * ValidationController — Updated
 *
 * Changes from original:
 *   1. NEW param: networkVersion (required) — e.g. "2024-Q1", "SUMMER-PEAK"
 *   2. Duplicate check: same file (hash) + same version → 409 Conflict
 *   3. Flow stops after reference resolution — no validation pipeline
 *   4. Status: PENDING → RUNNING → RESOLVED (not DONE/FAILED)
 */
@RestController
@RequestMapping("/api")
@CrossOrigin(origins = "*")
public class ValidationController {

    private static final long LARGE_FILE_THRESHOLD_BYTES = 50L * 1024 * 1024; // 50MB

    private final AdapterRegistry          adapterRegistry;
    private final ValidationService        validationService;
    private final LargeFileValidationService largeFileService;
    private final ValidationJobRepository  jobRepo;
    private final QueryService             queryService;

    public ValidationController(AdapterRegistry adapterRegistry,
                                  ValidationService validationService,
                                  LargeFileValidationService largeFileService,
                                  ValidationJobRepository jobRepo,
                                  QueryService queryService) {
        this.adapterRegistry  = adapterRegistry;
        this.validationService = validationService;
        this.largeFileService  = largeFileService;
        this.jobRepo           = jobRepo;
        this.queryService      = queryService;
    }

    // ─────────────────────────────────────────────────────────────────────
    // POST /api/import
    //
    // Upload a CIM file. Parses it, saves all objects to MongoDB,
    // resolves cross-references. NO validation pipeline.
    //
    // Required params:
    //   file           — the CIM file (RDF/XML, JSON-LD, Milsoft CSV)
    //   networkVersion — version label e.g. "2024-Q1", "SUMMER-PEAK-v2"
    //
    // Optional params:
    //   user           — who is importing (header X-User or param)
    //
    // Responses:
    //   200 OK         — small file completed
    //   202 Accepted   — large file processing started, poll /progress
    //   409 Conflict   — same file+version already exists (PENDING/RUNNING/RESOLVED)
    //   400 Bad Request— missing version or empty file
    // ─────────────────────────────────────────────────────────────────────
    @PostMapping("/import")
    public ResponseEntity<?> importFile(
            @RequestParam("file")           MultipartFile file,
            @RequestParam("networkVersion") String networkVersion,
            @RequestHeader(value = "X-User", defaultValue = "anonymous") String user) {

        // ── Validate inputs ───────────────────────────────────────────────
        if (file.isEmpty()) {
            return ResponseEntity.badRequest()
                    .body(Map.of("error", "File is empty."));
        }
        if (networkVersion == null || networkVersion.isBlank()) {
            return ResponseEntity.badRequest()
                    .body(Map.of(
                        "error", "networkVersion is required.",
                        "hint",  "Provide a version label e.g. '2024-Q1' or 'SUMMER-PEAK'"));
        }

        String cleanVersion = networkVersion.trim();

        // ── Compute file hash for duplicate detection ─────────────────────
        String fileHash;
        byte[] fileBytes;
        try {
            fileBytes = file.getBytes();
            fileHash  = sha256(fileBytes);
        } catch (Exception e) {
            return ResponseEntity.internalServerError()
                    .body(Map.of("error", "Could not read file: " + e.getMessage()));
        }

        // ── DUPLICATE CHECK ───────────────────────────────────────────────
        // Block if same file (hash) + same version is already PENDING,
        // RUNNING, or RESOLVED. Allow retry of FAILED jobs.
        List<String> activeStatuses = List.of("PENDING", "RUNNING", "RESOLVED");

        List<ValidationJob> duplicates = jobRepo
                .findByFileHashAndNetworkVersionAndStatusIn(
                        fileHash, cleanVersion, activeStatuses);

        if (!duplicates.isEmpty()) {
            ValidationJob existing = duplicates.get(0);
            return ResponseEntity.status(409).body(Map.of(
                "error",          "Duplicate import rejected.",
                "reason",         "Same file with version '" + cleanVersion
                                  + "' is already " + existing.getStatus() + ".",
                "existingJobId",  existing.getJobId(),
                "existingStatus", existing.getStatus(),
                "importedAt",     existing.getSubmittedAt().toString(),
                "hint",           "Use a different networkVersion to import this "
                                  + "file as a new version. "
                                  + "Or DELETE the existing job first."
            ));
        }

        // ── Also check by filename + version (secondary check) ────────────
        // Catches cases where same-named file with different content
        // is uploaded for the same version
        List<ValidationJob> sameNameVersion = jobRepo
                .findByFileNameAndNetworkVersionAndStatusIn(
                        file.getOriginalFilename(), cleanVersion, activeStatuses);

        if (!sameNameVersion.isEmpty()) {
            ValidationJob existing = sameNameVersion.get(0);
            return ResponseEntity.status(409).body(Map.of(
                "error",          "Duplicate import rejected.",
                "reason",         "File '" + file.getOriginalFilename()
                                  + "' with version '" + cleanVersion
                                  + "' was already imported (status: "
                                  + existing.getStatus() + ").",
                "existingJobId",  existing.getJobId(),
                "existingStatus", existing.getStatus(),
                "hint",           "Different file content detected but filename+version "
                                  + "matches an existing import."
            ));
        }

        // ── Detect format ─────────────────────────────────────────────────
        CIMFormatAdapter adapter;
        try {
            byte[] sample = Arrays.copyOf(fileBytes, Math.min(512, fileBytes.length));
            adapter = adapterRegistry.detect(sample, file.getOriginalFilename());
        } catch (IllegalArgumentException e) {
            return ResponseEntity.badRequest()
                    .body(Map.of("error", "Unsupported file format: " + e.getMessage()));
        }
        String format  = adapter.getFormatName();
        String jobId   = UUID.randomUUID().toString();
        long   fileSize = file.getSize();

        // ── Create job record ─────────────────────────────────────────────
        ValidationJob job = new ValidationJob(
                jobId, file.getOriginalFilename(), format, user, cleanVersion);
        job.setFileHash(fileHash);
        job.setStatus("PENDING");
        jobRepo.save(job);

        // ── Route by file size ────────────────────────────────────────────
        try {
            if (fileSize <= LARGE_FILE_THRESHOLD_BYTES) {
                // Small file — synchronous, returns when done
                largeFileService.processAndResolve(
                        new java.io.ByteArrayInputStream(fileBytes),
                        file.getOriginalFilename(),
                        format,
                        jobId,
                        cleanVersion);

                ValidationJob done = jobRepo.findByJobId(jobId).orElse(job);
                return ResponseEntity.ok(Map.of(
                    "jobId",          jobId,
                    "status",         done.getStatus(),
                    "networkVersion", cleanVersion,
                    "fileName",       file.getOriginalFilename(),
                    "format",         format,
                    "totalObjects",   done.getTotalObjects(),
                    "links",          buildLinks(jobId)
                ));

            } else {
                // Large file — async, returns immediately
                largeFileService.processAndResolveAsync(
                        file.getInputStream(),
                        file.getOriginalFilename(),
                        format,
                        jobId,
                        cleanVersion);

                return ResponseEntity.accepted().body(Map.of(
                    "jobId",          jobId,
                    "status",         "PROCESSING",
                    "networkVersion", cleanVersion,
                    "fileName",       file.getOriginalFilename(),
                    "format",         format,
                    "fileSizeMb",     String.format("%.1f", fileSize / (1024.0 * 1024.0)),
                    "links",          buildLinks(jobId)
                ));
            }
        } catch (Exception e) {
            job.setStatus("FAILED");
            job.setErrorMessage(e.getMessage());
            jobRepo.save(job);
            return ResponseEntity.internalServerError()
                    .body(Map.of("error", e.getMessage(), "jobId", jobId));
        }
    }

    // ─────────────────────────────────────────────────────────────────────
    // GET /api/jobs/{jobId}/progress
    // ─────────────────────────────────────────────────────────────────────
    @GetMapping("/jobs/{jobId}/progress")
    public ResponseEntity<?> getProgress(@PathVariable String jobId) {
        Optional<ProgressSnapshot> snap = largeFileService.getProgress(jobId);
        if (snap.isPresent()) return ResponseEntity.ok(snap.get());
        return jobRepo.findByJobId(jobId)
                .map(job -> ResponseEntity.ok(Map.of(
                    "jobId",          jobId,
                    "status",         job.getStatus(),
                    "networkVersion", job.getNetworkVersion() != null
                                      ? job.getNetworkVersion() : "",
                    "totalObjects",   job.getTotalObjects(),
                    "finished",       "RESOLVED".equals(job.getStatus())
                                   || "FAILED".equals(job.getStatus())
                )))
                .orElse(ResponseEntity.notFound().build());
    }

    // ─────────────────────────────────────────────────────────────────────
    // GET /api/jobs
    // ─────────────────────────────────────────────────────────────────────
    @GetMapping("/jobs")
    public ResponseEntity<?> listJobs(
            @RequestParam(required = false) String networkVersion) {
        List<ValidationJob> jobs = (networkVersion != null && !networkVersion.isBlank())
                ? jobRepo.findByNetworkVersion(networkVersion.trim())
                : jobRepo.findTop10ByOrderBySubmittedAtDesc();
        return ResponseEntity.ok(jobs);
    }

    // ─────────────────────────────────────────────────────────────────────
    // GET /api/jobs/{jobId}
    // ─────────────────────────────────────────────────────────────────────
    @GetMapping("/jobs/{jobId}")
    public ResponseEntity<?> getJob(@PathVariable String jobId) {
        return jobRepo.findByJobId(jobId)
                .map(ResponseEntity::ok)
                .orElse(ResponseEntity.notFound().build());
    }

    // ─────────────────────────────────────────────────────────────────────
    // GET /api/jobs/{jobId}/objects
    // ─────────────────────────────────────────────────────────────────────
    @GetMapping("/jobs/{jobId}/objects")
    public ResponseEntity<?> getObjects(
            @PathVariable String jobId,
            @RequestParam(required = false) String type,
            @RequestParam(required = false) String category,
            @RequestParam(required = false) String name,
            @RequestParam(defaultValue = "0")  int page,
            @RequestParam(defaultValue = "50") int size) {
        return ResponseEntity.ok(
                queryService.getObjects(jobId, type, category, name, page, size));
    }

    // ─────────────────────────────────────────────────────────────────────
    // GET /api/jobs/{jobId}/objects/stats
    // ─────────────────────────────────────────────────────────────────────
    @GetMapping("/jobs/{jobId}/objects/stats")
    public ResponseEntity<?> getStats(@PathVariable String jobId) {
        return ResponseEntity.ok(queryService.getObjectStats(jobId));
    }

    // ─────────────────────────────────────────────────────────────────────
    // DELETE /api/jobs/{jobId}
    // Removes job + all its objects (allows re-import)
    // ─────────────────────────────────────────────────────────────────────
    @DeleteMapping("/jobs/{jobId}")
    public ResponseEntity<?> deleteJob(@PathVariable String jobId) {
        if (jobRepo.findByJobId(jobId).isEmpty()) {
            return ResponseEntity.notFound().build();
        }
        queryService.deleteJob(jobId);
        return ResponseEntity.ok(Map.of(
            "message", "Job " + jobId + " and all its objects deleted.",
            "hint",    "You can now re-import the same file+version."
        ));
    }

    // ── Helpers ───────────────────────────────────────────────────────────

    private Map<String, String> buildLinks(String jobId) {
        return Map.of(
            "progress", "/api/jobs/" + jobId + "/progress",
            "objects",  "/api/jobs/" + jobId + "/objects",
            "stats",    "/api/jobs/" + jobId + "/objects/stats",
            "delete",   "/api/jobs/" + jobId
        );
    }

    private String sha256(byte[] data) throws Exception {
        MessageDigest md = MessageDigest.getInstance("SHA-256");
        byte[] hash = md.digest(data);
        StringBuilder sb = new StringBuilder();
        for (byte b : hash) sb.append(String.format("%02x", b));
        return sb.toString();
    }
}

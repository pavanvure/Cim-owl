// ═══════════════════════════════════════════════════════════════════
// CHANGES TO MongoDocuments.java
//
// 1. ADD these fields to ValidationJob class:
//
//    private String networkVersion;  // user-supplied e.g. "2024-Q1", "v3.2"
//    private String fileHash;        // SHA-256 of file content
//
// 2. ADD these fields to CimObjectRecord class:
//    (networkVersion field already exists — just confirm it is set)
//
// ═══════════════════════════════════════════════════════════════════

// ── ADD to ValidationJob (after errorMessage field) ──────────────

    /**
     * User-supplied network version label.
     * e.g. "2024-Q1", "SUMMER-PEAK", "v3.2", "OUTAGE-2026-05"
     * Used with fileHash for duplicate detection.
     */
    private String networkVersion;

    /**
     * SHA-256 hash of the uploaded file content.
     * Used together with networkVersion to detect duplicate imports.
     * Same file + same version = duplicate → rejected.
     */
    private String fileHash;

// ── ADD getters/setters to ValidationJob ─────────────────────────

    public String getNetworkVersion()         { return networkVersion; }
    public void setNetworkVersion(String v)   { this.networkVersion = v; }
    public String getFileHash()               { return fileHash; }
    public void setFileHash(String v)         { this.fileHash = v; }

// ── ALSO UPDATE constructor to accept networkVersion ─────────────
// Replace the existing 4-param constructor with this 5-param version:

    public ValidationJob(String jobId, String fileName,
                          String fileFormat, String submittedBy,
                          String networkVersion) {
        this.jobId           = jobId;
        this.fileName        = fileName;
        this.fileFormat      = fileFormat;
        this.submittedBy     = submittedBy;
        this.networkVersion  = networkVersion;
        this.status          = "PENDING";
        this.submittedAt     = Instant.now();
    }
